package br.edu.ifcvideira.utils;

import java.sql.*;

import javax.swing.JOptionPane;

public class Conectar {
	private final static String driver = "org.postgresql.Driver";
	private final static String usuario = "postgres";
	private final static String senha = "ifcvideira";
	private final static String host = "localhost";
	private final static String porta = "5432";
	private final static String banco = "txaccessbd";
	private final static String url = "jdbc:postgresql://" + host + ":" + porta + "/" + banco;
	private static Connection conexao = null;
	    
	public static Connection conectar(){
		 try {
			 Class.forName(driver);
			 conexao = DriverManager.getConnection(url, usuario, senha);
			 System.out.println("Conex�o efetuada com sucesso");
	       
		 } catch (Exception ex) {
			 JOptionPane.showMessageDialog(null, ex, "Erro Conex�o", JOptionPane.ERROR_MESSAGE);
		 }
		return conexao; 
	}

	public void fechar() {
		try {
			conexao.close();
			System.out.println("Conex�o encerrada");
		} 
	        
		catch (SQLException e) {
			e.printStackTrace();
		}
	}	
}
