package br.edu.ifcvideira.DAOs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.edu.ifcvideira.beans.ProdutoBeans;
import br.edu.ifcvideira.utils.Conectar;

public class ProdutoDAO {
	public void cadastrar(ProdutoBeans eb) throws Exception {
		try{
			String sql = "INSERT INTO produto (descricao, tipo, custo, marca, modelo, valorvenda, margemlucro) VALUES (?,?,?,?,?,?,?)";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			
			sqlPrep.setString(1, eb.getDescricao());
			sqlPrep.setString(2, eb.getTipo());
			sqlPrep.setString(3, eb.getCusto());
			sqlPrep.setString(4, eb.getMarca());
			sqlPrep.setString(5, eb.getModelo());
			sqlPrep.setString(6, eb.getValorVenda());
			sqlPrep.setString(7, eb.getMargemLucro());
			
			sqlPrep.execute();
			
			JOptionPane.showMessageDialog(null, "Produto Cadastrado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,e);
		}
	}
	
	public void alterar(ProdutoBeans eb) throws Exception {
		try{
			String sql = "UPDATE produto SET descricao = ?, tipo = ?, custo = ?, marca = ?, modelo = ?, valorvenda = ?, margemlucro = ? WHERE idProduto = ?";
			
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			
			sqlPrep.setString(1, eb.getDescricao());
			sqlPrep.setString(2, eb.getTipo());
			sqlPrep.setString(3, eb.getCusto());
			sqlPrep.setString(4, eb.getMarca());
			sqlPrep.setString(5, eb.getModelo());
			sqlPrep.setString(6, eb.getValorVenda());
			sqlPrep.setString(7, eb.getMargemLucro());
			sqlPrep.setInt(8, eb.getCodigo());
			
			sqlPrep.execute();
			
			JOptionPane.showMessageDialog(null, "Produto Atualizado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,e);
		}
	}
	
	public void excluir (ProdutoBeans eb) throws Exception {
		try{
			String sql = "DELETE FROM produto WHERE idProduto = ?";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			sqlPrep.setInt(1, eb.getCodigo());
			sqlPrep.execute();
			JOptionPane.showMessageDialog(null, "Produto apagado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,"SQLException \n\n"+e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Exception \n\n"+e);
		}
	}
	
	public int RetornarProximoCodigoCliente() throws Exception {
		try{
			String sql ="SELECT MAX(idProduto)+1 AS codigo FROM produto ";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			ResultSet rs = sqlPrep.executeQuery();
			if (rs.next()){
				return rs.getInt("codigo");
			}else{
				return 1;
			}
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return 1;
		}
	}
	
	public List<Object> buscarTodos() throws SQLException, Exception{
		List<Object> produto = new ArrayList<Object>();
		try {
			String sql = "SELECT * FROM produto";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next())
			{
				Object[] linha = {rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(5), rs.getString(6), rs.getString(4), rs.getString(7),rs.getString(8)};
				produto.add(linha);
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return produto;
	}
}
