package br.edu.ifcvideira.DAOs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.edu.ifcvideira.beans.Produto_Venda;
import br.edu.ifcvideira.beans.RelatorioEmpresaBeans;
import br.edu.ifcvideira.beans.Servico_Venda;
import br.edu.ifcvideira.beans.VendaBeans;
import br.edu.ifcvideira.beans.VendaProdutoServicoBeans;
import br.edu.ifcvideira.utils.Conectar;

public class VendaDAO {
	public void cadastrarVenda(VendaBeans eb) throws Exception {
		try{
			String sql = "INSERT INTO venda (idEmpresa, idCliente, dataVenda, valorTotal) VALUES (?,?,?,?)";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			
			sqlPrep.setInt(1, eb.getIdEmpresa());
			sqlPrep.setInt(2, eb.getIdCliente());
			sqlPrep.setTimestamp(3, eb.getDataVenda());
			sqlPrep.setString(4, eb.getValorTotal());
			
			sqlPrep.execute();
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e, "SQLException Erro", JOptionPane.ERROR_MESSAGE);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e, "Exception Erro", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void cadastraVendaProdutoServico(VendaProdutoServicoBeans eb) throws Exception {
		try{
			String sql = "INSERT INTO VendaProdutoServico (idVenda, idProduto, idServico, quantidade, valor, valorTotalProduto) VALUES (?,?,?,?,?,?)";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			
			sqlPrep.setInt(1, eb.getIdVenda());
			sqlPrep.setInt(2, eb.getIdProduto());
			sqlPrep.setInt(3, eb.getIdServico());
			sqlPrep.setDouble(4, eb.getQuantidade());
			sqlPrep.setDouble(5, eb.getValor());
			sqlPrep.setDouble(6, eb.getValorTotalProduto());
			
			sqlPrep.execute();

		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e, "Erro SQLExceptio", JOptionPane.ERROR_MESSAGE);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exception", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void alterar(VendaBeans eb) throws Exception{
		try{
			String sql = "DELETE FROM venda WHERE idVenda = ?";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			sqlPrep.setInt(1, eb.getIdVenda());
			sqlPrep.execute();
			
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,"SQLException \n\n"+e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Exception \n\n"+e);
		}
		
		try{
			String sql = "INSERT INTO venda (idEmpresa, idCliente, dataVenda, valorTotal) VALUES (?,?,?,?)";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			
			sqlPrep.setInt(1, eb.getIdEmpresa());
			sqlPrep.setInt(2, eb.getIdCliente());
			sqlPrep.setTimestamp(3, eb.getDataVenda());
			sqlPrep.setString(4, eb.getValorTotal());
			
			sqlPrep.execute();
			
			JOptionPane.showMessageDialog(null, "Cliente alterado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,e);
		}
	}
	
	public void excluir (VendaBeans eb) throws Exception {
		try{
			String sql = "DELETE FROM venda WHERE idVenda = ?";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			sqlPrep.setInt(1, eb.getIdVenda());
			sqlPrep.execute();
			
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,"SQLException \n\n"+e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Exception \n\n"+e);
		}
	}
	
	public int RetornarProximoVenda() throws Exception {
		try{
			String sql ="SELECT MAX(idVenda)+1 AS codigo FROM venda";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			ResultSet rs = sqlPrep.executeQuery();
			if (rs.next()){
				return rs.getInt("codigo");
			}else{
				return 1;
			}
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			return 1;
		}
	}
	
	public List<Object> buscarTodos() throws SQLException, Exception{
		List<Object> cliente = new ArrayList<Object>();
		try {
			String sql = "SELECT * FROM venda";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next())
			{
				Object[] linha = {rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)};
				cliente.add(linha);
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return cliente;
	}

	public List<Object> buscarProdutosVenda() throws Exception{
		List<Object> venda = new ArrayList<Object>();
		try {
			String sql = "SELECT * FROM produtos_venda";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next())
			{
				Object[] linha = {rs.getString(1),rs.getString(2) ,rs.getString(3), rs.getString(4), rs.getString(5), rs.getObject(6), rs.getObject(7)};
				venda.add(linha);
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return venda;
	}
	
	public void insereProduto(Produto_Venda eb) {
		try{
			String sql = "INSERT INTO produtos_venda (idVenda, idProduto,nomeProduto, tipo ,quantidade, valorProduto,valorTotalProduto) VALUES (?,?,?,?,?,?,?)";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			
			sqlPrep.setInt(1, eb.getIdVenda());
			sqlPrep.setInt(2, eb.getIdProduto());
			sqlPrep.setString(3, eb.getNomeProduto());
			sqlPrep.setString(4, eb.getTipo());
			sqlPrep.setInt(5, eb.getQuantidade());
			sqlPrep.setDouble(6, eb.getValorProduto());
			sqlPrep.setDouble(7, eb.getValorTotalProduto());
			
			sqlPrep.execute();
			
			JOptionPane.showMessageDialog(null, "Cadastro Produto Venda efetuado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,e);
		}
	}
	
	public List<Object> buscarServicoVenda() throws Exception{
		List<Object> venda = new ArrayList<Object>();
		try {
			String sql = "SELECT * FROM servicos_venda";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next())
			{
				Object[] linha = {rs.getString(1),rs.getString(2) ,rs.getString(3), rs.getString(4), rs.getString(5), rs.getObject(6), rs.getObject(7)};
				venda.add(linha);
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return venda;
	}
	
	public void insereServico(Servico_Venda eb) {
		try{
			String sql = "INSERT INTO servicos_venda (idVenda, idServicos, nomeServico, tipo ,quantidade, valorServico,valorTotalServico) VALUES (?,?,?,?,?,?,?)";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			
			sqlPrep.setInt(1, eb.getIdVenda());
			sqlPrep.setInt(2, eb.getIdServico());
			sqlPrep.setString(3, eb.getNomeServico());
			sqlPrep.setString(4, eb.getTipo());
			sqlPrep.setInt(5, eb.getQuantidade());
			sqlPrep.setDouble(6, eb.getValorServico());
			sqlPrep.setDouble(7, eb.getValorTotalServico());
			
			sqlPrep.execute();
			
			JOptionPane.showMessageDialog(null, "Cadastro Servi�o Venda efetuado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,e);
		}
	}
	
	public void excluirServico (Servico_Venda eb) throws Exception {
		try{
			String sql = "DELETE FROM servicos_venda WHERE idServicos = ?";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			sqlPrep.setInt(1, eb.getIdServico());
			sqlPrep.execute();
			JOptionPane.showMessageDialog(null, "Servico_Venda apagado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,"SQLException \n\n"+e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Exception \n\n"+e);
		}
	}
	
	public void excluirProduto (Produto_Venda eb) throws Exception {
		try{
			String sql = "DELETE FROM produtos_venda WHERE idProduto = ?";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			sqlPrep.setInt(1, eb.getIdProduto());
			sqlPrep.execute();
			JOptionPane.showMessageDialog(null, "Produto_Venda apagado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,"SQLException \n\n"+e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Exception \n\n"+e);
		}
	}
	
	public void apagarTabela() {
		try{
			String sql = "DELETE FROM servicos_venda";
			java.sql.Statement state = Conectar.conectar().createStatement();
			state.executeQuery(sql);
			state.close();

		} catch(SQLException e) {
			
			
		} catch(Exception e) {
			
		}
	}
	
	public void apagarTabela1() {
		try{			
			String sql1 = "DELETE FROM produtos_venda";
			java.sql.Statement state1 = Conectar.conectar().createStatement();
			state1.executeQuery(sql1);
			state1.close();
		} catch(SQLException e) {
			
			
		} catch(Exception e) {
			
		}
	}
	//Chamar este metodo para pegar os dados da tabela de baixo do relotio venda
	public List<Object> retornaVenda() {
		List<Object> cliente = new ArrayList<Object>();
		try {
			String sql = "SELECT * FROM venda";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next())
			{
				Object[] linha = {rs.getString(1),rs.getString(2) ,rs.getString(3), rs.getString(4), rs.getString(5)};
				cliente.add(linha);
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}

		return cliente;
	}
	public List<Object> retornaNomeEmpresa(int cod) {
		List<Object> nome = new ArrayList<Object>();
			try {
				String sql = "SELECT empresa FROM empresa WHERE idEmpresa = " + cod;
				java.sql.Statement state = Conectar.conectar().createStatement();
				ResultSet rs = state.executeQuery(sql);	
				while (rs.next())
				{
					Object[] linha = {rs.getString(1)};
					nome.add(linha);
				}
				state.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
		return nome;
	}
	
	public List<Object> retornaRelatorioVenda(RelatorioEmpresaBeans re){
		List<Object> dados = new ArrayList<Object>();
		try {
			String sql = "SELECT empresa FROM empresa WHERE idEmpresa = " + re.getNomeEmpresa();
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			while (rs.next())
			{
				Object[] linha = {rs.getString(1)};
				dados.add(linha);
			}
			state.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exception RetornaRelatorioVenda (BuscaEmpresa)", JOptionPane.ERROR_MESSAGE);
		}
		try {
			String sql = "SELECT cliente FROM cliente WHERE idCliente = " + re.getNomeCliente();
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			while (rs.next())
			{
				Object[] linha = {rs.getString(1)};
				dados.add(linha);
			}
			state.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exception RetornaRelatorioVenda (BuscaCliente)", JOptionPane.ERROR_MESSAGE);
		}
		return dados;
	}
	public String retornaNomeEmpresa(RelatorioEmpresaBeans re) {
		String cliente = new String();
		try {
			String sql = "SELECT empresa FROM empresa WHERE idEmpresa = " + re.getIdEmpresa();
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			
			while (rs.next())
			{
				String linha = rs.getString(1);
				cliente = linha;
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		
		return cliente;
		//Terminar para enviar os dados para a tabela
	}
	public String retornaNomeCliente(RelatorioEmpresaBeans re) {
		String cliente = new String();
		try {
			String sql = "SELECT cliente FROM cliente WHERE idCliente = " + re.getIdCliente();
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			
			while (rs.next())
			{
				String linha = rs.getString(1);
				cliente = linha;
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		
		return cliente;
	}
	
	public String retornaDadoCNPJEmpresa(RelatorioEmpresaBeans re) {
		String cliente = new String();
		try {
			String sql = "SELECT cnpjcpf FROM empresa WHERE empresa = '" + re.getNomeEmpresa()+"'";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			
			while (rs.next())
			{
				String linha = rs.getString(1);
				cliente = linha;
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exceptio retornaDadoCNPJEmpresa", JOptionPane.ERROR_MESSAGE);
		}
		
		return cliente;
	}
	public String retornaDadoCNPJCliente(RelatorioEmpresaBeans re) {
		String cliente = new String();
		try {
			String sql = "SELECT cnpjcpf FROM cliente WHERE cliente = '" + re.getNomeCliente()+"'";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			
			while (rs.next())
			{
				String linha = rs.getString(1);
				cliente = linha;
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exceptio retornaDadoCNPJCliente", JOptionPane.ERROR_MESSAGE);
		}
		
		return cliente;
	}
	public String retornaEnderecoEmpresa(RelatorioEmpresaBeans re) {
		String cliente = new String();
		try {
			String sql = "SELECT rua, bairro, cidade, estado FROM empresa WHERE empresa = '" + re.getNomeEmpresa()+"'";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			
			while (rs.next())
			{
				String linha = rs.getString(1)+", " + rs.getString(2)+", " + rs.getString(3)+", " + rs.getString(4);
				cliente = linha;
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exceptio retornaEnderecoEmpresa", JOptionPane.ERROR_MESSAGE);
		}
		
		return cliente;
	}
	
	public String retornaEnderecoCliente(RelatorioEmpresaBeans re) {
		String cliente = new String();
		try {
			String sql = "SELECT rua, bairro, cidade, estado FROM cliente  WHERE cliente = '" + re.getNomeCliente()+"'";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			
			while (rs.next())
			{
				String linha = rs.getString(1)+", " + rs.getString(2)+", " + rs.getString(3)+", " + rs.getString(4);
				cliente = linha;
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exceptio retornaEnderecoEmpresa", JOptionPane.ERROR_MESSAGE);
		}
		
		return cliente;
	}
	
	public List<Object> retornaProdutosVenda(RelatorioEmpresaBeans re) {
		List<Object> dados = new ArrayList<Object>();
		try {
			String sql = "SELECT * FROM vendaprodutoservico WHERE idVenda = " + re.getIdVenda();
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			
			while (rs.next())
			{
				Object[] linha = {rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)};
				dados.add(linha);
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exceptio retornaProdutosVenda", JOptionPane.ERROR_MESSAGE);
		}
		
		return dados;
	}
	
	public String retornaNomeProduto(RelatorioEmpresaBeans re) {
		String produto = new String();
		try {
			String sql = "SELECT descricao FROM produto WHERE idProduto = " + re.getIdProduto();
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			
			while (rs.next())
			{
				String linha = rs.getString(1);
				produto = linha;
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exceptio retornaEnderecoEmpresa", JOptionPane.ERROR_MESSAGE);
		}
		
		return produto;
	}
	public List<Object> retornaCodigoProduto(RelatorioEmpresaBeans re) {
		List<Object> produto = new ArrayList<Object>();
		try {
			String sql = "SELECT idProduto FROM vendaprodutoservico WHERE idVenda = " + re.getIdProduto();
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			
			while (rs.next())
			{
				Object[] linha = {rs.getString(1)};
				produto.add(linha);
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exceptio retornaEnderecoEmpresa", JOptionPane.ERROR_MESSAGE);
		}
		
		return produto;
	}
	
	public String retornaNomeServico(RelatorioEmpresaBeans re) {
		String servico = new String();
		try {
			String sql = "SELECT descricao FROM servico WHERE idServico = " + re.getIdServico();
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);	
			
			while (rs.next())
			{
				String linha = rs.getString(1);
				servico = linha;
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e, "Erro Exceptio retornaNomeServico", JOptionPane.ERROR_MESSAGE);
		}
		
		return servico;
	}
	public void apagarVenda(VendaBeans vd) {
		try{			
			String sql = "DELETE FROM venda WHERE idVenda = " + vd.getIdVenda();
			java.sql.Statement state = Conectar.conectar().createStatement();
			state.executeQuery(sql);
			state.close();
			
			String sql1 = "DELETE FROM vendaprodutoservico WHERE idVenda = " + vd.getIdVenda();
			java.sql.Statement state1 = Conectar.conectar().createStatement();
			state1.executeQuery(sql1);
			state1.close();
			
		} catch(SQLException e) {
			
			
		} catch(Exception e) {
			
		}
	}
	
}
