package br.edu.ifcvideira.DAOs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.edu.ifcvideira.beans.ClienteBeans;
import br.edu.ifcvideira.utils.Conectar;

public class ClienteDAO1 {
	public void cadastrar(ClienteBeans eb) throws Exception {
		try{
			String sql = "INSERT INTO cliente (cliente, cnpjCpf, inscricao, rg, telefone, bairro, cidade, estado, CEP, pais, rua) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			
			sqlPrep.setString(1, eb.getCliente());
			sqlPrep.setString(2, eb.getCnpj_cpf());
			sqlPrep.setString(3, eb.getInscricaoEstadual());
			sqlPrep.setString(4, eb.getRg());
			sqlPrep.setString(5, eb.getTelefone());
			sqlPrep.setString(6, eb.getBairro());
			sqlPrep.setString(7, eb.getCidade());
			sqlPrep.setString(8, eb.getEstado());
			sqlPrep.setString(9, eb.getCep());
			sqlPrep.setString(10, eb.getPais());
			sqlPrep.setString(11, eb.getRua());
			
			sqlPrep.execute();
			
			JOptionPane.showMessageDialog(null, "Cadastro Cliente efetuado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,e);
		}
	}
	
	public void alterar(ClienteBeans eb) throws Exception{
		try{
			String sql = "UPDATE cliente SET cliente = ?, cnpjCpf = ?, inscricao = ?, rg = ?, telefone = ?, bairro = ?, cidade = ?, estado = ?, CEP = ?, pais = ?, rua = ?  WHERE idCliente = ?";
			
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			
			
			sqlPrep.setString(1, eb.getCliente());
			sqlPrep.setString(2, eb.getCnpj_cpf());
			sqlPrep.setString(3, eb.getInscricaoEstadual());
			sqlPrep.setString(4, eb.getRg());
			sqlPrep.setString(5, eb.getTelefone());
			sqlPrep.setString(6, eb.getBairro());
			sqlPrep.setString(7, eb.getCidade());
			sqlPrep.setString(8, eb.getEstado());
			sqlPrep.setString(9, eb.getCep());
			sqlPrep.setString(10, eb.getPais());
			sqlPrep.setString(11, eb.getRua());
			sqlPrep.setInt(12, eb.getCodigo());
			
			sqlPrep.execute();
			JOptionPane.showMessageDialog(null, "Atualiza��o efetuado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,e.getMessage());
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,e.getMessage());
		}
	}
	
	public void excluir (ClienteBeans eb) throws Exception {
		try{
			String sql = "DELETE FROM cliente WHERE idCliente = ?";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			sqlPrep.setInt(1, eb.getCodigo());
			sqlPrep.execute();
			
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,"SQLException \n\n"+e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Exception \n\n"+e);
		}
	}

	public int RetornarProximoCodigoCliente() throws Exception {
		try{
			String sql ="SELECT MAX(idCliente)+1 AS codigo FROM cliente ";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			ResultSet rs = sqlPrep.executeQuery();
			if (rs.next()){
				return rs.getInt("codigo");
			}else{
				return 1;
			}
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			return 1;
		}
	}
	
	public List<Object> buscarTodos() throws SQLException, Exception{
		List<Object> cliente = new ArrayList<Object>();
		try {
			String sql = "SELECT * FROM cliente";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next())
			{
				Object[] linha = {rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11), rs.getString(12)};
				cliente.add(linha);
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return cliente;
	}
}
