package br.edu.ifcvideira.DAOs;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.edu.ifcvideira.beans.cadastroUsuario;
import br.edu.ifcvideira.utils.Conectar;

public class usuarioDAO {

	public void cadastrar(cadastroUsuario us) throws Exception {
		try{
			String sql = "INSERT INTO acesso (usuario, senha) VALUES (?,?)";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			sqlPrep.setString(1, us.getUsuario());
			sqlPrep.setString(2, us.getSenha());
			sqlPrep.execute();
			JOptionPane.showMessageDialog(null, "Cadastro efetuado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,e);
		}
	}
	
	public void alterar(cadastroUsuario us) throws Exception{
		try{
			String sql = "UPDATE acesso SET usuario = ?, senha = ? WHERE idAcesso = ? ";
			
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			
			sqlPrep.setString(1, us.getUsuario());
			sqlPrep.setString(2, us.getSenha());
			sqlPrep.setInt(3, us.getCodigo());
			
			sqlPrep.execute();
			JOptionPane.showMessageDialog(null, "Atualiza��o efetuado com sucesso !");
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,e.getMessage());
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,e.getMessage());
		}
	}
	
	public void excluir (cadastroUsuario us) throws Exception {
		try{
			String sql = "DELETE FROM acesso WHERE idAcesso = ?";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			sqlPrep.setInt(1, us.getCodigo());
			sqlPrep.execute();
			
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null,"SQLException UsuarioDAO \n\n"+e);
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null,"SQLException UsuarioDAO \n\n"+e);
		}
	}

	public int RetornarProximoCodigoCliente() throws Exception {
		try{
			String sql ="SELECT MAX(idAcesso)+1 AS codigo FROM acesso ";
			java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
			ResultSet rs = sqlPrep.executeQuery();
			if (rs.next()){
				return rs.getInt("codigo");
			}else{
				return 1;
			}
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			return 1;
		}
	}
	
	public List<Object> buscarTodos() throws SQLException, Exception{
		List<Object> cliente = new ArrayList<Object>();
		try {
			String sql = "SELECT * FROM acesso";
			java.sql.Statement state = Conectar.conectar().createStatement();
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next()){
				Object[] linha = {rs.getString(1), rs.getString(2), rs.getString(3)};
				cliente.add(linha);
			}
			state.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return cliente;
	}
	
	public int checkLogin(cadastroUsuario us) throws SQLException, Exception{
		int flag=0;
		
		try{
		String sql = "Select usuario, senha, idAcesso FROM acesso where usuario=?";
		
		java.sql.PreparedStatement sqlPrep = Conectar.conectar().prepareStatement(sql);
		int contador = 1;
		sqlPrep.setString(contador++, us.getUsuario());
		
		ResultSet rs = sqlPrep.executeQuery();
		
		while (rs.next()){
				
				String senha = rs.getString("senha");
				
				if (us.getSenha().equals(senha)){
					us.setUsuario(rs.getString("usuario"));
					us.setCodigo(rs.getInt("idAcesso"));
				}else{
					JOptionPane.showMessageDialog(null, "Senha incorreta", "Senha Acesso", JOptionPane.ERROR_MESSAGE);
				}
				flag=1;
		}
		
		if (flag==0){
			JOptionPane.showMessageDialog(null, "Dados de login inexistente", "Usuario Login", JOptionPane.ERROR_MESSAGE);
		}
	} catch(Exception e) {
		JOptionPane.showMessageDialog(null, "Dados de login inexistente", "Usuario Login", JOptionPane.ERROR_MESSAGE);
		
	}
	return flag;	
	}
}
