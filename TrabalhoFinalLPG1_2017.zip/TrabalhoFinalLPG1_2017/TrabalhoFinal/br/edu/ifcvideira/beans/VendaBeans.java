package br.edu.ifcvideira.beans;

import java.sql.Timestamp;

public class VendaBeans {
	private int	idVenda;
	private int idEmpresa;
	private int idCliente;
	private String valorTotal;
	private Timestamp dataVenda;
	
	public String getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}
	public int getIdVenda() {
		return idVenda;
	}
	public void setIdVenda(int idVenda) {
		this.idVenda = idVenda;
	}
	public int getIdEmpresa() {
		return idEmpresa;
	}
	public void setIdEmpresa(int idEmpresa) {
		this.idEmpresa = idEmpresa;
	}
	public int getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public Timestamp getDataVenda() {
		return dataVenda;
	}
	public void setDataVenda(Timestamp dataVenda) {
		this.dataVenda = dataVenda;
	}

}
