package br.edu.ifcvideira.beans;

public class ServicosBeans {
	private int codigo;
	private String descricao;
	private String custo;
	private String valorVenda;
	private String tipo;
	private String margemLucro;
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getCusto() {
		return custo;
	}
	public void setCusto(String custo) {
		this.custo = custo;
	}
	public String getValorVenda() {
		return valorVenda;
	}
	public void setValorVenda(String valorVenda) {
		this.valorVenda = valorVenda;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getMargemLucro() {
		return margemLucro;
	}
	public void setMargemLucro(String margemLucro) {
		this.margemLucro = margemLucro;
	}	
}
