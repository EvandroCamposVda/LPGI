package br.edu.ifcvideira.beans;

public class Servico_Venda {
	private int idVenda;
	private int idServico;
	private int quantidade;
	private double valorServico;
	private double valorTotalServico;
	private String tipo;
	private String nomeServico;
	public int getIdVenda() {
		return idVenda;
	}
	public void setIdVenda(int idVenda) {
		this.idVenda = idVenda;
	}
	public int getIdServico() {
		return idServico;
	}
	public void setIdServico(int idServico) {
		this.idServico = idServico;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public double getValorServico() {
		return valorServico;
	}
	public void setValorServico(double valorServico) {
		this.valorServico = valorServico;
	}
	public double getValorTotalServico() {
		return valorTotalServico;
	}
	public void setValorTotalServico(double valorTotalServico) {
		this.valorTotalServico = valorTotalServico;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getNomeServico() {
		return nomeServico;
	}
	public void setNomeServico(String nomeServico) {
		this.nomeServico = nomeServico;
	}
}
