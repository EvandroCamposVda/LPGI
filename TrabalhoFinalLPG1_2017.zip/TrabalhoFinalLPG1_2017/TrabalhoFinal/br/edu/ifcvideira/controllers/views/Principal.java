package br.edu.ifcvideira.controllers.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JMenuBar;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Canvas;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class Principal extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setTitle("Principal");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Principal.class.getResource("/br/edu/ifcvideira/imgs/logoTX.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnCadastro = new JMenu("Cadastro");
		menuBar.add(mnCadastro);
		
		JMenuItem mntmEmpresa = new JMenuItem("Empresa");
		mntmEmpresa.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
					Empresa frame = new Empresa();
					frame.setVisible(true);
				
			}
		});
		mnCadastro.add(mntmEmpresa);
		
		JMenuItem mntmClientes = new JMenuItem("Clientes");
		mntmClientes.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Cliente frame = new Cliente();
				frame.setVisible(true);
			}
		});
		mnCadastro.add(mntmClientes);
		
		JMenuItem mntmProduto = new JMenuItem("Produto");
		mntmProduto.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				Produto produto = new Produto();
				produto.setVisible(true);
			}
		});
		mnCadastro.add(mntmProduto);
		
		JMenuItem mntmServio = new JMenuItem("Servi\u00E7o");
		mntmServio.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				Servicos servico = new Servicos();
				servico.setVisible(true);
			}
		});
		mnCadastro.add(mntmServio);
		
		JMenuItem mntmVenda = new JMenuItem("Venda");
		mntmVenda.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				Venda frame = new Venda();
				frame.setVisible(true);
			}
		});
		mnCadastro.add(mntmVenda);
		
		JMenu mnRelatrios = new JMenu("Relat\u00F3rios");
		menuBar.add(mnRelatrios);
		
		JMenuItem mntmClientes_1 = new JMenuItem("Clientes");
		mntmClientes_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				RelatorioCliente rc = new RelatorioCliente();
				rc.setVisible(true);
				rc.setTitle("Relatorio Cliente");
				RelatorioCliente.btnSelecionar.setVisible(false);
			}
		});
		mnRelatrios.add(mntmClientes_1);
		
		JMenuItem mntmEmpresa_1 = new JMenuItem("Empresa");
		mntmEmpresa_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				RelatorioEmpresa re = new RelatorioEmpresa();
				re.setVisible(true);
				re.setTitle("Relatorio Empresa");
				RelatorioEmpresa.btnSelecionar.setVisible(false);
			}
		});
		mnRelatrios.add(mntmEmpresa_1);
		
		JMenuItem mntmServios = new JMenuItem("Servi\u00E7os");
		mntmServios.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				RelatorioServicoProduto rsp = new RelatorioServicoProduto();
				rsp.setVisible(true);
				RelatorioServicoProduto.rdServico.setSelected(true);
				RelatorioServicoProduto.lblQuantidade.setVisible(false);
				RelatorioServicoProduto.txtQuantidade.setVisible(false);
				rsp.atualizarTabelaServico();
				RelatorioServicoProduto.btnSelecionar.setVisible(false);
				RelatorioServicoProduto.txtBuscaServCod.setEditable(true);
				RelatorioServicoProduto.txtBuscaServNom.setEditable(true);
				rsp.setTitle("Relat�rio Produto/Servi�os");
			}
		});
		mnRelatrios.add(mntmServios);
		
		JMenuItem mntmProdutos = new JMenuItem("Produtos");
		mntmProdutos.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				RelatorioServicoProduto rsp= new RelatorioServicoProduto();
				rsp.setVisible(true);
				rsp.setTitle("Relat�rio Produto/Servi�os");
				RelatorioServicoProduto.rdProduto.setSelected(true);
				RelatorioServicoProduto.lblQuantidade.setVisible(false);
				RelatorioServicoProduto.txtQuantidade.setVisible(false);
				rsp.atualizarTabelaProduto();
				RelatorioServicoProduto.btnSelecionar.setVisible(false);
				RelatorioServicoProduto.txtBuscaProdutoCo.setEditable(true);
				RelatorioServicoProduto.txtBuscaProdNom.setEditable(true);
			}
		});
		mnRelatrios.add(mntmProdutos);
		
		JMenuItem mntmVendas = new JMenuItem("Vendas");
		mntmVendas.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				RelatorioVenda rl = new RelatorioVenda();
				rl.setVisible(true);
			}
		});
		mnRelatrios.add(mntmVendas);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(203, 216, 233));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label_1 = new JLabel("");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				label_1.setIcon(new ImageIcon(Principal.class.getResource("/br/edu/ifcvideira/imgs/VendaFundo.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				label_1.setIcon(new ImageIcon(Principal.class.getResource("/br/edu/ifcvideira/imgs/vendaTransparente.png")));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				Venda venda = new Venda();
				venda.setVisible(true);
			}
		});
		label_1.setIcon(new ImageIcon(Principal.class.getResource("/br/edu/ifcvideira/imgs/VendaTransparente.png")));
		label_1.setBounds(968, 34, 92, 42);
		contentPane.add(label_1);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Principal.class.getResource("/br/edu/ifcvideira/imgs/Trabalho Final Faixa.png")));
		label.setBounds(0, 0, 1376, 98);
		contentPane.add(label);
		
		this.setExtendedState(MAXIMIZED_BOTH);		
	}
}
