package br.edu.ifcvideira.controllers.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.RowFilter;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import br.edu.ifcvideira.DAOs.EmpresaDAO;
import br.edu.ifcvideira.DAOs.VendaDAO;
import br.edu.ifcvideira.beans.RelatorioEmpresaBeans;
import br.edu.ifcvideira.beans.VendaBeans;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.SystemColor;
import javax.swing.SwingConstants;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;

public class RelatorioVenda extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JScrollPane scrollPane_1;
	private JLabel lblNewLabel;
	private JTextField txtBuscaCodigo;
	private JLabel lblNewLabel_1;
	private JTextField txtBuscaEmpresa;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;
	private JLabel label_8;
	private JLabel label_9;
	private JTextField txtCodigoVenda;
	private JTextField txtDataEmissao;
	private JTextField txtNomeEmpresa;
	private JTextField txtCPFEmpresa;
	private JTextField txtEnderecoEmpresa;
	private JTextField txtNomeCliente;
	private JTextField txtCNPJCliente;
	private JTextField txtEnderecoCliente;
	public List<Object> nome;
	private List<Object> empresa = new ArrayList<Object>();
	private List<Object> cliente = new ArrayList<Object>();
	private List<Object> venda = new ArrayList<Object>();
	private List<Object> produtos = new ArrayList<Object>();
	private JTextField txtBuscaCliente;
	private List<Object> nome2;
	VendaDAO vd = new VendaDAO();
	RelatorioEmpresaBeans rsp = new RelatorioEmpresaBeans();
	private JTextField txtValorTotalVenda;
	private JLabel label_10;
	public static JButton btnApagar = new JButton("Apagar");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RelatorioVenda frame = new RelatorioVenda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RelatorioVenda() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(RelatorioVenda.class.getResource("/br/edu/ifcvideira/imgs/logoTX.png")));
		setTitle("Relatorio Vendas");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 20, 856, 697);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtDataEmissao = new JTextField();
		txtDataEmissao.setForeground(Color.BLUE);
		txtDataEmissao.setEditable(false);
		txtDataEmissao.setColumns(10);
		txtDataEmissao.setBounds(538, 25, 103, 20);
		contentPane.add(txtDataEmissao);
		
		txtCPFEmpresa = new JTextField();
		txtCPFEmpresa.setForeground(Color.BLUE);
		txtCPFEmpresa.setEditable(false);
		txtCPFEmpresa.setColumns(10);
		txtCPFEmpresa.setBounds(115, 126, 276, 20);
		contentPane.add(txtCPFEmpresa);
		
		txtNomeCliente = new JTextField();
		txtNomeCliente.setForeground(Color.BLUE);
		txtNomeCliente.setEditable(false);
		txtNomeCliente.setColumns(10);
		txtNomeCliente.setBounds(511, 100, 276, 20);
		contentPane.add(txtNomeCliente);
		
		txtEnderecoCliente = new JTextField();
		txtEnderecoCliente.setForeground(Color.BLUE);
		txtEnderecoCliente.setEditable(false);
		txtEnderecoCliente.setColumns(10);
		txtEnderecoCliente.setBounds(511, 152, 276, 20);
		contentPane.add(txtEnderecoCliente);
		
		txtCodigoVenda = new JTextField();
		txtCodigoVenda.setForeground(Color.BLUE);
		txtCodigoVenda.setEditable(false);
		txtCodigoVenda.setColumns(10);
		txtCodigoVenda.setBounds(129, 25, 86, 20);
		contentPane.add(txtCodigoVenda);
		
		txtEnderecoEmpresa = new JTextField();
		txtEnderecoEmpresa.setForeground(Color.BLUE);
		txtEnderecoEmpresa.setEditable(false);
		txtEnderecoEmpresa.setColumns(10);
		txtEnderecoEmpresa.setBounds(115, 155, 276, 20);
		contentPane.add(txtEnderecoEmpresa);
		
		txtCNPJCliente = new JTextField();
		txtCNPJCliente.setForeground(Color.BLUE);
		txtCNPJCliente.setEditable(false);
		txtCNPJCliente.setColumns(10);
		txtCNPJCliente.setBounds(511, 126, 276, 20);
		contentPane.add(txtCNPJCliente);
		
		txtNomeEmpresa = new JTextField();
		txtNomeEmpresa.setForeground(Color.BLUE);
		txtNomeEmpresa.setEditable(false);
		txtNomeEmpresa.setColumns(10);
		txtNomeEmpresa.setBounds(115, 100, 276, 20);
		contentPane.add(txtNomeEmpresa);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(24, 437, 787, 163);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				String cnpj;
				String endereco;
				
				txtCodigoVenda.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 0)));
				txtDataEmissao.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 3)));
				txtNomeEmpresa.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 1)));
				txtNomeCliente.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 2)));
				table.setValueAt(cliente.get(table.getSelectedRow()), table.getSelectedRow(), 2);
				//Retorna CNPJ Empresa do banco
				rsp.setNomeEmpresa(txtNomeEmpresa.getText());
				cnpj = (vd.retornaDadoCNPJEmpresa(rsp));
				txtCPFEmpresa.setText(cnpj);
				
				//Retorna CNPJ Cliente do banco
				rsp.setNomeCliente(txtNomeCliente.getText());
				cnpj = (vd.retornaDadoCNPJCliente(rsp));
				txtCNPJCliente.setText(cnpj);
				
				//Retorna Endere�o Empresa do banco
				rsp.setEnderecoEmpresa(txtNomeEmpresa.getText());
				endereco = (vd.retornaEnderecoEmpresa(rsp));
				txtEnderecoEmpresa.setText(endereco);
				
				//Retorna Endere�o Cliente do banco
				rsp.setEnderecoCliente(txtNomeCliente.getText());
				endereco = (vd.retornaEnderecoCliente(rsp));
				txtEnderecoCliente.setText(endereco);
				
				
				//Recebendo os dados para tabela do banco porem com IDs
				rsp.setIdVenda(Integer.parseInt(txtCodigoVenda.getText()));
				try {
					VendaDAO vd = new VendaDAO();
					produtos = vd.retornaProdutosVenda(rsp);
					DefaultTableModel model = (DefaultTableModel) table_1.getModel();
					model.setNumRows(0);
				for (int x=0; x!=produtos.size(); x++)
					{
						model.addRow((Object[]) produtos.get(x));
					}
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
				//Organizando a tabela
				for (int x=0;x<table_1.getRowCount();x++) {
					table_1.setValueAt(table_1.getValueAt(x, 5), x, 6);
					table_1.setValueAt(table_1.getValueAt(x, 4), x, 5);
					table_1.setValueAt(table_1.getValueAt(x, 3), x, 4);
					
					if (table_1.getValueAt(x, 2).equals("0")) {
						table_1.setValueAt("Produto", x, 3);
					}else if (table_1.getValueAt(x, 2)!="0"){
						table_1.setValueAt("Servi�o", x, 3);
					}
				}
				
				//Trocando os dados de servico para a posi��o do produto
				for (int x=0;x<table_1.getRowCount();x++) {
					if (table_1.getValueAt(x, 2).equals("0")) {
						
					}else {
						table_1.setValueAt(table_1.getValueAt(x, 2), x, 1);
					}
				}
				
				//Recebendo os nomes dos produtos
				for (int x=0;x<table_1.getRowCount();x++) {
					if (table_1.getValueAt(x, 2).equals("0")) {
						RelatorioEmpresaBeans re = new RelatorioEmpresaBeans();
						VendaDAO vd = new VendaDAO();
						String nome;
						re.setIdProduto(Integer.parseInt(String.valueOf(table_1.getValueAt(x, 1))));
						nome = vd.retornaNomeProduto(re);
						table_1.setValueAt(nome, x, 2);
					}else if (table_1.getValueAt(x, 2)!=("0")){
						RelatorioEmpresaBeans re = new RelatorioEmpresaBeans();
						VendaDAO vd = new VendaDAO();
						String nome;
						re.setIdServico(Integer.parseInt(String.valueOf(table_1.getValueAt(x, 2))));
						nome = vd.retornaNomeServico(re);
						table_1.setValueAt(nome, x, 2);
					}
				}
				
				//Atualiza valor total da venda 
				txtValorTotalVenda.setText("R$ "+(String.valueOf(table.getValueAt(table.getSelectedRow(), 4))));
				
				if (table.getSelectedRow()!=-1) {
					btnApagar.setEnabled(true);
				}
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Codigo Venda", "Nome Empresa", "Nome Cliente","Data Venda","Valor Total"
			}
		));
		scrollPane.setViewportView(table);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(24, 186, 787, 156);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.setForeground(Color.BLACK);
		table_1.setBackground(SystemColor.control);
		table_1.setEnabled(false);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
					"Codigo Venda","Codigo Produto", "Produto", "Tipo", "Quantidade", "Valor Produto", "Valor Total"
			}
		));
		scrollPane_1.setViewportView(table_1);
		
		lblNewLabel = new JLabel("Codigo Venda");
		lblNewLabel.setBounds(24, 409, 141, 14);
		contentPane.add(lblNewLabel);
		
		txtBuscaCodigo = new JTextField();
		txtBuscaCodigo.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {
				if (txtBuscaCodigo.getText().equals("")) {
					txtBuscaCliente.setEditable(true);
					txtBuscaCodigo.setEditable(true);
					txtBuscaEmpresa.setEditable(true);
				}else if (txtBuscaCodigo.getText()!=("")) {
					txtBuscaCliente.setEditable(false);
					txtBuscaCodigo.setEditable(true);
					txtBuscaEmpresa.setEditable(false);
				}
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por nome
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro); 
				
				if (txtBuscaCodigo.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscaCodigo.getText(), 0));  
				}
			}
		});
		txtBuscaCodigo.setBounds(115, 406, 157, 20);
		contentPane.add(txtBuscaCodigo);
		txtBuscaCodigo.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Nome Empresa");
		lblNewLabel_1.setBounds(286, 409, 136, 14);
		contentPane.add(lblNewLabel_1);
		
		txtBuscaEmpresa = new JTextField();
		txtBuscaEmpresa.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				if (txtBuscaEmpresa.getText().equals("")) {
					txtBuscaCliente.setEditable(true);
					txtBuscaCodigo.setEditable(true);
					txtBuscaEmpresa.setEditable(true);
				}else if (txtBuscaEmpresa.getText()!=("")) {
					txtBuscaCliente.setEditable(false);
					txtBuscaCodigo.setEditable(false);
					txtBuscaEmpresa.setEditable(true);
				}
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por nome
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro); 
				
				if (txtBuscaEmpresa.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscaEmpresa.getText(), 1));  
				}
				
			}
		});
		txtBuscaEmpresa.setBounds(396, 406, 141, 20);
		contentPane.add(txtBuscaEmpresa);
		txtBuscaEmpresa.setColumns(10);
		
		label = new JLabel("Codigo Venda");
		label.setBounds(34, 28, 128, 14);
		contentPane.add(label);
		
		label_1 = new JLabel("Dados Empresa");
		label_1.setBounds(34, 69, 128, 20);
		contentPane.add(label_1);
		
		label_2 = new JLabel("Nome");
		label_2.setBounds(44, 103, 46, 14);
		contentPane.add(label_2);
		
		label_3 = new JLabel("CNPJ/CPF");
		label_3.setBounds(44, 129, 84, 14);
		contentPane.add(label_3);
		
		label_4 = new JLabel("Endere\u00E7o");
		label_4.setBounds(44, 155, 84, 14);
		contentPane.add(label_4);
		
		label_5 = new JLabel("Dados Cliente");
		label_5.setBounds(430, 66, 128, 23);
		contentPane.add(label_5);
		
		label_6 = new JLabel("Nome");
		label_6.setBounds(440, 103, 46, 14);
		contentPane.add(label_6);
		
		label_7 = new JLabel("CNPJ/CPF");
		label_7.setBounds(440, 129, 84, 14);
		contentPane.add(label_7);
		
		label_8 = new JLabel("Endere\u00E7o");
		label_8.setBounds(440, 155, 84, 14);
		contentPane.add(label_8);
		
		label_9 = new JLabel("Data de Emiss\u00E3o");
		label_9.setBounds(411, 28, 128, 14);
		contentPane.add(label_9);
		
		JButton Sair = new JButton("Sair");
		Sair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		Sair.setBounds(725, 624, 86, 23);
		contentPane.add(Sair);
		
		JLabel lblNomeCliente = new JLabel("Nome Cliente");
		lblNomeCliente.setBounds(560, 409, 136, 14);
		contentPane.add(lblNomeCliente);
		
		txtBuscaCliente = new JTextField();
		txtBuscaCliente.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				if (txtBuscaCliente.getText().equals("")) {
					txtBuscaCliente.setEditable(true);
					txtBuscaCodigo.setEditable(true);
					txtBuscaEmpresa.setEditable(true);
				}else if (txtBuscaCliente.getText()!=("")) {
					txtBuscaCliente.setEditable(true);
					txtBuscaCodigo.setEditable(false);
					txtBuscaEmpresa.setEditable(false);
				}
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por nome
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro); 
				
				if (txtBuscaCliente.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscaCliente.getText(), 2));  
				}
			}
		});
		txtBuscaCliente.setColumns(10);
		txtBuscaCliente.setBounds(670, 406, 141, 20);
		contentPane.add(txtBuscaCliente);
		
		txtValorTotalVenda = new JTextField();
		txtValorTotalVenda.setHorizontalAlignment(SwingConstants.TRAILING);
		txtValorTotalVenda.setEditable(false);
		txtValorTotalVenda.setColumns(10);
		txtValorTotalVenda.setBounds(670, 362, 141, 20);
		contentPane.add(txtValorTotalVenda);
		
		JLabel lblValorTotal = new JLabel("Valor Total ");
		lblValorTotal.setBounds(560, 365, 136, 14);
		contentPane.add(lblValorTotal);
		
		label_10 = new JLabel("");
		label_10.setIcon(new ImageIcon(RelatorioVenda.class.getResource("/br/edu/ifcvideira/imgs/FundoBranco.png")));
		label_10.setBounds(10, 14, 820, 604);
		contentPane.add(label_10);
		btnApagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VendaBeans vb = new VendaBeans();
				VendaDAO vd = new VendaDAO();
				vb.setIdVenda(Integer.parseInt(txtCodigoVenda.getText()));
				vd.apagarVenda(vb);
				atualizaTabelaVendas();
				atualizaNomeEmpresa();
			}
		});
		btnApagar.setEnabled(false);
		
		
		btnApagar.setBounds(365, 624, 89, 23);
		contentPane.add(btnApagar);
		atualizaTabelaVendas();
		atualizaNomeEmpresa();
		btnApagar.setVisible(false);
	}
	
	public void atualizaTabelaVendas() {
		try {
			VendaDAO vd = new VendaDAO();
			venda = vd.retornaVenda();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			model.setNumRows(0);
		for (int x=0; x!=venda.size(); x++)
			{
				model.addRow((Object[]) venda.get(x));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	
	public void atualizaNomeEmpresa() {
		//Criar Metodo de buscar nome da empresa, cliente, datavenda, valorTotal.
		
		
		for (int x=0;x<table.getRowCount();x++) {
			rsp.setIdEmpresa(Integer.parseInt(String.valueOf(table.getValueAt(x, 1))));
			empresa.add(vd.retornaNomeEmpresa(rsp));
			table.setValueAt(empresa.get(x), x, 1);
		}
		
		for (int x=0;x<table.getRowCount();x++) {
			rsp.setIdCliente((Integer.parseInt(String.valueOf(table.getValueAt(x, 2)))));
			cliente.add(vd.retornaNomeCliente(rsp));
			table.setValueAt(cliente.get(x), x, 2);
		}
		
	}
}
