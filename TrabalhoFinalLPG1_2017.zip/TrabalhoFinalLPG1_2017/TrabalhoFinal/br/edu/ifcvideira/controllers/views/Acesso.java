package br.edu.ifcvideira.controllers.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import br.edu.ifcvideira.controllers.views.*;
import br.edu.ifcvideira.utils.Conectar;
import br.edu.ifcvideira.DAOs.usuarioDAO;
import br.edu.ifcvideira.beans.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Acesso extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsuario;
	private JPasswordField txtSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Acesso frame = new Acesso();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Acesso() {
		setTitle("Acesso");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Acesso.class.getResource("/br/edu/ifcvideira/imgs/logoTX.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 200, 560, 341);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setFont(new Font("DeVinne Txt BT", Font.PLAIN, 15));
		lblUsuario.setBounds(208, 151, 81, 14);
		contentPane.add(lblUsuario);
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(328, 149, 196, 20);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		txtSenha = new JPasswordField();
		txtSenha.setBounds(328, 177, 196, 20);
		contentPane.add(txtSenha);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setFont(new Font("DeVinne Txt BT", Font.PLAIN, 15));
		lblSenha.setBounds(208, 179, 93, 14);
		contentPane.add(lblSenha);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Acesso.class.getResource("/br/edu/ifcvideira/imgs/Logo 100x100.png")));
		label.setBounds(208, 0, 114, 120);
		contentPane.add(label);
		
		JLabel lblTxAccessSistemas = new JLabel("Tx Access Sistemas");
		lblTxAccessSistemas.setForeground(Color.DARK_GRAY);
		lblTxAccessSistemas.setBackground(Color.GRAY);
		lblTxAccessSistemas.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 20));
		lblTxAccessSistemas.setBounds(322, 87, 212, 29);
		contentPane.add(lblTxAccessSistemas);
		
		JButton btnEnter = new JButton("Enter");
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				br.edu.ifcvideira.beans.cadastroUsuario usuario = new br.edu.ifcvideira.beans.cadastroUsuario();
				
				usuario.setUsuario(String.valueOf(txtUsuario.getText()));
				usuario.setSenha(String.valueOf(txtSenha.getPassword()));
				
				usuarioDAO userbd = new usuarioDAO();
				try {
					int flag = userbd.checkLogin(usuario);
						if (flag == 1) {
							Principal frame = new Principal();
							frame.setVisible(true);
							dispose();
						}
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, e, "Erro Acesso DAO", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnEnter.setBackground(new Color(204, 204, 255));
		btnEnter.setForeground(SystemColor.desktop);
		btnEnter.setBounds(328, 208, 89, 23);
		contentPane.add(btnEnter);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int dec;
				
				dec = JOptionPane.showConfirmDialog(null, "Deseja realmente sair ?", "Fechar sistema",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
					if (dec == 0) {
						System.exit(0);
					}
			}
		});
		btnCancelar.setBackground(new Color(204, 204, 255));
		btnCancelar.setBounds(435, 208, 89, 23);
		contentPane.add(btnCancelar);
		
		JLabel label_1 = new JLabel("");
		label_1.setBackground(new Color(51, 102, 204));
		label_1.setIcon(new ImageIcon(Acesso.class.getResource("/br/edu/ifcvideira/imgs/Trabalho Final.png")));
		label_1.setBounds(0, 0, 544, 302);
		contentPane.add(label_1);
	}
}
