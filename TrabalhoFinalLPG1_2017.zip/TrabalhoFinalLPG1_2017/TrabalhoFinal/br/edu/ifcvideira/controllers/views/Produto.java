package br.edu.ifcvideira.controllers.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.RowFilter;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import br.edu.ifcvideira.DAOs.ClienteDAO1;
import br.edu.ifcvideira.DAOs.EmpresaDAO;
import br.edu.ifcvideira.DAOs.ProdutoDAO;
import br.edu.ifcvideira.beans.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;

public class Produto extends JFrame {

	private JPanel contentPane;
	private JTextField txtMarca;
	private JTextField txtCustoProduto;
	private JTextField txtDescricao;
	private JTextField txtCodigo;
	
	
	JButton btnCadastro = new JButton("Cadastro");
	JButton btnCadastrar = new JButton("Cadastrar");
	private List<Object> cliente = new ArrayList<Object>();
	private JTextField txtModelo;
	private JTable table;
	private JTextField txtTipo;
	private JTextField txtBuscaNome;
	private JTextField txtBuscaCodigo;
	JButton btnExcluir = new JButton("Excluir");
	JButton btnConcluirAlterar = new JButton("Concluir");
	private JTextField txtMargemLucro;
	private JTextField txtValorVenda;
	JButton btnCancelar_1 = new JButton("Cancelar");
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Produto frame = new Produto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Produto() {
		setTitle("Produto");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Produto.class.getResource("/br/edu/ifcvideira/imgs/logoTX.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 20, 616, 693);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(235, 240, 246));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtDescricao.setEditable(true);
				txtTipo.setEditable(true);
				txtValorVenda.setEditable(true);
				txtMarca.setEditable(true);
				txtModelo.setEditable(true);
				txtCustoProduto.setEditable(true);
				txtBuscaCodigo.setEnabled(false);
				txtBuscaNome.setEnabled(false);
				
				btnCancelar_1.setEnabled(true);
				btnAlterar.setVisible(false);
				btnConcluirAlterar.setVisible(true);
				btnConcluirAlterar.setEnabled(true);
				btnExcluir.setEnabled(false);
				btnCadastro.setEnabled(false);
				
				table.clearSelection();
			}
		});
		
		txtValorVenda = new JTextField();
		txtValorVenda.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {	
					DecimalFormat df = new DecimalFormat("0.00");
					if (table.getSelectedRow()==-1) {
						txtMargemLucro.setText(String.valueOf(df.format(((Double.parseDouble(txtValorVenda.getText()))*100)/(Double.parseDouble(txtCustoProduto.getText()))-100)));
					}
			}
		});
		txtValorVenda.setEditable(false);
		txtValorVenda.setBounds(95, 233, 219, 20);
		contentPane.add(txtValorVenda);
		txtValorVenda.setColumns(10);
		
		txtMargemLucro = new JTextField();
		txtMargemLucro.setForeground(Color.RED);
		txtMargemLucro.setEditable(false);
		txtMargemLucro.setColumns(10);
		txtMargemLucro.setBounds(293, 260, 82, 20);
		contentPane.add(txtMargemLucro);
		btnAlterar.setEnabled(false);
		btnAlterar.setBounds(203, 351, 89, 23);
		contentPane.add(btnAlterar);
		btnConcluirAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProdutoBeans p = new ProdutoBeans();
				ProdutoDAO pd = new ProdutoDAO();
				
				p.setCodigo(Integer.parseInt(txtCodigo.getText()));
				p.setCusto(String.valueOf(txtCustoProduto.getText()));
				p.setDescricao(txtDescricao.getText());
				p.setMarca(txtMarca.getText());
				p.setMargemLucro(String.valueOf((txtMargemLucro.getText())));
				p.setModelo(txtModelo.getText());
				p.setTipo(txtTipo.getText());
				p.setValorVenda(String.valueOf(txtValorVenda.getText()));
				
				try {
					pd.alterar(p);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, e1);
				}
				
				txtDescricao.setEditable(false);
				txtTipo.setEditable(false);
				txtValorVenda.setEditable(false);
				txtMarca.setEditable(false);
				txtModelo.setEditable(false);
				txtCustoProduto.setEditable(false);
				txtMargemLucro.setEditable(false);
				btnConcluirAlterar.setVisible(false);
				btnAlterar.setVisible(true);
				btnExcluir.setEnabled(true);
				btnCadastro.setEnabled(true);
				atualizarTabela();
				
			}
		});
		
		
		btnConcluirAlterar.setBounds(203, 351, 89, 23);
		contentPane.add(btnConcluirAlterar);
		
		JLabel lblCodigo_1 = new JLabel("Codigo");
		lblCodigo_1.setBounds(303, 304, 83, 14);
		contentPane.add(lblCodigo_1);
		
		txtBuscaNome = new JTextField();
		txtBuscaCodigo = new JTextField();
		txtBuscaCodigo.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {
				if (txtBuscaCodigo.getText().equals("")) {
					txtBuscaCodigo.setEditable(true);
					txtBuscaNome.setEditable(true);
				}else {
					txtBuscaCodigo.setEditable(true);
					txtBuscaNome.setEditable(false);
				}
				
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por codigo
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro);
				
				if (txtBuscaCodigo.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter(txtBuscaCodigo.getText(), 0));  
				}  
			}
		});
		txtBuscaCodigo.setColumns(10);
		txtBuscaCodigo.setBounds(380, 301, 137, 20);
		contentPane.add(txtBuscaCodigo);
		
		
		txtBuscaNome.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {
				if (txtBuscaNome.getText().equals("")) {
					txtBuscaCodigo.setEditable(true);
					txtBuscaNome.setEditable(true);
				}else {
					txtBuscaCodigo.setEditable(false);
					txtBuscaNome.setEditable(true);
				}
				
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por nome
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro); 
				
				if (txtBuscaNome.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscaNome.getText(), 1));  
				}  
			}
		});
		txtBuscaNome.setBounds(99, 304, 137, 20);
		contentPane.add(txtBuscaNome);
		txtBuscaNome.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(22, 307, 83, 14);
		contentPane.add(lblNome);
		
		txtTipo = new JTextField();
		txtTipo.setEditable(false);
		txtTipo.setColumns(10);
		txtTipo.setBounds(95, 124, 280, 20);
		contentPane.add(txtTipo);
		
		txtModelo = new JTextField();
		txtModelo.setEditable(false);
		txtModelo.setColumns(10);
		txtModelo.setBounds(95, 202, 219, 20);
		contentPane.add(txtModelo);
		
		JLabel txtsModelo = new JLabel("Modelo");
		txtsModelo.setForeground(Color.BLUE);
		txtsModelo.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtsModelo.setBounds(22, 204, 107, 14);
		contentPane.add(txtsModelo);
		
		JLabel lblMargemLucro = new JLabel("Margem Lucro");
		lblMargemLucro.setForeground(Color.RED);
		lblMargemLucro.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblMargemLucro.setBounds(22, 262, 107, 14);
		contentPane.add(lblMargemLucro);
		
		JLabel lblValorVenda = new JLabel("Valor Venda");
		lblValorVenda.setForeground(Color.BLUE);
		lblValorVenda.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblValorVenda.setBounds(22, 231, 107, 14);
		contentPane.add(lblValorVenda);
		
		JLabel lblMarca = new JLabel("Marca");
		lblMarca.setForeground(Color.BLUE);
		lblMarca.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblMarca.setBounds(22, 177, 98, 14);
		contentPane.add(lblMarca);
		
		JLabel lblDadosProduto = new JLabel("Dados Produto");
		lblDadosProduto.setForeground(Color.GRAY);
		lblDadosProduto.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 17));
		lblDadosProduto.setBounds(22, 25, 353, 14);
		contentPane.add(lblDadosProduto);
		
		txtMarca = new JTextField();
		txtMarca.setEditable(false);
		txtMarca.setColumns(10);
		txtMarca.setBounds(95, 175, 219, 20);
		contentPane.add(txtMarca);
		
		txtCustoProduto = new JTextField();
		txtCustoProduto.setEditable(false);
		txtCustoProduto.setColumns(10);
		txtCustoProduto.setBounds(95, 149, 156, 20);
		contentPane.add(txtCustoProduto);
		
		txtDescricao = new JTextField();
		txtDescricao.setEditable(false);
		txtDescricao.setColumns(10);
		txtDescricao.setBounds(95, 97, 280, 20);
		contentPane.add(txtDescricao);
		
		JLabel lblDescrio = new JLabel("Descri\u00E7\u00E3o");
		lblDescrio.setForeground(Color.BLUE);
		lblDescrio.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblDescrio.setBounds(22, 97, 83, 16);
		contentPane.add(lblDescrio);
		
		JLabel lblTipo = new JLabel("Tipo");
		lblTipo.setForeground(Color.BLUE);
		lblTipo.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTipo.setBounds(22, 125, 83, 16);
		contentPane.add(lblTipo);
		
		JLabel lblCusto = new JLabel("Custo");
		lblCusto.setForeground(Color.BLUE);
		lblCusto.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblCusto.setBounds(22, 152, 83, 16);
		contentPane.add(lblCusto);
		
		JButton btnConcluir = new JButton("Concluir");
		btnConcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnConcluir.setBounds(22, 620, 89, 23);
		contentPane.add(btnConcluir);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancelar.setBounds(124, 620, 89, 23);
		contentPane.add(btnCancelar);
		
		JLabel lblCodigo = new JLabel("Codigo");
		lblCodigo.setForeground(Color.BLUE);
		lblCodigo.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblCodigo.setBounds(22, 71, 83, 16);
		contentPane.add(lblCodigo);
		
		txtCodigo = new JTextField();
		txtCodigo.setEditable(false);
		txtCodigo.setColumns(10);
		txtCodigo.setBounds(95, 71, 83, 20);
		contentPane.add(txtCodigo);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Produto.class.getResource("/br/edu/ifcvideira/imgs/FundoBranco.png")));
		label.setBounds(10, 11, 580, 329);
		contentPane.add(label);
		
		
		btnCadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ProdutoDAO p = new ProdutoDAO();
				
				int i = 0;
				
				try {
					i = p.RetornarProximoCodigoCliente();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				limpaCampos();
				btnAlterar.setEnabled(false);
				btnExcluir.setEnabled(false);
				
				
				txtCodigo.setText(String.valueOf(i));
				txtCustoProduto.setEditable(true);
				txtDescricao.setEditable(true);
				txtMarca.setEditable(true);
				txtMargemLucro.setEditable(false);
				txtModelo.setEditable(true);
				txtValorVenda.setEditable(true);
				txtTipo.setEditable(true);
				
				btnCadastro.setVisible(false);
				btnCadastrar.setVisible(true);
				btnCancelar_1.setEnabled(true);
				
				table.clearSelection();
				
				txtBuscaCodigo.setEditable(false);
				txtBuscaNome.setEditable(false);
				txtBuscaCodigo.setText("");
				txtBuscaNome.setText("");
			}
		});
		btnCadastro.setBounds(104, 351, 89, 23);
		contentPane.add(btnCadastro);
		
		
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (table.getSelectedRow() != -1){
					Object[] options3 = {"Excluir", "Cancelar"};
					if(JOptionPane.showOptionDialog(null, "Tem certeza que deseja excluir o registro:\n>   " 
							+ table.getValueAt(table.getSelectedRow(), 0) + "   -   "
							+ table.getValueAt(table.getSelectedRow(), 1), null,
							JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options3, options3[0]) == 0){
						try {
						ProdutoBeans cb = new ProdutoBeans();
						ProdutoDAO cbd = new ProdutoDAO();
						txtCodigo.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 0)));
						table.clearSelection();
							//atribui��o do valor do campo c�digo para o objeto cliente
							cb.setCodigo(Integer.parseInt(txtCodigo.getText()));
							
							// chamada do m�todo de exclus�o na classe Dao passando como par�metro o c�digo do cliente para ser exclu�do
							cbd.excluir(cb);
							
						
							atualizarTabela();
							txtCustoProduto.setText(null);
							txtDescricao.setText(null);
							txtMarca.setText(null);
							txtMargemLucro.setText(null);
							txtModelo.setText(null);
							txtTipo.setText(null);
							txtCustoProduto.setText(null);
							txtCodigo.setText(null);
							
						} catch (Exception e1) {
							JOptionPane.showMessageDialog(null, e1.getMessage());
						}
					}
				}
				else{
					JOptionPane.showMessageDialog(null, "Nenhuma linha selecionada");
				}
			}
		});
		btnExcluir.setEnabled(false);
		btnExcluir.setBounds(302, 351, 89, 23);
		contentPane.add(btnExcluir);
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ProdutoDAO pd = new ProdutoDAO();
				ProdutoBeans p = new ProdutoBeans();
				
				p.setDescricao(String.valueOf(txtDescricao.getText()));
				p.setCusto(String.valueOf(String.valueOf(txtCustoProduto.getText())));
				p.setMarca(String.valueOf(txtMarca.getText()));
				p.setMargemLucro(String.valueOf(txtMargemLucro.getText()));
				p.setValorVenda(String.valueOf(String.valueOf(txtValorVenda.getText())));
				p.setModelo(String.valueOf(txtModelo.getText()));
				p.setTipo(String.valueOf(txtTipo.getText()));
				
				
				txtCustoProduto.setEditable(false);
				txtDescricao.setEditable(false);
				txtMarca.setEditable(false);
				txtMargemLucro.setEditable(false);
				txtModelo.setEditable(false);
				txtValorVenda.setEditable(false);
				txtTipo.setEditable(false);
				
				btnCadastrar.setVisible(false);
				btnCadastro.setVisible(true);
				
				try {
					pd.cadastrar(p);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, e, "Erro Cadastro", JOptionPane.ERROR_MESSAGE);
				}
				
				atualizarTabela();
				
				txtBuscaCodigo.setEditable(false);
				txtBuscaNome.setEditable(false);
				txtBuscaCodigo.setText("");
				txtBuscaNome.setText("");
			}
		});
		
		
		btnCadastrar.setBounds(95, 351, 98, 23);
		contentPane.add(btnCadastrar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				setCampoTabela();
			}
		});
		scrollPane.setBounds(10, 385, 580, 224);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				limpaCampos();
				setCampoTabela();
				setCamposEnable();
				btnExcluir.setEnabled(true);
				btnAlterar.setEnabled(true);
				btnAlterar.setVisible(true);
				btnConcluirAlterar.setVisible(false);
				btnCancelar_1.setEnabled(true);
				btnCadastrar.setVisible(false);
				btnCadastro.setVisible(true);
				btnCadastro.setEnabled(true);
				
				txtBuscaCodigo.setEditable(true);
				txtBuscaNome.setEditable(true);
				txtCodigo.setEditable(false);
				txtCustoProduto.setEditable(false);
				txtDescricao.setEditable(false);
				txtMarca.setEditable(false);
				txtMargemLucro.setEditable(false);
				txtModelo.setEditable(false);
				txtTipo.setEditable(false);
				txtValorVenda.setEditable(false);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Codigo", "Descri\u00E7\u00E3o", "Tipo", "Marca", "Modelo", "Custo", "Valor Venda", "Margem Lucro"
			}
		));
		scrollPane.setViewportView(table);
		
		
		btnCancelar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtCodigo.setText(null);
				txtBuscaCodigo.setEditable(true);
				txtBuscaNome.setEditable(true);
				txtCodigo.setEditable(false);
				txtCustoProduto.setEditable(false);
				txtDescricao.setEditable(false);
				txtMarca.setEditable(false);
				txtMargemLucro.setEditable(false);
				txtModelo.setEditable(false);
				txtTipo.setEditable(false);
				txtValorVenda.setEditable(false);
				
				btnCadastro.setVisible(true);
				btnCadastro.setEnabled(true);
				btnCadastrar.setVisible(false);
				btnAlterar.setEnabled(true);
				btnExcluir.setEnabled(true);
				btnCancelar_1.setEnabled(true);
				btnConcluirAlterar.setVisible(false);
				btnAlterar.setVisible(true);
				
				txtBuscaCodigo.setEditable(true);
				txtBuscaNome.setEditable(true);
				txtBuscaCodigo.setEnabled(true);
				txtBuscaNome.setEnabled(true);
				txtBuscaCodigo.setText("");
				txtBuscaNome.setText("");
				
				limpaCampos();
			}
		});
		btnCancelar_1.setEnabled(false);
		btnCancelar_1.setBounds(401, 351, 89, 23);
		contentPane.add(btnCancelar_1);
		
		btnCadastrar.setVisible(false);
		btnCadastro.setVisible(true);
		
		atualizarTabela();
	}
	
	public void setCampoTabela() {
		txtCodigo.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 0)));
		txtDescricao.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 1)));
		txtTipo.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 2)));
		txtCustoProduto.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 5)));
		txtMarca.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 3)));
		txtModelo.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 4)));
		txtValorVenda.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 6)));
		txtMargemLucro.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 7)));
	}
	
	public void atualizarTabela() {
		try {
			ProdutoDAO cld = new ProdutoDAO();
			cliente = cld.buscarTodos();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			model.setNumRows(0);
		for (int x=0; x!=cliente.size(); x++)
			{
				model.addRow((Object[]) cliente.get(x));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	
	public void limpaCampos() {
		txtCustoProduto.setText(null);
		txtDescricao.setText(null);
		txtMarca.setText(null);
		txtMargemLucro.setText(null);
		txtValorVenda.setText(null);
		txtModelo.setText(null);
		txtTipo.setText(null);
		txtCustoProduto.setText(null);
		txtValorVenda.setText(null);
		txtCodigo.setText(null);
	}
	
	public void setCamposEnable() {
		txtBuscaCodigo.setEditable(true);
		txtBuscaNome.setEditable(true);
		txtCodigo.setEditable(false);
		txtCustoProduto.setEditable(false);
		txtDescricao.setEditable(false);
		txtMarca.setEditable(false);
		txtMargemLucro.setEditable(false);
		txtModelo.setEditable(false);
		txtTipo.setEditable(false);
		txtValorVenda.setEditable(false);
	}
}
