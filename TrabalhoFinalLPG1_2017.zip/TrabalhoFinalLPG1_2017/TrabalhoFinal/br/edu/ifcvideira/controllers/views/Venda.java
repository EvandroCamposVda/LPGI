package br.edu.ifcvideira.controllers.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import br.edu.ifcvideira.DAOs.ProdutoDAO;
import br.edu.ifcvideira.DAOs.ServicoDAO;
import br.edu.ifcvideira.DAOs.VendaDAO;
import br.edu.ifcvideira.beans.ClienteBeans;
import br.edu.ifcvideira.beans.Produto_Venda;
import br.edu.ifcvideira.beans.Servico_Venda;
import br.edu.ifcvideira.beans.VendaBeans;
import br.edu.ifcvideira.beans.VendaProdutoServicoBeans;

import java.awt.Toolkit;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;

public class Venda extends JFrame {
	
	public static List<Object> servico = new ArrayList<Object>();
	public static List<Object> servico1 = new ArrayList<Object>();
	public static List<Object> salvaTudo = new ArrayList<Object>();
	
	JButton btnAtualizarProduto = new JButton("Atualizar");
	private JPanel contentPane;
	public static JTextField txtCPFEmpresa;
	public static JTextField txtEndereecoEmpresa;
	public static int retornaCodigoVenda = 0;
	private JLabel lblEndereo;
	private JLabel lblDadosCliente;
	private JLabel label_1;
	public static JTextField txtNomeCliente;
	public static JTextField txtCPFCliente;
	private JLabel label_2;
	public static JTextField txtEnderecoCliente;
	private JLabel label_3;
	private JButton btnAdicionarProduto;
	private JButton btnExcluir;
	private JButton btnCancelarProduto;
	private JButton btnApagarProduto;
	private JButton btnCriarNovo;
	private JButton btnCancelar;
	private JButton btnConcluir;
	private JTextField txtCodigoVenda;
	private JTextField txtDataEmissao;
	public static JTextField txtNomeEmpresa;
	private JButton btnTerminar;
	JButton btnBuscarCliente = new JButton("Buscar");
	JButton btnBuscarEmpresa = new JButton("Buscar");
	JButton btnProcurar = new JButton("Procurar");
	private JTable table;
	private JLabel lblValorTotalVenda;
	private JTextField txtValorTotalVenda;
	public static int codigoEmpresa =0 ;
	public static int codigoCliente = 0;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Venda frame = new Venda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Venda() {
		setAutoRequestFocus(false);
		
		btnAdicionarProduto = new JButton("Adicionar");
		btnAdicionarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				RelatorioServicoProduto rs = new RelatorioServicoProduto();
				rs.setVisible(true);
				RelatorioServicoProduto.rdProduto.setSelected(false);
				RelatorioServicoProduto.rdServico.setSelected(false);
				
			}
		});
		btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RelatorioVenda rv = new RelatorioVenda();
				rv.setVisible(true);
				RelatorioVenda.btnApagar.setVisible(true);
			}
		});
		btnCancelarProduto = new JButton("Cancelar");
		btnCancelarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VendaDAO vd = new VendaDAO();
				vd.apagarTabela();
				vd.apagarTabela1();
				atualizaTabelaProduto();
				atualizarValorTotal();
			}
		});
		btnApagarProduto = new JButton("Apagar");
		btnApagarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (String.valueOf(table.getValueAt(table.getSelectedRow(), 3)).equals("Servi�o")){
					int cod;
					int dec = 0;
					cod = Integer.parseInt(String.valueOf(table.getValueAt(table.getSelectedRow(), 1)));
					Servico_Venda sv = new Servico_Venda();
					dec = ((JOptionPane.showConfirmDialog(null, "Deseja realmente apagar este servi�o do pedido ?", "Apagar Servi�o", JOptionPane.YES_NO_OPTION ,JOptionPane.WARNING_MESSAGE)));
					if (dec == 0) {
						VendaDAO vd= new VendaDAO();
						JOptionPane.showMessageDialog(null, cod);
						sv.setIdServico(cod);
						try {
							vd.excluirServico(sv);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					atualizaTabelaProduto();
				}else if (String.valueOf(table.getValueAt(table.getSelectedRow(), 3)).equals("Produto")){
					int cod;
					int dec = 0;
					cod = Integer.parseInt(String.valueOf(table.getValueAt(table.getSelectedRow(), 1)));
					Produto_Venda sv = new Produto_Venda();
					dec = ((JOptionPane.showConfirmDialog(null, "Deseja realmente apagar este Produto do pedido ?", "Apagar Produto", JOptionPane.YES_NO_OPTION ,JOptionPane.WARNING_MESSAGE)));
					if (dec == 0) {
						VendaDAO vd= new VendaDAO();
						JOptionPane.showMessageDialog(null, cod);
						sv.setIdProduto(cod);
						try {
							vd.excluirProduto(sv);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					atualizaTabelaProduto();
				}
			}

		});
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		txtCodigoVenda = new JTextField();
		txtDataEmissao = new JTextField();
		
		setTitle("Venda");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Venda.class.getResource("/br/edu/ifcvideira/imgs/logoTX.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 0, 750, 730);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnCadastrarCliente = new JButton("Cadastrar");
		btnCadastrarCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Cliente frame = new Cliente();
				frame.setVisible(true);
			}
		});
		
		JButton btnCadastrarEmpresa = new JButton("Cadastrar");
		btnCadastrarEmpresa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Empresa frame = new Empresa();
				frame.setVisible(true);
			}
		});
		
		JButton btnCadastrarClient = new JButton("Cadastrar");
		btnCadastrarClient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Cliente cl = new Cliente();
				cl.setVisible(true);
			}
		});
		
		btnTerminar = new JButton("Terminar");
		btnTerminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VendaBeans vb = new VendaBeans();
				VendaDAO vd = new VendaDAO();
				Timestamp timestamp = new Timestamp(System.currentTimeMillis());
				
				if (table.getModel().getRowCount()==0) {
					JOptionPane.showMessageDialog(null, "Favor Selecione um Produto/Servi�o Ou aperte Atualizar", "Erro Produto", JOptionPane.ERROR_MESSAGE);
				}else if (txtValorTotalVenda.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Favor Atualizar a pagina campo valor total n�o esta preenchido !", "Erro", JOptionPane.WARNING_MESSAGE);
				}else {
				txtDataEmissao.setText(String.valueOf(timestamp));
				
				vb.setDataVenda(timestamp);
				vb.setIdEmpresa(codigoEmpresa);
				vb.setIdCliente(codigoCliente);
				vb.setValorTotal(String.valueOf(txtValorTotalVenda.getText()));
				
				VendaProdutoServicoBeans vps = new VendaProdutoServicoBeans();
				
				for (int x=0;x<table.getModel().getRowCount();x++) {
					if (String.valueOf((String.valueOf(table.getValueAt(x, 3)))).equals("Servi�o")){
						
						vps.setIdVenda(Integer.parseInt(String.valueOf(txtCodigoVenda.getText())));
						vps.setIdServico(Integer.parseInt(String.valueOf(table.getValueAt(x, 1))));
						vps.setQuantidade(Integer.parseInt(String.valueOf(table.getValueAt(x, 4))));
						vps.setValor((Double.parseDouble(String.valueOf(table.getValueAt(x, 5)))));
						vps.setValorTotalProduto((Double.parseDouble(String.valueOf(table.getValueAt(x, 6)))));
						
					}else if ((String.valueOf((String.valueOf(table.getValueAt(x, 3)))).equals("Produto"))) {
						vps.setIdVenda(Integer.parseInt(String.valueOf(txtCodigoVenda.getText())));
						vps.setIdProduto(Integer.parseInt(String.valueOf(table.getValueAt(x, 1))));
						vps.setQuantidade(Integer.parseInt(String.valueOf(table.getValueAt(x, 4))));
						vps.setValor((Double.parseDouble(String.valueOf(table.getValueAt(x, 5)))));
						vps.setValorTotalProduto((Double.parseDouble(String.valueOf(table.getValueAt(x, 6)))));
					}
					
					
					try {
						vd.cadastraVendaProdutoServico(vps);
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, e, "Erro Exception cadastraVendaProdutoServico", JOptionPane.ERROR_MESSAGE);
					}
				}
				try {
					vd.cadastrarVenda(vb);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, e, "Erro Exception cadastraVendaProdutoServico", JOptionPane.ERROR_MESSAGE);
				}
				
				JOptionPane.showMessageDialog(null, "Dados Cadastrados com sucesso");
				
				btnAdicionarProduto.setEnabled(false);
				btnApagarProduto.setEnabled(false);
				btnCancelarProduto.setEnabled(false);
				btnCriarNovo.setVisible(true);
				btnTerminar.setVisible(false);
				btnAtualizarProduto.setEnabled(false);
				btnExcluir.setEnabled(true);
				btnConcluir.setEnabled(true);
				btnProcurar.setEnabled(true);
				vd.apagarTabela();
				vd.apagarTabela1();
				dispose();
				Venda frame= new Venda();
				frame.setVisible(true);
				}
			}
		});
		btnCriarNovo = new JButton("Criar Novo");
		
		
		btnCriarNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				btnBuscarCliente.setEnabled(true);
				btnBuscarEmpresa.setEnabled(true);
				btnCadastrarClient.setEnabled(true);
				btnCadastrarEmpresa.setEnabled(true);
				btnCriarNovo.setVisible(false);
				btnTerminar.setVisible(true);
				btnProcurar.setEnabled(false);
				btnConcluir.setEnabled(false);
				btnExcluir.setEnabled(false);
				
				VendaDAO venda = new VendaDAO();
				venda.apagarTabela();
				venda.apagarTabela1();
				Venda.txtNomeCliente.setText(null);
			
				try {
					retornaCodigoVenda = venda.RetornarProximoVenda();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (retornaCodigoVenda == 0) {
					retornaCodigoVenda = 1;
				}
				
				txtCodigoVenda.setText(String.valueOf(retornaCodigoVenda));
			}
		});
		btnCriarNovo.setBounds(284, 646, 106, 23);
		contentPane.add(btnCriarNovo);
		btnTerminar.setBounds(284, 646, 106, 23);
		contentPane.add(btnTerminar);
		btnCadastrarClient.setEnabled(false);
		btnCadastrarClient.setBounds(484, 271, 108, 23);
		contentPane.add(btnCadastrarClient);
		
		txtNomeEmpresa = new JTextField();
		txtNomeEmpresa.setForeground(Color.BLUE);
		txtNomeEmpresa.setEditable(false);
		txtNomeEmpresa.setColumns(10);
		txtNomeEmpresa.setBounds(99, 112, 276, 20);
		contentPane.add(txtNomeEmpresa);
		btnCadastrarEmpresa.setEnabled(false);
		btnCadastrarEmpresa.setBounds(484, 111, 108, 23);
		contentPane.add(btnCadastrarEmpresa);
		
		JLabel lblDadosEmpresa = new JLabel("Dados Empresa");
		lblDadosEmpresa.setBounds(20, 61, 128, 40);
		contentPane.add(lblDadosEmpresa);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(30, 115, 46, 14);
		contentPane.add(lblNome);
		
		txtCPFEmpresa = new JTextField();
		txtCPFEmpresa.setForeground(Color.BLUE);
		txtCPFEmpresa.setEditable(false);
		txtCPFEmpresa.setBounds(99, 138, 276, 20);
		contentPane.add(txtCPFEmpresa);
		txtCPFEmpresa.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("CNPJ/CPF");
		lblNewLabel.setBounds(30, 141, 84, 14);
		contentPane.add(lblNewLabel);
		
		txtEndereecoEmpresa = new JTextField();
		txtEndereecoEmpresa.setForeground(Color.BLUE);
		txtEndereecoEmpresa.setEditable(false);
		txtEndereecoEmpresa.setColumns(10);
		txtEndereecoEmpresa.setBounds(99, 164, 276, 20);
		contentPane.add(txtEndereecoEmpresa);
		
		lblEndereo = new JLabel("Endere\u00E7o");
		lblEndereo.setBounds(30, 167, 84, 14);
		contentPane.add(lblEndereo);
		
		lblDadosCliente = new JLabel("Dados Cliente");
		lblDadosCliente.setBounds(20, 221, 128, 40);
		contentPane.add(lblDadosCliente);
		
		label_1 = new JLabel("Nome");
		label_1.setBounds(30, 275, 46, 14);
		contentPane.add(label_1);
		
		txtNomeCliente = new JTextField();
		txtNomeCliente.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {
				if (txtNomeCliente.getText().equals(null)&&txtNomeEmpresa.getText().equals(null)) {
					
				}else {
					btnAdicionarProduto.setEnabled(true);
					btnApagarProduto.setEnabled(true);
					btnCancelarProduto.setEnabled(true);
				}
			}
		});
		txtNomeCliente.setForeground(Color.BLUE);
		txtNomeCliente.setEditable(false);
		txtNomeCliente.setColumns(10);
		txtNomeCliente.setBounds(99, 272, 276, 20);
		contentPane.add(txtNomeCliente);
		
		txtCPFCliente = new JTextField();
		txtCPFCliente.setForeground(Color.BLUE);
		txtCPFCliente.setEditable(false);
		txtCPFCliente.setColumns(10);
		txtCPFCliente.setBounds(99, 298, 276, 20);
		contentPane.add(txtCPFCliente);
		
		label_2 = new JLabel("CNPJ/CPF");
		label_2.setBounds(30, 301, 84, 14);
		contentPane.add(label_2);
		
		txtEnderecoCliente = new JTextField();
		txtEnderecoCliente.setForeground(Color.BLUE);
		txtEnderecoCliente.setEditable(false);
		txtEnderecoCliente.setColumns(10);
		txtEnderecoCliente.setBounds(99, 324, 276, 20);
		contentPane.add(txtEnderecoCliente);
		
		label_3 = new JLabel("Endere\u00E7o");
		label_3.setBounds(30, 327, 84, 14);
		contentPane.add(label_3);
		
		btnBuscarEmpresa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				RelatorioEmpresa re = new RelatorioEmpresa();
				re.setVisible(true);
				RelatorioEmpresa.btnSelecionar.setVisible(true);
				re.setTitle("Busca Empresa");
			}
		});
		btnBuscarEmpresa.setEnabled(false);
		btnBuscarEmpresa.setBounds(385, 111, 89, 23);
		contentPane.add(btnBuscarEmpresa);
		
		
		btnBuscarCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RelatorioCliente rc = new RelatorioCliente();
				rc.setVisible(true);
				RelatorioCliente.btnSelecionar.setVisible(true);
				rc.setTitle("Busca Cliente");
			}
		});
		btnBuscarCliente.setEnabled(false);
		btnBuscarCliente.setBounds(385, 271, 89, 23);
		contentPane.add(btnBuscarCliente);
		
		JLabel lblAdicionarServios = new JLabel("Adicionar Servi\u00E7os / Produtos");
		lblAdicionarServios.setBounds(20, 389, 340, 14);
		contentPane.add(lblAdicionarServios);
		
		
		btnAdicionarProduto.setEnabled(false);
		btnAdicionarProduto.setBounds(192, 612, 89, 23);
		contentPane.add(btnAdicionarProduto);
		
		
		btnExcluir.setBounds(400, 646, 89, 23);
		contentPane.add(btnExcluir);
		
		
		btnCancelarProduto.setEnabled(false);
		btnCancelarProduto.setBounds(390, 612, 89, 23);
		contentPane.add(btnCancelarProduto);
		
		
		btnApagarProduto.setEnabled(false);
		btnApagarProduto.setBounds(291, 612, 89, 23);
		contentPane.add(btnApagarProduto);
		
		
		btnCancelar.setBounds(499, 646, 89, 23);
		contentPane.add(btnCancelar);
		
		btnConcluir = new JButton("Concluir");
		btnConcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnConcluir.setBounds(185, 646, 89, 23);
		contentPane.add(btnConcluir);
		
		JLabel lblCodigoProduto = new JLabel("Codigo Venda");
		lblCodigoProduto.setBounds(20, 40, 128, 14);
		contentPane.add(lblCodigoProduto);
		
		
		txtCodigoVenda.setEditable(false);
		txtCodigoVenda.setBounds(113, 37, 86, 20);
		contentPane.add(txtCodigoVenda);
		txtCodigoVenda.setColumns(10);
		
		JLabel tlblDataDeEmisso = new JLabel("Data de Emiss\u00E3o");
		tlblDataDeEmisso.setBounds(426, 40, 128, 14);
		contentPane.add(tlblDataDeEmisso);
		
		
		txtDataEmissao.setEditable(false);
		txtDataEmissao.setColumns(10);
		txtDataEmissao.setBounds(538, 37, 172, 20);
		contentPane.add(txtDataEmissao);
		btnProcurar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RelatorioVenda rv = new RelatorioVenda();
				rv.setVisible(true);
			}
		});
		
		
		btnProcurar.setBounds(86, 646, 89, 23);
		contentPane.add(btnProcurar);
		
		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon(Venda.class.getResource("/br/edu/ifcvideira/imgs/FundoBranco.png")));
		label_4.setBounds(10, 229, 714, 139);
		contentPane.add(label_4);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Venda.class.getResource("/br/edu/ifcvideira/imgs/FundoBranco.png")));
		label.setBounds(10, 11, 714, 199);
		contentPane.add(label);
		
		
		btnAtualizarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				atualizaTabelaProduto();
				atualizarValorTotal();
				atualizarValorTotal();
				
			}
		});
		btnAtualizarProduto.setBounds(635, 385, 89, 23);
		contentPane.add(btnAtualizarProduto);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 414, 714, 168);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				atualizarValorTotal();
				
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Codigo Venda","Codigo Produto", "Produto", "Tipo", "Quantidade", "Valor Produto", "Valor Total"
			}
		));
		scrollPane.setViewportView(table);
		
		lblValorTotalVenda = new JLabel("Valor Total Venda");
		lblValorTotalVenda.setBounds(484, 599, 115, 14);
		contentPane.add(lblValorTotalVenda);
		
		txtValorTotalVenda = new JTextField();
		txtValorTotalVenda.setForeground(Color.RED);
		txtValorTotalVenda.setHorizontalAlignment(SwingConstants.TRAILING);
		txtValorTotalVenda.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {
				atualizarValorTotal();
			}
		});
		txtValorTotalVenda.setEditable(false);
		txtValorTotalVenda.setBounds(596, 596, 128, 20);
		contentPane.add(txtValorTotalVenda);
		txtValorTotalVenda.setColumns(10);
	}

	public int getIdVn() {
		int i = Integer.parseInt(txtCodigoVenda.getText());
		return i;
	}
	
	public void atualizaTabelaProduto() {
		try {
			VendaDAO cld = new VendaDAO();
			servico = cld.buscarProdutosVenda();
			servico1 = cld.buscarServicoVenda();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			model.setNumRows(0);
		for (int x=0; x!=servico.size(); x++){
				model.addRow((Object[]) servico.get(x));
			}
		for (int x=0; x!=servico1.size(); x++){
			model.addRow((Object[]) servico1.get(x));
		}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	
	public void atualizarValorTotal() {
		double calc1;
		double calc2 = 0;
		
		for (int x=0;x<table.getModel().getRowCount();x++) {
			calc1 = ((Double.parseDouble((String.valueOf(table.getValueAt(x, 6))))));
			calc2 = calc1 + calc2;
		}
		txtValorTotalVenda.setText(String.valueOf(calc2));
	}
}
