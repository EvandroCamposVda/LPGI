package br.edu.ifcvideira.controllers.views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.edu.ifcvideira.DAOs.ServicoDAO;
import br.edu.ifcvideira.beans.ServicosBeans;

import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.RowFilter;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Servicos extends JFrame {

	private JPanel contentPane;
	private JTextField txtValorVenda;
	private JTextField txtCusto;
	private JTextField txtCodigo;
	private JTextField txtDescricao;
	JButton btnCadastrar = new JButton("Cadastrar");
	JButton btnCadastro = new JButton("Cadastro");
	private JTextField txtMargemLucro;
	private JTable table;
	private JTextField txtBuscaCodigo;
	private JTextField txtBuscaNome;;
	private JTextField txtTipo;
	JButton btnCancelar = new JButton("Cancelar");
	JButton btnExcluir = new JButton("Excluir");
	JButton btnAlterar = new JButton("Alterar");
	JButton button_1 = new JButton("Concluir");
	JButton button = new JButton("Cancelar");
	private List<Object> servico = new ArrayList<Object>();
	JButton btnConcluirAlterar = new JButton("Concluir");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Servicos frame = new Servicos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Servicos() {
		
		
		setTitle("Servi\u00E7os");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Servicos.class.getResource("/br/edu/ifcvideira/imgs/logoTX.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 60, 623, 637);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAlterar.setVisible(false);
				btnConcluirAlterar.setVisible(true);
				btnCadastro.setVisible(true);
				btnCadastro.setEnabled(false);
				btnExcluir.setEnabled(false);
				
				table.clearSelection();
				
				txtDescricao.setEditable(true);
				txtTipo.setEditable(true);
				txtCusto.setEditable(true);
				txtValorVenda.setEditable(true);
				txtBuscaCodigo.setEditable(false);
				txtBuscaNome.setEditable(false);
				
			}
		});
		
		
		btnAlterar.setEnabled(false);
		btnAlterar.setBounds(199, 282, 89, 23);
		contentPane.add(btnAlterar);
		btnConcluirAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ServicoDAO sd = new ServicoDAO();
				ServicosBeans sb = new ServicosBeans();
				
				sb.setCodigo(Integer.parseInt(txtCodigo.getText()));
				sb.setCusto(txtCusto.getText());
				sb.setDescricao(txtDescricao.getText());
				sb.setMargemLucro(txtMargemLucro.getText());
				sb.setTipo(txtTipo.getText());
				sb.setValorVenda(txtValorVenda.getText());
				
				try {
					sd.alterar(sb);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				atualizarTabela();
				btnCadastro.setEnabled(true);
				btnCadastro.setVisible(true);
				btnConcluirAlterar.setVisible(false);
				btnAlterar.setEnabled(false);
				btnAlterar.setVisible(true);
				btnExcluir.setEnabled(false);
				
				txtDescricao.setEditable(false);
				txtTipo.setEditable(false);
				txtCusto.setEditable(false);
				txtValorVenda.setEditable(false);
				txtBuscaCodigo.setEditable(true);
				txtBuscaNome.setEditable(true);
				
			}
		});
		
		
		btnConcluirAlterar.setBounds(199, 282, 89, 23);
		contentPane.add(btnConcluirAlterar);
		
		txtBuscaCodigo = new JTextField();
		txtBuscaCodigo.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				if (txtBuscaCodigo.getText().equals("")) {
					txtBuscaCodigo.setEditable(true);
					txtBuscaNome.setEditable(true);
				}else {
					txtBuscaCodigo.setEditable(true);
					txtBuscaNome.setEditable(false);
				}
				
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por codigo
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro);
				
				if (txtBuscaCodigo.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter(txtBuscaCodigo.getText(), 0));  
				}  
			}
		});
		txtBuscaCodigo.setColumns(10);
		txtBuscaCodigo.setBounds(379, 228, 137, 20);
		contentPane.add(txtBuscaCodigo);
		
		txtBuscaNome = new JTextField();
		txtBuscaNome.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {
				if (txtBuscaNome.getText().equals("")) {
					txtBuscaCodigo.setEditable(true);
					txtBuscaNome.setEditable(true);
				}else {
					txtBuscaCodigo.setEditable(false);
					txtBuscaNome.setEditable(true);
				}
				
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por nome
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro); 
				
				if (txtBuscaNome.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscaNome.getText(), 1));  
				}  
			}
		});
		txtBuscaNome.setColumns(10);
		txtBuscaNome.setBounds(98, 231, 137, 20);
		contentPane.add(txtBuscaNome);
		
		JLabel label_2 = new JLabel("Codigo");
		label_2.setBounds(302, 231, 83, 14);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("Nome");
		label_3.setBounds(21, 234, 83, 14);
		contentPane.add(label_3);
		txtTipo = new JTextField();
		
		
		txtTipo.setEditable(false);
		txtTipo.setColumns(10);
		txtTipo.setBounds(94, 110, 156, 20);
		contentPane.add(txtTipo);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		
		button.setBounds(123, 571, 89, 23);
		contentPane.add(button);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		
		button_1.setBounds(21, 571, 89, 23);
		contentPane.add(button_1);
		
		
		btnCadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtCusto.setEditable(true);
				txtDescricao.setEditable(true);
				txtValorVenda.setEditable(true);
				txtTipo.setEditable(true);
				txtBuscaCodigo.setEditable(false);
				txtBuscaNome.setEditable(false);
				
				btnCadastro.setVisible(false);
				btnCadastrar.setVisible(true);
				btnCancelar.setEnabled(true);
				btnAlterar.setEnabled(false);
				btnExcluir.setEnabled(false);
				
				table.clearSelection();
				
				txtBuscaCodigo.setText(null);
				txtBuscaNome.setText(null);
				txtCodigo.setText(null);
				txtCusto.setText(null);
				txtTipo.setText(null);
				txtDescricao.setText(null);
				txtValorVenda.setText(null);
				txtMargemLucro.setText(null);
				
				int i = 0;
				ServicoDAO sd = new ServicoDAO();
				try {
					i = sd.RetornarProximoCodigoCliente();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				txtMargemLucro.setText(null);
				txtCodigo.setText(String.valueOf(i));
			}
		});
		btnCadastro.setBounds(100, 282, 89, 23);
		contentPane.add(btnCadastro);
		
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ServicoDAO sd = new ServicoDAO();
				ServicosBeans sb = new ServicosBeans();
				
				sb.setCodigo(Integer.parseInt(txtCodigo.getText()));
				
				try {
					sd.excluir(sb);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1, "Erro ao excluir", JOptionPane.ERROR_MESSAGE);
				}
				atualizarTabela();
			}
		});
		
		
		btnExcluir.setEnabled(false);
		btnExcluir.setBounds(298, 282, 89, 23);
		contentPane.add(btnExcluir);
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCadastrar.setVisible(false);
				btnCadastro.setVisible(true);
				btnAlterar.setEnabled(false);
				btnExcluir.setEnabled(false);
				
				txtCusto.setEditable(false);
				txtDescricao.setEditable(false);
				txtValorVenda.setEditable(false);
				txtTipo.setEditable(false);
				txtBuscaCodigo.setEditable(true);
				txtBuscaNome.setEditable(true);
				
				table.clearSelection();
				
				txtBuscaCodigo.setText(null);
				txtBuscaNome.setText(null);
				txtCodigo.setText(null);
				txtCusto.setText(null);
				txtTipo.setText(null);
				txtDescricao.setText(null);
				txtValorVenda.setText(null);
				txtMargemLucro.setText(null);
			}
		});
		
		
		btnCancelar.setBounds(397, 282, 89, 23);
		contentPane.add(btnCancelar);
		
		txtMargemLucro = new JTextField();
		txtMargemLucro.setText("0");
		txtMargemLucro.setForeground(Color.RED);
		txtMargemLucro.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtMargemLucro.setEditable(false);
		txtMargemLucro.setColumns(10);
		txtMargemLucro.setBounds(240, 197, 141, 20);
		contentPane.add(txtMargemLucro);
		
		JLabel label = new JLabel("Margem Lucro");
		label.setForeground(Color.RED);
		label.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label.setBounds(21, 201, 107, 14);
		contentPane.add(label);
		
		txtValorVenda = new JTextField();
		txtValorVenda.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {
			if (table.getSelectedRow()==-1) {
				
				double calc;
				double custo;
				double venda;
				DecimalFormat df = new DecimalFormat("0.00");
				
				
				custo = Double.parseDouble(txtCusto.getText());
				venda = Double.parseDouble(txtValorVenda.getText());
				
				calc = (venda*100/custo)-100;
				
				txtMargemLucro.setText(String.valueOf(df.format(calc)));
				
			}
			}
		});
		txtValorVenda.setEditable(false);
		txtValorVenda.setColumns(10);
		txtValorVenda.setBounds(94, 163, 156, 20);
		contentPane.add(txtValorVenda);
		
		JLabel label_1 = new JLabel("Valor Venda");
		label_1.setForeground(Color.BLUE);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_1.setBounds(21, 165, 107, 14);
		contentPane.add(label_1);
		
		txtCusto = new JTextField();
		txtCusto.setEditable(false);
		txtCusto.setColumns(10);
		txtCusto.setBounds(94, 135, 156, 20);
		contentPane.add(txtCusto);
		
		JLabel label_4 = new JLabel("Custo");
		label_4.setForeground(Color.BLUE);
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_4.setBounds(21, 136, 83, 16);
		contentPane.add(label_4);
		
		txtCodigo = new JTextField();
		txtCodigo.setEditable(false);
		txtCodigo.setColumns(10);
		txtCodigo.setBounds(94, 57, 83, 20);
		contentPane.add(txtCodigo);
		
		JLabel label_5 = new JLabel("Codigo");
		label_5.setForeground(Color.BLUE);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_5.setBounds(21, 57, 83, 16);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("Descri\u00E7\u00E3o");
		label_6.setForeground(Color.BLUE);
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_6.setBounds(21, 83, 83, 16);
		contentPane.add(label_6);
		
		JLabel label_7 = new JLabel("Tipo");
		label_7.setForeground(Color.BLUE);
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_7.setBounds(21, 111, 83, 16);
		contentPane.add(label_7);
		
		txtDescricao = new JTextField();
		txtDescricao.setEditable(false);
		txtDescricao.setColumns(10);
		txtDescricao.setBounds(94, 83, 280, 20);
		contentPane.add(txtDescricao);
		
		JLabel lblDadosServios = new JLabel("Dados Servi\u00E7os");
		lblDadosServios.setForeground(Color.GRAY);
		lblDadosServios.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 17));
		lblDadosServios.setBounds(21, 22, 353, 14);
		contentPane.add(lblDadosServios);
		
		JLabel label_8 = new JLabel("");
		label_8.setIcon(new ImageIcon(Servicos.class.getResource("/br/edu/ifcvideira/imgs/FundoBranco.png")));
		label_8.setBounds(10, 11, 587, 257);
		contentPane.add(label_8);
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ServicosBeans sb = new ServicosBeans();
				ServicoDAO sd = new ServicoDAO();
				
				table.clearSelection();
				sb.setDescricao(txtDescricao.getText());
				sb.setCusto(String.valueOf(txtCusto.getText()));
				sb.setValorVenda(String.valueOf(txtValorVenda.getText()));
				sb.setTipo(txtTipo.getText());
				sb.setMargemLucro(txtMargemLucro.getText());
				
				try {
					sd.cadastrar(sb);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				
				atualizarTabela();
				
				txtCusto.setEditable(false);
				txtDescricao.setEditable(false);
				txtValorVenda.setEditable(false);
				txtTipo.setEditable(false);
				
				btnCadastro.setVisible(true);
				btnCadastrar.setVisible(false);
				
				txtTipo.setText(null);
				txtCodigo.setText(null);
				txtCusto.setText(null);
				txtDescricao.setText(null);
				txtMargemLucro.setText(null);
				txtValorVenda.setText(null);
			
			}
		});
		
		
		btnCadastrar.setBounds(88, 282, 101, 23);
		contentPane.add(btnCadastrar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 316, 587, 244);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				setCampoTabela();
				
				btnAlterar.setEnabled(true);
				btnAlterar.setVisible(true);
				btnExcluir.setEnabled(true);
				btnConcluirAlterar.setVisible(false);
				
				
				txtBuscaCodigo.setEditable(true);
				txtBuscaNome.setEditable(true);
				txtCodigo.setEditable(false);
				txtCusto.setEditable(false);
				txtDescricao.setEditable(false);
				txtMargemLucro.setEditable(false);
				txtTipo.setEditable(false);
				txtValorVenda.setEditable(false);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Codigo", "Descri��o", "Tipo", "Custo", "Valor Venda", "Margem Lucro"
			}
		));
		scrollPane.setViewportView(table);
		
		btnCadastro.setVisible(true);
		btnCadastrar.setVisible(false);
		atualizarTabela();
	}
	
	public void setCampoTabela() {
		txtCodigo.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 0)));
		txtDescricao.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 1)));
		txtTipo.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 2)));
		txtCusto.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 3)));
		txtValorVenda.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 4)));
		txtMargemLucro.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 5)));
	}
	
	public void atualizarTabela() {
		try {
			ServicoDAO cld = new ServicoDAO();
			servico = cld.buscarTodos();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			model.setNumRows(0);
		for (int x=0; x!=servico.size(); x++)
			{
				model.addRow((Object[]) servico.get(x));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
}
