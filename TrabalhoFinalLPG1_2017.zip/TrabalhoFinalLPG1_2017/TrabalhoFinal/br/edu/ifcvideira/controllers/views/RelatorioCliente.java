package br.edu.ifcvideira.controllers.views;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import br.edu.ifcvideira.DAOs.ClienteDAO1;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.RowFilter;

import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;

public class RelatorioCliente extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField txtBuscaNome;
	private JTextField txtBuscaCPF;
	public static JButton btnSelecionar = new JButton("Selecionar");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RelatorioCliente frame = new RelatorioCliente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RelatorioCliente() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(RelatorioCliente.class.getResource("/br/edu/ifcvideira/imgs/logoTX.png")));
		setTitle("Busca Clientes");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 883, 430);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
					"C\u00F3digo", "Nome", "CNPJ/CPF", "Inscri\u00E7\u00E3o", "RG", "Telefone", "Rua", "Bairro", "Cidade", "Estado", "CEP", "Pais"
			}
		));
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 61, 825, 274);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
					"C\u00F3digo", "Nome", "CNPJ/CPF", "Inscri\u00E7\u00E3o", "RG", "Telefone", "Rua", "Bairro", "Cidade", "Estado", "CEP", "Pais"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSair.setBounds(758, 357, 89, 23);
		contentPane.add(btnSair);
		btnSelecionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome;
				String cnpj;
				String endereco;
				int cod;
				
				cod = Integer.parseInt(String.valueOf(table.getValueAt(table.getSelectedRow(), 0)));
				Venda.codigoCliente = cod;
				
				nome = String.valueOf(table.getValueAt(table.getSelectedRow(), 1));
				Venda.txtNomeCliente.setText(nome);
				
				cnpj = String.valueOf(table.getValueAt(table.getSelectedRow(), 2));
				Venda.txtCPFCliente.setText(cnpj);
				
				endereco = (String.valueOf(table.getValueAt(table.getSelectedRow(), 6))+ ", " + String.valueOf(table.getValueAt(table.getSelectedRow(), 7))+ ", "+ String.valueOf(table.getValueAt(table.getSelectedRow(), 8)));
				Venda.txtEnderecoCliente.setText(endereco);
				dispose();
			}
		});
		btnSelecionar.setBounds(645, 357, 103, 23);
		contentPane.add(btnSelecionar);
		
		JLabel lblBuscaNome = new JLabel("Busca Nome");
		lblBuscaNome.setBounds(34, 36, 72, 14);
		contentPane.add(lblBuscaNome);
		
		txtBuscaNome = new JTextField();
		txtBuscaNome.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {
				if(txtBuscaNome.getText().equals("")) {
					txtBuscaCPF.setEditable(true);
					txtBuscaNome.setEditable(true);
				}else if (txtBuscaNome.getText()!="") {
					txtBuscaCPF.setEditable(false);
					txtBuscaNome.setEditable(true);
				}
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por nome
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro); 
				
				if (txtBuscaNome.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscaNome.getText(), 1));  
				}  
			}
		});
		txtBuscaNome.setBounds(116, 33, 152, 20);
		contentPane.add(txtBuscaNome);
		txtBuscaNome.setColumns(10);
		
		JLabel lblBuscaCnpjcpf = new JLabel("Busca CNPJ/CPF");
		lblBuscaCnpjcpf.setBounds(354, 36, 109, 14);
		contentPane.add(lblBuscaCnpjcpf);
		
		txtBuscaCPF = new JTextField();
		txtBuscaCPF.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				if(txtBuscaCPF.getText().equals("")) {
					txtBuscaCPF.setEditable(true);
					txtBuscaNome.setEditable(true);
				}else if (txtBuscaCPF.getText()!="") {
					txtBuscaCPF.setEditable(true);
					txtBuscaNome.setEditable(false);
				}
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por nome
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro); 
				
				if (txtBuscaCPF.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscaCPF.getText(), 2));  
				}  
			}
		});
		txtBuscaCPF.setBounds(460, 33, 152, 20);
		contentPane.add(txtBuscaCPF);
		txtBuscaCPF.setColumns(10);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(RelatorioCliente.class.getResource("/br/edu/ifcvideira/imgs/FundoBranco.png")));
		label.setForeground(Color.WHITE);
		label.setBounds(10, 11, 848, 336);
		contentPane.add(label);
		atualizarTabela();
		btnSelecionar.setVisible(false);
	}
	
	public void atualizarTabela() {
		try {
			ClienteDAO1 cld = new ClienteDAO1();
			List<Object> cliente = cld.buscarTodos();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			model.setNumRows(0);
		for (int x=0; x!=cliente.size(); x++)
			{
				model.addRow((Object[]) cliente.get(x));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	}

