package br.edu.ifcvideira.controllers.views;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.JobAttributes;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import br.edu.ifcvideira.DAOs.ProdutoDAO;
import br.edu.ifcvideira.DAOs.ServicoDAO;
import br.edu.ifcvideira.DAOs.VendaDAO;
import br.edu.ifcvideira.beans.Produto_Venda;
import br.edu.ifcvideira.beans.Servico_Venda;
import br.edu.ifcvideira.beans.VendaBeans;

import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.SwingConstants;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;

public class RelatorioServicoProduto extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTable table;
	private JTable table_1;
	public static List<Object> servico = new ArrayList<Object>();
	public static List<Object> produto = new ArrayList<Object>();
	private JTable tabela;
	int codigoServico;
	public static int confereDados;
	public static String tipoServico;
	public static String custoServico;
	public static String valorVendaServico;
	public static String margemLucroServico;
	public static JRadioButton rdProduto = new JRadioButton("Produto");
	public static JRadioButton rdServico = new JRadioButton("Servi\u00E7o");
	public static JTextField txtQuantidade;
	public static  JTextField txtBuscaProdNom;
	public static  JTextField txtBuscaProdutoCo;
	public static  JTextField txtBuscaServNom;
	public static  JTextField txtBuscaServCod;
	public static JButton btnSelecionar = new JButton("Selecionar");
	public static JLabel lblQuantidade = new JLabel("Quantidade");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RelatorioServicoProduto frame = new RelatorioServicoProduto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RelatorioServicoProduto() {
		setTitle("Servi\u00E7o/Produto");
		setIconImage(Toolkit.getDefaultToolkit().getImage(RelatorioServicoProduto.class.getResource("/br/edu/ifcvideira/imgs/logoTX.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 0, 847, 730);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		rdServico.setBackground(Color.WHITE);
		
		
		rdServico.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				atualizarTabelaServico();
				table_1.setVisible(false);
				table.setVisible(true);
				txtBuscaProdNom.setEditable(false);
				txtBuscaProdutoCo.setEditable(false);
				txtQuantidade.setEditable(true);
				txtBuscaServCod.setEditable(true);
				txtBuscaServNom.setEditable(true);
				btnSelecionar.setEnabled(true);
			}
		});
		buttonGroup.add(rdServico);
		rdServico.setBounds(20, 345, 109, 23);
		contentPane.add(rdServico);
		rdProduto.setBackground(Color.WHITE);
		
		
		rdProduto.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				atualizarTabelaProduto();
				table_1.setVisible(true);
				table.setVisible(false);
				txtBuscaProdNom.setEditable(true);
				txtBuscaProdutoCo.setEditable(true);
				txtQuantidade.setEditable(true);
				txtBuscaServCod.setEditable(false);
				txtBuscaServNom.setEditable(false);
				btnSelecionar.setEnabled(true);
			}
		});
		buttonGroup.add(rdProduto);
		rdProduto.setBounds(20, 22, 109, 23);
		contentPane.add(rdProduto);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 379, 786, 235);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C�digo", "Descri��o", "Tipo", "Custo", "Valor Venda", "Margem Lucro"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnSair.setBounds(717, 664, 89, 23);
		contentPane.add(btnSair);
		
		
		btnSelecionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			if (txtQuantidade.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "Favor Preencher a quantidade", "Erro Quantidade", JOptionPane.ERROR_MESSAGE);
			}else {
				
				
				if (rdProduto.isSelected()) {
				
				VendaDAO vendas = new VendaDAO();
				Produto_Venda vd = new Produto_Venda();
				DecimalFormat df = new DecimalFormat("0.00");
				double calc;
				
				vd.setIdProduto(Integer.parseInt(String.valueOf(table_1.getValueAt(table_1.getSelectedRow(), 0))));
				vd.setIdVenda(Venda.retornaCodigoVenda);
				vd.setQuantidade(Integer.parseInt(txtQuantidade.getText()));
				vd.setValorProduto(Double.parseDouble(String.valueOf(table_1.getValueAt(table_1.getSelectedRow(), 6))));
				calc = (Double.parseDouble((String.valueOf(table_1.getValueAt(table_1.getSelectedRow(), 6)))))*Double.parseDouble(txtQuantidade.getText());
				vd.setValorTotalProduto((calc));
				vd.setTipo("Produto");
				vd.setNomeProduto(String.valueOf(table_1.getValueAt(table_1.getSelectedRow(), 1)));
				
				vendas.insereProduto(vd);
				
				try {
					vendas.buscarProdutosVenda();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Venda vde = new Venda();
				vde.atualizaTabelaProduto();
				
			}else if (rdServico.isSelected()) {
				VendaDAO vendas = new VendaDAO();
				Servico_Venda sv= new Servico_Venda();
				double calc;
				
				sv.setIdServico(Integer.parseInt(String.valueOf(table.getValueAt(table.getSelectedRow(), 0))));
				sv.setIdVenda(Venda.retornaCodigoVenda);
				sv.setQuantidade(Integer.parseInt(txtQuantidade.getText()));
				sv.setValorServico(Double.parseDouble(String.valueOf(table.getValueAt(table.getSelectedRow(), 4))));
				calc = (Double.parseDouble((String.valueOf(table.getValueAt(table.getSelectedRow(), 4)))))*Double.parseDouble(txtQuantidade.getText());
				sv.setValorTotalServico(calc);
				sv.setTipo("Servi�o");
				sv.setNomeServico(String.valueOf(table.getValueAt(table.getSelectedRow(), 1)));
				
				vendas.insereServico(sv);
				
				try {
					vendas.buscarServicoVenda();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Venda vde = new Venda();
				vde.atualizaTabelaProduto();
			}
				
			dispose();
			}
			}
		});
		btnSelecionar.setBounds(603, 664, 104, 23);
		contentPane.add(btnSelecionar);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(20, 56, 786, 235);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
					"Codigo", "Descri\u00E7\u00E3o", "Tipo", "Marca", "Modelo", "Custo", "Valor Venda", "Margem Lucro"
			}
		));
		
		
		lblQuantidade.setBounds(568, 639, 139, 14);
		contentPane.add(lblQuantidade);
		
		txtQuantidade = new JTextField();
		txtQuantidade.setHorizontalAlignment(SwingConstants.TRAILING);
		txtQuantidade.setBounds(720, 636, 86, 20);
		contentPane.add(txtQuantidade);
		txtQuantidade.setColumns(10);
		
		JLabel lblNome = new JLabel("Descri\u00E7\u00E3o");
		lblNome.setBounds(145, 26, 74, 14);
		contentPane.add(lblNome);
		
		txtBuscaProdNom = new JTextField();
		txtBuscaProdNom.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {

				if (txtBuscaProdNom.getText().equals("")) {
					txtBuscaProdutoCo.setEditable(true);
					txtBuscaProdNom.setEditable(true);
				}else {
					txtBuscaProdutoCo.setEditable(false);
					txtBuscaProdNom.setEditable(true);
				}
				
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por nome
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table_1.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table_1.setRowSorter(filtro); 
				
				if (txtBuscaProdNom.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscaProdNom.getText(), 1));  
				}  
			}
		});
		txtBuscaProdNom.setBounds(217, 23, 117, 20);
		contentPane.add(txtBuscaProdNom);
		txtBuscaProdNom.setColumns(10);
		
		txtBuscaProdutoCo = new JTextField();
		txtBuscaProdutoCo.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				if (txtBuscaProdutoCo.getText().equals("")) {
					txtBuscaProdutoCo.setEditable(true);
					txtBuscaProdNom.setEditable(true);
				}else {
					txtBuscaProdutoCo.setEditable(true);
					txtBuscaProdNom.setEditable(false);
				}
				
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por codigo
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table_1.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table_1.setRowSorter(filtro);
				
				if (txtBuscaProdutoCo.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter(txtBuscaProdutoCo.getText(), 0));  
				}  
			}
		});
		txtBuscaProdutoCo.setColumns(10);
		txtBuscaProdutoCo.setBounds(409, 22, 117, 20);
		contentPane.add(txtBuscaProdutoCo);
		
		JLabel lblCodigo = new JLabel("Codigo");
		lblCodigo.setBounds(357, 26, 74, 14);
		contentPane.add(lblCodigo);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(RelatorioServicoProduto.class.getResource("/br/edu/ifcvideira/imgs/FundoBranco.png")));
		label.setBounds(10, 11, 811, 295);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Descri\u00E7\u00E3o");
		label_1.setBounds(145, 349, 74, 14);
		contentPane.add(label_1);
		
		txtBuscaServNom = new JTextField();
		txtBuscaServNom.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {

				if (txtBuscaServNom.getText().equals("")) {
					txtBuscaServCod.setEditable(true);
					txtBuscaServNom.setEditable(true);
				}else {
					txtBuscaServCod.setEditable(false);
					txtBuscaServNom.setEditable(true);
				}
				
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por nome
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro); 
				
				if (txtBuscaServNom.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscaServNom.getText(), 1));  
				}  
			}
		});
		txtBuscaServNom.setColumns(10);
		txtBuscaServNom.setBounds(217, 346, 130, 20);
		contentPane.add(txtBuscaServNom);
		
		JLabel label_2 = new JLabel("Codigo");
		label_2.setBounds(357, 349, 74, 14);
		contentPane.add(label_2);
		
		txtBuscaServCod = new JTextField();
		txtBuscaServCod.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				if (txtBuscaServCod.getText().equals("")) {
					txtBuscaServCod.setEditable(true);
					txtBuscaServNom.setEditable(true);
				}else {
					txtBuscaServCod.setEditable(true);
					txtBuscaServNom.setEditable(false);
				}
				
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por codigo
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro);
				
				if (txtBuscaServCod.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter(txtBuscaServCod.getText(), 0));  
				}  
			}
		});
		txtBuscaServCod.setColumns(10);
		txtBuscaServCod.setBounds(409, 345, 117, 20);
		contentPane.add(txtBuscaServCod);
		
		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(RelatorioServicoProduto.class.getResource("/br/edu/ifcvideira/imgs/FundoBranco.png")));
		label_3.setBounds(10, 330, 811, 298);
		contentPane.add(label_3);
		txtBuscaProdNom.setEditable(false);
		txtBuscaProdutoCo.setEditable(false);
		txtQuantidade.setEditable(false);
		txtBuscaServCod.setEditable(false);
		txtBuscaServNom.setEditable(false);
		btnSelecionar.setEnabled(false);
	}
	
	public void atualizarTabelaServico() {
		try {
			ServicoDAO cld = new ServicoDAO();
			servico = cld.buscarTodos();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			model.setNumRows(0);
		for (int x=0; x!=servico.size(); x++)
			{
				model.addRow((Object[]) servico.get(x));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	
	public void atualizarTabelaProduto() {
		try {
			ProdutoDAO cld = new ProdutoDAO();
			produto = cld.buscarTodos();
			DefaultTableModel model = (DefaultTableModel) table_1.getModel();
			model.setNumRows(0);
		for (int x=0; x!=produto.size(); x++)
			{
				model.addRow((Object[]) produto.get(x));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	
	public void jogaDadosServico() {
		
	}
}
