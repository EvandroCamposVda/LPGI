package br.edu.ifcvideira.controllers.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTextPane;
import javax.swing.RowFilter;

import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import br.edu.ifcvideira.DAOs.ClienteDAO1;
import br.edu.ifcvideira.beans.ClienteBeans;

import javax.swing.border.BevelBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;

public class Cliente extends JFrame {

	private JPanel contentPane;
	private JTextField txtBairro;
	private JTextField txtEstado;
	private JTextField txtTelefone;
	private JTextField txtInscricao;
	private JTextField txtCidade;
	private JTextField txtCep;
	private JTextField txtEndereco;
	private JTextField txtCnpj;
	private JTextField txtEmpresa;
	private JTextField txtCodigo;
	String msg = "";
	JButton btnCadastro = new JButton("Cadastro");
	JButton btnCadastrar = new JButton("Cadastrar");
	JButton btnExcluir = new JButton("Excluir");
	JButton btnAlterar = new JButton("Alterar");
	private int cod;
	private JTextField txtRG;
	private JTable table;
	private JTextField txtBuscar;
	private List<Object> cliente = new ArrayList<Object>();
	JButton btnConcluir_1 = new JButton("Concluir");
	private JTextField txtPais;
	JComboBox comboBox_1 = new JComboBox();
	private JTextField txtBuscaCodigo;
	JLabel lblRG = new JLabel("RG");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cliente frame = new Cliente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cliente() {
		setBackground(new Color(51, 204, 153));
		setIconImage(Toolkit.getDefaultToolkit().getImage(Cliente.class.getResource("/br/edu/ifcvideira/imgs/logoTX.png")));
		setTitle("Cliente");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 20, 637, 687);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnCadastrar_1 = new JButton("Cadastrar");
		btnCadastrar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClienteBeans cl = new ClienteBeans();
				ClienteDAO1 cld = new ClienteDAO1();
				
				if (txtEmpresa.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha o nome do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else if ((comboBox_1.getSelectedIndex()==0) && txtCnpj.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha o CNPJ do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else if ((comboBox_1.getSelectedIndex()==1) && txtCnpj.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha o CPF do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else if ((comboBox_1.getSelectedIndex()==1) && txtRG.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha o RG do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else if (txtTelefone.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha o Telefone do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else if (txtEndereco.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha o Endere�o do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else if (txtBairro.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha o Bairro do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else if (txtCidade.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha a Cidade do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else if (txtEstado.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha o Estado do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else if (txtCep.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha o CEP do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else if (txtPais.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha o Pais do Cliente", "Erro", JOptionPane.ERROR_MESSAGE);
				}else {
					cl.setBairro(txtBairro.getText());
					cl.setCep(txtCep.getText());
					cl.setCidade(txtCidade.getText());
					cl.setCliente(txtEmpresa.getText());
					cl.setCnpj_cpf(txtCnpj.getText());
					cl.setEstado(txtEstado.getText());
					cl.setPais(txtPais.getText());
					cl.setRg(txtRG.getText());
					cl.setTelefone(txtTelefone.getText());
					cl.setRua(txtEndereco.getText());
					
					
					if (txtInscricao.getText().equals("")) {
						cl.setInscricaoEstadual("Insento");
					}else {
						cl.setInscricaoEstadual(txtInscricao.getText());
					}
					
					
					try {
						cld.cadastrar(cl);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					
					btnCadastro.setVisible(true);
					btnCadastrar_1.setVisible(false);
					txtBairro.setEditable(false);
					txtCidade.setEditable(false);
					txtCnpj.setEditable(false);
					txtCodigo.setEditable(false);
					txtEmpresa.setEditable(false);
					txtEndereco.setEditable(false);
					txtEstado.setEditable(false);
					txtInscricao.setEditable(false);
					txtTelefone.setEditable(false);
					txtCep.setEditable(false);
					txtRG.setEditable(false);
					txtBuscar.setEditable(true);
					txtBuscaCodigo.setEditable(true);
					txtPais.setEditable(false);
					atualizarTabela();
					
				}
	
			}
		});
		
		JLabel lblBuscarCodigo = new JLabel("Buscar Codigo");
		lblBuscarCodigo.setBounds(269, 397, 83, 14);
		contentPane.add(lblBuscarCodigo);
		
		txtBuscaCodigo = new JTextField();
		txtBuscaCodigo.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {
				
				if (txtBuscaCodigo.getText().equals("")) {
					txtBuscaCodigo.setEditable(true);
					txtBuscar.setEditable(true);
				}else {
					txtBuscaCodigo.setEditable(true);
					txtBuscar.setEditable(false);
				}
				
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por codigo
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro);
				
				if (txtBuscaCodigo.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter(txtBuscaCodigo.getText(), 0));  
				}  
			}
		});
		txtBuscaCodigo.setColumns(10);
		txtBuscaCodigo.setBounds(359, 394, 141, 20);
		contentPane.add(txtBuscaCodigo);
		
		txtPais = new JTextField();
		txtPais.setEditable(false);
		txtPais.setColumns(10);
		txtPais.setBounds(93, 367, 141, 20);
		contentPane.add(txtPais);
		btnCadastrar_1.setBounds(105, 437, 98, 23);
		contentPane.add(btnCadastrar_1);
		btnCadastrar_1.setVisible(false);
		
		JLabel lblBuscar = new JLabel("Buscar Nome");
		lblBuscar.setBounds(20, 397, 83, 14);
		contentPane.add(lblBuscar);
		
		txtBuscar = new JTextField();
		txtBuscar.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				
				if (txtBuscar.getText().equals("")) {
					txtBuscaCodigo.setEditable(true);
					txtBuscar.setEditable(true);
				}else {
					txtBuscaCodigo.setEditable(false);
					txtBuscar.setEditable(true);
				}
				
				//atualizar a tabela apenas com valores correspondentes aos digitados no campo de busca por nome
				TableRowSorter<TableModel> filtro = null;  
				DefaultTableModel model = (DefaultTableModel) table.getModel();  
				filtro = new TableRowSorter<TableModel>(model);  
				table.setRowSorter(filtro); 
				
				if (txtBuscar.getText().length() == 0) {
					filtro.setRowFilter(null);
				} else {  
					filtro.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscar.getText(), 1));  
				}  
			}
		});
		txtBuscar.setBounds(103, 394, 141, 20);
		contentPane.add(txtBuscar);
		txtBuscar.setColumns(10);
		
		
		lblRG.setForeground(Color.BLUE);
		lblRG.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblRG.setBounds(20, 148, 46, 14);
		contentPane.add(lblRG);
		
		txtRG = new JTextField();
		txtRG.setEditable(false);
		txtRG.setBounds(93, 145, 156, 20);
		contentPane.add(txtRG);
		txtRG.setColumns(10);
		
		txtRG.setVisible(false);
		lblRG.setVisible(false);
		
		JLabel label = new JLabel("Endere\u00E7o");
		label.setForeground(Color.BLUE);
		label.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label.setBounds(20, 241, 107, 14);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Estado");
		label_1.setForeground(Color.BLUE);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_1.setBounds(20, 316, 107, 14);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("Cidade");
		label_2.setForeground(Color.BLUE);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_2.setBounds(20, 291, 107, 14);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("Bairro");
		label_3.setForeground(Color.BLUE);
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_3.setBounds(20, 266, 107, 14);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("Telefone");
		label_4.setForeground(Color.BLUE);
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_4.setBounds(20, 216, 98, 14);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("Inscri\u00E7\u00E3o");
		label_5.setBounds(20, 122, 83, 14);
		contentPane.add(label_5);
		
		txtBairro = new JTextField();
		txtBairro.setEditable(false);
		txtBairro.setColumns(10);
		txtBairro.setBounds(93, 266, 141, 20);
		contentPane.add(txtBairro);
		
		JLabel label_6 = new JLabel("Dados Gen\u00E9ricos");
		label_6.setForeground(Color.GRAY);
		label_6.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 17));
		label_6.setBounds(20, 191, 353, 14);
		contentPane.add(label_6);
		
		txtEstado = new JTextField();
		txtEstado.setEditable(false);
		txtEstado.setColumns(10);
		txtEstado.setBounds(93, 316, 83, 20);
		contentPane.add(txtEstado);
		
		JLabel label_7 = new JLabel("Pais");
		label_7.setForeground(Color.BLUE);
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_7.setBounds(20, 369, 107, 14);
		contentPane.add(label_7);
		
		txtTelefone = new JTextField();
		txtTelefone.setEditable(false);
		txtTelefone.setColumns(10);
		txtTelefone.setBounds(93, 216, 219, 20);
		contentPane.add(txtTelefone);
		
		txtInscricao = new JTextField();
		txtInscricao.setEditable(false);
		txtInscricao.setColumns(10);
		txtInscricao.setBounds(93, 119, 156, 20);
		contentPane.add(txtInscricao);
		
		JLabel label_CEP = new JLabel("CEP");
		label_CEP.setForeground(Color.BLUE);
		label_CEP.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_CEP.setBounds(20, 342, 107, 14);
		contentPane.add(label_CEP);
		
		txtCidade = new JTextField();
		txtCidade.setEditable(false);
		txtCidade.setColumns(10);
		txtCidade.setBounds(93, 291, 141, 20);
		contentPane.add(txtCidade);
		
		txtCep = new JTextField();
		txtCep.setEditable(false);
		txtCep.setColumns(10);
		txtCep.setBounds(93, 342, 83, 20);
		contentPane.add(txtCep);
		
		txtEndereco = new JTextField();
		txtEndereco.setEditable(false);
		txtEndereco.setColumns(10);
		txtEndereco.setBounds(93, 241, 280, 20);
		contentPane.add(txtEndereco);
		
		txtCnpj = new JTextField();
		txtCnpj.setEditable(false);
		txtCnpj.setColumns(10);
		txtCnpj.setBounds(93, 94, 156, 20);
		contentPane.add(txtCnpj);
		comboBox_1.setForeground(Color.BLUE);
		
		
		comboBox_1.addPopupMenuListener(new PopupMenuListener() {
			public void popupMenuCanceled(PopupMenuEvent arg0) {
			}
			public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {
				if (comboBox_1.getSelectedIndex()==1) {
					txtRG.setVisible(true);
					lblRG.setVisible(true);
				}else if(comboBox_1.getSelectedIndex()==0) {
					txtRG.setVisible(false);
					lblRG.setVisible(false);
				}
			}
			public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
			}
		});
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"CNPJ", "CPF"}));
		comboBox_1.setBounds(20, 94, 63, 20);
		contentPane.add(comboBox_1);
		
		txtEmpresa = new JTextField();
		txtEmpresa.setEditable(false);
		txtEmpresa.setColumns(10);
		txtEmpresa.setBounds(93, 67, 280, 20);
		contentPane.add(txtEmpresa);
		
		JLabel label_9 = new JLabel("Empresa");
		label_9.setForeground(Color.BLUE);
		label_9.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_9.setBounds(20, 67, 83, 16);
		contentPane.add(label_9);
		
		txtCodigo = new JTextField();
		txtCodigo.setEditable(false);
		txtCodigo.setColumns(10);
		txtCodigo.setBounds(93, 36, 63, 20);
		contentPane.add(txtCodigo);
		
		JLabel label_10 = new JLabel("Codigo");
		label_10.setForeground(Color.BLACK);
		label_10.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label_10.setBounds(20, 40, 83, 16);
		contentPane.add(label_10);
		
		JLabel label_12 = new JLabel("");
		label_12.setIcon(new ImageIcon(Cliente.class.getResource("/br/edu/ifcvideira/imgs/FundoBranco.png")));
		label_12.setBounds(10, 16, 589, 410);
		contentPane.add(label_12);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtBairro.setText("");
				txtCidade.setText("");
				txtCnpj.setText("");
				txtEmpresa.setText("");
				txtEndereco.setText("");
				txtEstado.setText("");
				txtInscricao.setText("");
				txtTelefone.setText("");
				txtCep.setText("");
				txtCodigo.setText("");
				txtRG.setText("");
				txtPais.setText("");
				
				txtRG.setEditable(false);
				txtBairro.setEditable(false);
				txtCidade.setEditable(false);
				txtCnpj.setEditable(false);
				txtCodigo.setEditable(false);
				txtEmpresa.setEditable(false);
				txtEndereco.setEditable(false);
				txtEstado.setEditable(false);
				txtInscricao.setEditable(false);
				txtTelefone.setEditable(false);
				txtCep.setEditable(false);
				txtPais.setEditable(false);
				txtBuscaCodigo.setEditable(true);
				txtBuscar.setEditable(true);
				
				btnCadastro.setEnabled(true);
				btnConcluir_1.setEnabled(false);
				btnExcluir.setEnabled(false);
				btnAlterar.setEnabled(false);
				btnCancelar.setEnabled(false);
				btnCadastrar_1.setVisible(false);
				btnCadastro.setEnabled(true);
				btnCadastro.setVisible(true);
				
			}
		});
		btnCancelar.setEnabled(false);
		btnCancelar.setBounds(411, 437, 89, 23);
		contentPane.add(btnCancelar);
		
		
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (table.getSelectedRow() != -1){
					Object[] options3 = {"Excluir", "Cancelar"};
					if(JOptionPane.showOptionDialog(null, "Tem certeza que deseja excluir o registro:\n>   " 
							+ table.getValueAt(table.getSelectedRow(), 0) + "   -   "
							+ table.getValueAt(table.getSelectedRow(), 1), null,
							JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options3, options3[0]) == 0){
						try {
						ClienteBeans cb = new ClienteBeans();
						ClienteDAO1 cbd = new ClienteDAO1();
						txtCodigo.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 0)));
							//atribui��o do valor do campo c�digo para o objeto cliente
							cb.setCodigo(Integer.parseInt(txtCodigo.getText()));
							
							// chamada do m�todo de exclus�o na classe Dao passando como par�metro o c�digo do cliente para ser exclu�do
							cbd.excluir(cb);
							
						
							atualizarTabela();
							txtBairro.setText("");
							txtCidade.setText("");
							txtCnpj.setText("");
							txtEmpresa.setText("");
							txtEndereco.setText("");
							txtEstado.setText("");
							txtInscricao.setText("");
							txtTelefone.setText("");
							txtCep.setText("");
							txtCodigo.setText("");
							txtRG.setText("");
						} catch (Exception e1) {
							JOptionPane.showMessageDialog(null, e1.getMessage());
						}
					}
				}
				else{
					JOptionPane.showMessageDialog(null, "Nenhuma linha selecionada");
				}
			}
		});
		btnExcluir.setEnabled(false);
		btnExcluir.setBounds(312, 437, 89, 23);
		contentPane.add(btnExcluir);
		
		
		btnAlterar.setEnabled(false);
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCancelar.setEnabled(true);
				btnExcluir.setEnabled(false);
				btnCadastro.setEnabled(false);
				btnCadastrar_1.setEnabled(false);
				btnAlterar.setEnabled(false);
				btnAlterar.setVisible(false);
				btnConcluir_1.setEnabled(true);
				btnConcluir_1.setVisible(true);
				
				txtBuscaCodigo.setEditable(false);
				txtBuscar.setEditable(false);
				txtBairro.setEditable(true);
				txtCidade.setEditable(true);
				txtCnpj.setEditable(true);
				txtCodigo.setEditable(false);
				txtEmpresa.setEditable(true);
				txtEndereco.setEditable(true);
				txtEstado.setEditable(true);
				txtInscricao.setEditable(true);
				txtTelefone.setEditable(true);
				txtCep.setEditable(true);
				txtPais.setEditable(true);
			}
		});
		btnAlterar.setBounds(213, 437, 89, 23);
		contentPane.add(btnAlterar);
		
		JButton btnCancelarBaixo = new JButton("Cancelar");
		btnCancelarBaixo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnCancelarBaixo.setBounds(119, 616, 89, 23);
		contentPane.add(btnCancelarBaixo);
		
		JButton btnConcluir = new JButton("Concluir");
		btnConcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnConcluir.setBounds(20, 616, 89, 23);
		contentPane.add(btnConcluir);
		
		btnCadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClienteDAO1 cld = new ClienteDAO1();

					try {
						txtCodigo.setText(String.valueOf(cld.RetornarProximoCodigoCliente()));
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null, e1, "Erro Ao receber o proximo codigo", JOptionPane.ERROR_MESSAGE);
					}
				
				
				txtBairro.setText("");
				txtCidade.setText("");
				txtCnpj.setText("");
				txtEmpresa.setText("");
				txtEndereco.setText("");
				txtEstado.setText("");
				txtInscricao.setText("");
				txtTelefone.setText("");
				txtCep.setText("");
				txtRG.setText("");
				txtPais.setText("");
				
				
				txtRG.setEditable(true);
				txtBairro.setEditable(true);
				txtCidade.setEditable(true);
				txtCnpj.setEditable(true);
				txtCodigo.setEditable(false);
				txtEmpresa.setEditable(true);
				txtEndereco.setEditable(true);
				txtEstado.setEditable(true);
				txtInscricao.setEditable(true);
				txtTelefone.setEditable(true);
				txtCep.setEditable(true);
				txtBuscar.setEditable(false);
				txtBuscaCodigo.setEditable(false);
				txtPais.setEditable(true);
				
				btnCadastro.setVisible(false);
				btnCadastrar_1.setVisible(true);
				btnCadastrar_1.setEnabled(true);
				btnCancelar.setEnabled(true);
				btnAlterar.setEnabled(false);
				btnExcluir.setEnabled(false);
				
				atualizarTabela();
			}
		});
		btnCadastro.setBounds(114, 437, 89, 23);
		contentPane.add(btnCadastro);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				setCampoTabela();
			}
		});
		scrollPane.setViewportBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		scrollPane.setBounds(10, 471, 589, 134);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				btnAlterar.setEnabled(true);
				btnExcluir.setEnabled(true);
				btnCancelar.setEnabled(true);
				btnAlterar.setVisible(true);
				btnCadastro.setEnabled(true);
				setCampoTabela();
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3digo", "Nome", "CNPJ/CPF", "Inscri\u00E7\u00E3o", "RG", "Telefone", "Rua", "Bairro", "Cidade", "Estado", "CEP", "Pais"
			}
		));
		scrollPane.setViewportView(table);
		btnConcluir_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ClienteBeans cl = new ClienteBeans();
				ClienteDAO1 cld = new ClienteDAO1();
				
				cl.setCodigo(Integer.parseInt(txtCodigo.getText()));
				cl.setBairro(txtBairro.getText());
				cl.setCep(txtCep.getText());
				cl.setCidade(txtCidade.getText());
				cl.setCliente(txtEmpresa.getText());
				cl.setCnpj_cpf(txtCnpj.getText());
				cl.setEstado(txtEstado.getText());
				cl.setInscricaoEstadual(txtInscricao.getText());
				cl.setPais(txtPais.getText());
				cl.setRg(txtRG.getText());
				cl.setTelefone(txtTelefone.getText());
				cl.setRua(txtEndereco.getText());
				
				try {
					cld.alterar(cl);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				atualizarTabela();
				btnConcluir_1.setVisible(false);
				btnAlterar.setEnabled(false);
				btnAlterar.setVisible(true);
				btnCancelar.setEnabled(false);
				btnExcluir.setEnabled(false);
				btnCadastro.setEnabled(true);
				
				txtBairro.setText("");
				txtCidade.setText("");
				txtCnpj.setText("");
				txtEmpresa.setText("");
				txtEndereco.setText("");
				txtEstado.setText("");
				txtInscricao.setText("");
				txtTelefone.setText("");
				txtCep.setText("");
				txtRG.setText("");
				txtPais.setText("");
				
				txtBuscaCodigo.setEditable(true);
				txtBuscar.setEditable(true);
				txtRG.setEditable(false);
				txtBairro.setEditable(false);
				txtCidade.setEditable(false);
				txtCnpj.setEditable(false);
				txtCodigo.setEditable(false);
				txtEmpresa.setEditable(false);
				txtEndereco.setEditable(false);
				txtEstado.setEditable(false);
				txtInscricao.setEditable(false);
				txtTelefone.setEditable(false);
				txtCep.setEditable(false);
				txtPais.setEditable(false);
				
			}
		});
		
		
		btnConcluir_1.setBounds(213, 437, 89, 23);
		contentPane.add(btnConcluir_1);
		
		
		atualizarTabela();
	}
	
	public void setCampoTabela() {
		txtCodigo.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 0)));
		txtEmpresa.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 1)));
		txtCnpj.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 2)));
		txtInscricao.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 3)));
		txtTelefone.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 5)));
		txtEndereco.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 6)));
		txtBairro.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 7)));
		txtCidade.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 8)));
		txtEstado.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 9)));
		txtCep.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 10)));
		txtPais.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 11)));
		
		txtRG.setText(String.valueOf(table.getValueAt(table.getSelectedRow(), 4)));
		
		int rg = 0;
		rg = (String.valueOf(table.getValueAt(table.getSelectedRow(), 4))).length();
		if (rg > 1) {
			txtRG.setVisible(true);
			lblRG.setVisible(true);
			
		}else {
			txtRG.setVisible(false);
			lblRG.setVisible(false);
		}
		
		
	}
	
	public void atualizarTabela() {
		try {
			ClienteDAO1 cld = new ClienteDAO1();
			cliente = cld.buscarTodos();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			model.setNumRows(0);
		for (int x=0; x!=cliente.size(); x++)
			{
				model.addRow((Object[]) cliente.get(x));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
}