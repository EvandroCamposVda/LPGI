package br.edu.ifc.Calculadora;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dialog.ModalExclusionType;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JTable;
import javax.swing.event.PopupMenuListener;
import javax.swing.event.PopupMenuEvent;

public class Calculadora extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblNumero;
	private JTextField tfNum1;
	private JTextField tfNum2;
	private JComboBox cbOperacao;
	private JButton btCalcular;
	private JTextField tfResultado;
	private JLabel lblResultado;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	JRadioButton rbAdicao = new JRadioButton("Adi\u00E7\u00E3o");
	JRadioButton rbSubt = new JRadioButton("Subtra\u00E7\u00E3o");
	JRadioButton rbMult = new JRadioButton("Multiplica\u00E7\u00E3o");
	JRadioButton rbDiv = new JRadioButton("Divis\u00E3o");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculadora frame = new Calculadora();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Calculadora() {
		setModalExclusionType(ModalExclusionType.APPLICATION_EXCLUDE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 269, 385);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("Calculadora");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel.setBounds(26, 12, 205, 19);
		contentPane.add(lblNewLabel);
		
		lblNumero = new JLabel("Numero 1");
		lblNumero.setBounds(26, 60, 63, 16);
		contentPane.add(lblNumero);
		
		tfNum1 = new JTextField();
		tfNum1.setBounds(117, 58, 114, 20);
		contentPane.add(tfNum1);
		tfNum1.setColumns(10);
		
		JLabel lblNumero_1 = new JLabel("Numero 2");
		lblNumero_1.setBounds(26, 90, 63, 16);
		contentPane.add(lblNumero_1);
		
		tfNum2 = new JTextField();
		tfNum2.setColumns(10);
		tfNum2.setBounds(117, 88, 114, 20);
		contentPane.add(tfNum2);
		
		cbOperacao = new JComboBox();
		cbOperacao.addPopupMenuListener(new PopupMenuListener() {
			public void popupMenuCanceled(PopupMenuEvent arg0) {
			}
			public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {
				double num1;
				double num2;
				double result = 0;
				
				num1 = Double.parseDouble(tfNum1.getText());
				num2 = Double.parseDouble(tfNum2.getText());
				
				if (cbOperacao.getSelectedIndex() == 1){
					result = num1 + num2;
					tfResultado.setText(""+result);
				}else if (cbOperacao.getSelectedIndex() == 2){
					result = num1 - num2;
					tfResultado.setText(""+result);
				}else if (cbOperacao.getSelectedIndex() == 3){
					result = num1 / num2;
					tfResultado.setText(""+result);
				}else if (cbOperacao.getSelectedIndex() == 4){
					result = num1 * num2;
					tfResultado.setText(""+result);
				}else {
					JOptionPane.showMessageDialog(null, "Selecione uma op��o !", "Erro Opera��o", JOptionPane.ERROR_MESSAGE);
				}
			}
			public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
			}
		});
		cbOperacao.setModel(new DefaultComboBoxModel(new String[] {"Selecione", "Adi\u00E7\u00E3o", "Subtra\u00E7\u00E3o", "Divis\u00E3o", "Multiplica\u00E7\u00E3o"}));
		cbOperacao.setBounds(26, 233, 104, 25);
		contentPane.add(cbOperacao);
		
		btCalcular = new JButton("Calcular");
		btCalcular.addActionListener(new ActionListener() {//addActionListener ouvente
			public void actionPerformed(ActionEvent e) {
//				double num1;
//				double num2;
//				double result = 0;
				
//				num1 = Double.parseDouble(tfNum1.getText());
//				num2 = Double.parseDouble(tfNum2.getText());
				
//				if (cbOperacao.getSelectedIndex() == 1){
//					result = num1 + num2;
//					tfResultado.setText(""+result);
//				}else if (cbOperacao.getSelectedIndex() == 2){
//					result = num1 - num2;
//					tfResultado.setText(""+result);
//				}else if (cbOperacao.getSelectedIndex() == 3){
//					result = num1 / num2;
//					tfResultado.setText(""+result);
//				}else if (cbOperacao.getSelectedIndex() == 4){
//					result = num1 * num2;
//					tfResultado.setText(""+result);
//				}else {
//					JOptionPane.showMessageDialog(null, "Selecione uma op��o !", "Erro Opera��o", JOptionPane.ERROR_MESSAGE);
//				}
				
//				if (rbAdicao.isSelected()){
//					result = num1 + num2;
//					tfResultado.setText(""+result);
//				}else if (rbDiv.isSelected()){
//					result = num1 / num2;
//					tfResultado.setText(""+result);
//				}else if (rbMult.isSelected()){
//					result = num1 * num2;
//					tfResultado.setText(""+result);
//				}else if (rbSubt.isSelected()){
//					result = num1 - num2;
//					tfResultado.setText(""+result);
//				}
			}
		});
		btCalcular.setBounds(142, 232, 89, 26);
		contentPane.add(btCalcular);
		
		tfResultado = new JTextField();
		tfResultado.setBackground(Color.WHITE);
		tfResultado.setForeground(Color.BLACK);
		tfResultado.setEditable(false);
		tfResultado.setColumns(10);
		tfResultado.setBounds(117, 314, 114, 20);
		contentPane.add(tfResultado);
		
		JLabel lblResultado = new JLabel("Resultado");
		lblResultado.setBounds(26, 316, 63, 16);
		contentPane.add(lblResultado);
		
		
		buttonGroup.add(rbAdicao);
		rbAdicao.setSelected(true);
		rbAdicao.setBounds(110, 116, 121, 24);
		contentPane.add(rbAdicao);
		
		
		buttonGroup.add(rbSubt);
		rbSubt.setBounds(110, 144, 121, 24);
		contentPane.add(rbSubt);
		
		
		buttonGroup.add(rbMult);
		rbMult.setBounds(110, 172, 121, 24);
		contentPane.add(rbMult);
		
		
		buttonGroup.add(rbDiv);
		rbDiv.setBounds(110, 200, 121, 24);
		contentPane.add(rbDiv);
	}
}
