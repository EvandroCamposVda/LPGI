package br.edu.ifcvideira.Exercicio01;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;

public class Principal extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	JCheckBox chEstabilizador = new JCheckBox("Estabilizador - R$ 150,00\r\n");
	JCheckBox chTeclado = new JCheckBox("Teclado - R$ 50,00\r\n");
	JCheckBox chCarregador = new JCheckBox("Carregador - R$ 200,00\r\n");
	JCheckBox chPasta = new JCheckBox("Pasta - R$ 150,00\r\n");
	private final JLabel lblPlacaMe = new JLabel("Placa M\u00E3e");
	Notebook no= new Notebook();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 385);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblConfigureOSeu = new JLabel("Configure seu computador");
		lblConfigureOSeu.setFont(new Font("Arial", Font.BOLD, 12));
		lblConfigureOSeu.setBounds(132, 11, 202, 22);
		contentPane.add(lblConfigureOSeu);
		
		JRadioButton rbNote = new JRadioButton("Notebook");
		rbNote.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rbNote.isSelected()){
					chCarregador.setEnabled(true);
					chPasta.setEnabled(true);
					chEstabilizador.setEnabled(false);
					chTeclado.setEnabled(false);
					chEstabilizador.setSelected(false);
					chTeclado.setSelected(false);
				}
			}
		});
		buttonGroup.add(rbNote);
		rbNote.setSelected(true);
		rbNote.setBounds(64, 40, 109, 23);
		contentPane.add(rbNote);
		
		JRadioButton rbDesktop = new JRadioButton("Desktop");
		rbDesktop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(rbDesktop.isSelected()){
					chCarregador.setEnabled(false);
					chPasta.setEnabled(false);
					chEstabilizador.setEnabled(true);
					chTeclado.setEnabled(true);
					chCarregador.setSelected(false);
					chPasta.setSelected(false);
				}
			}
		});
		buttonGroup.add(rbDesktop);
		rbDesktop.setBounds(282, 40, 109, 23);
		contentPane.add(rbDesktop);
		
		
		chEstabilizador.setEnabled(false);
		chEstabilizador.setBounds(238, 66, 148, 23);
		contentPane.add(chEstabilizador);
		
		chTeclado.setEnabled(false);
		chTeclado.setBounds(238, 87, 148, 23);
		contentPane.add(chTeclado);
		
		chCarregador.setBounds(25, 66, 148, 23);
		contentPane.add(chCarregador);
		
		chPasta.setBounds(25, 87, 148, 23);
		contentPane.add(chPasta);
		lblPlacaMe.setBounds(25, 128, 88, 22);
		
		contentPane.add(lblPlacaMe);
		
		JComboBox cbPlacaMae = new JComboBox();
		cbPlacaMae.setModel(new DefaultComboBoxModel(new String[] {"Modelo 1- R$ 500,00", "Modelo 2- R$ 700,00", "Modelo 3- R$ 900,00"}));
		cbPlacaMae.setBounds(95, 129, 135, 20);
		contentPane.add(cbPlacaMae);
		
		JComboBox cbProcessador = new JComboBox();
		cbProcessador.setModel(new DefaultComboBoxModel(new String[] {"Modelo 1 - R$ 400,00 ", "Modelo 2 - R$ 500,00 ", "Modelo 3 - R$ 600,00 "}));
		cbProcessador.setBounds(95, 153, 135, 20);
		contentPane.add(cbProcessador);
		
		JLabel lblProcessador = new JLabel("Processador");
		lblProcessador.setBounds(25, 152, 88, 22);
		contentPane.add(lblProcessador);
		
		JButton btnCalcular = new JButton("Calcular");
		btnCalcular.addActionListener(new ActionListener() {
			public void actionPerformed1(ActionEvent e) {
				//selecionou que quer comprar o notenook
				if(rbNote.isSelected()){
					
					//carregador
					if (chCarregador.isSelected()){
						no.setCarregador(200);
						no.setCarregadorDesc(chCarregador.getText()+"\n");
					}else{
						no.setCarregadorDesc("");
					}
					
					//pasta
					if (chPasta.isSelected()){
						no.setPasta(150);
						no.setPastaDesc(chPasta.getText()+"\n");
					}else{
						no.setPastaDesc("");
					}
					
					//placa mae
					if (cbPlacaMae.getSelectedIndex()==0){
						no.setPlacaMae(500);
						no.setPlacaMaeDesc("Placa M�e: "+cbPlacaMae.getSelectedItem()+"\n");
					}else if (cbPlacaMae.getSelectedIndex()==1){
						no.setPlacaMae(700);
						no.setPlacaMaeDesc("Placa M�e: "+cbPlacaMae.getSelectedItem()+"\n");
					}else if (cbPlacaMae.getSelectedIndex()==2){
						no.setPlacaMae(900);
						no.setPlacaMaeDesc("Placa M�e: "+cbPlacaMae.getSelectedItem()+"\n");
					}
					
					//processador
					if (cbProcessador.getSelectedIndex()==0){
						no.setProcessador(400);
						no.setProcessadorDesc("Processador: "+cbProcessador.getSelectedItem()+"\n");
					}else if (cbProcessador.getSelectedIndex()==1){
						no.setProcessador(500);
						no.setProcessadorDesc("Processador: "+cbProcessador.getSelectedItem()+"\n");
					}else if (cbProcessador.getSelectedIndex()==2){
						no.setProcessador(600);
						no.setProcessadorDesc("Processador: "+cbProcessador.getSelectedItem()+"\n");
					}
					
					JOptionPane.showMessageDialog(null, no.notaFiscalNote());
				}else{
					//selecionou que quer o desktop
				}
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				{
						//selecionou que quer comprar o notenook
						if(rbNote.isSelected()){
							
							//carregador
							if (chCarregador.isSelected()){
								no.setCarregador(200);
								no.setCarregadorDesc(chCarregador.getText()+"\n");
							}else{
								no.setCarregadorDesc("");
							}
							
							//pasta
							if (chPasta.isSelected()){
								no.setPasta(150);
								no.setPastaDesc(chPasta.getText()+"\n");
							}else{
								no.setPastaDesc("");
							}
							
							//placa mae
							if (cbPlacaMae.getSelectedIndex()==0){
								no.setPlacaMae(500);
								no.setPlacaMaeDesc("Placa M�e: "+cbPlacaMae.getSelectedItem()+"\n");
							}else if (cbPlacaMae.getSelectedIndex()==1){
								no.setPlacaMae(700);
								no.setPlacaMaeDesc("Placa M�e: "+cbPlacaMae.getSelectedItem()+"\n");
							}else if (cbPlacaMae.getSelectedIndex()==2){
								no.setPlacaMae(900);
								no.setPlacaMaeDesc("Placa M�e: "+cbPlacaMae.getSelectedItem()+"\n");
							}
							
							//processador
							if (cbProcessador.getSelectedIndex()==0){
								no.setProcessador(400);
								no.setProcessadorDesc("Processador: "+cbProcessador.getSelectedItem()+"\n");
							}else if (cbProcessador.getSelectedIndex()==1){
								no.setProcessador(500);
								no.setProcessadorDesc("Processador: "+cbProcessador.getSelectedItem()+"\n");
							}else if (cbProcessador.getSelectedIndex()==2){
								no.setProcessador(600);
								no.setProcessadorDesc("Processador: "+cbProcessador.getSelectedItem()+"\n");
							}
							
							JOptionPane.showMessageDialog(null, no.notaFiscalNote());
						}else{
							//selecionou que quer o desktop
						}
					}
				
			}
		});
		btnCalcular.setBounds(165, 312, 89, 23);
		contentPane.add(btnCalcular);
	}

}
