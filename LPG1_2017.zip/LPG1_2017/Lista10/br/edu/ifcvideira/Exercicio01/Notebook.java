package br.edu.ifcvideira.Exercicio01;

public class Notebook extends Computador {
	private double carregador;
	private double pasta;
	private String carregadorDesc;
	private String pastaDesc;
	
	public double getCarregador() {
		return carregador;
	}
	public void setCarregador(double carregador) {
		this.carregador = carregador;
	}
	public double getPasta() {
		return pasta;
	}
	public void setPasta(double pasta) {
		this.pasta = pasta;
	}
	public String getCarregadorDesc() {
		return carregadorDesc;
	}
	public void setCarregadorDesc(String carregadorDesc) {
		this.carregadorDesc = carregadorDesc;
	}
	public String getPastaDesc() {
		return pastaDesc;
	}
	public void setPastaDesc(String pastaDesc) {
		this.pastaDesc = pastaDesc;
	}
	
	
	public double calculaNote(){
		return this.getCarregador() + this.getPasta() +this.getHd() +this.getMemoria() + this.getPlacaMae() + this.getProcessador();
	}
	
	public String notaFiscalNote(){
		return "Ddos do Notebook escolhido:\n\n"
			+this.getCarregadorDesc()
			+this.getPastaDesc()
			+this.getPlacaMaeDesc()
			+this.getProcessadorDesc()
			+this.getHdDesc()
			+this.getMemoriaDesc()
			+"Quantidade de columes: 1\n"
			+"Valor total: R$"+calculaNote();
	}
}
