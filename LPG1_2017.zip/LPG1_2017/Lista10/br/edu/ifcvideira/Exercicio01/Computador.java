package br.edu.ifcvideira.Exercicio01;

public class Computador {
	private double placaMae;
	private double processador;
	private double hd;
	private double memoria;
	
	private String placaMaeDesc;
	private String processadorDesc;
	private String hdDesc;
	private String memoriaDesc;
	
	public double getPlacaMae() {
		return placaMae;
	}
	public void setPlacaMae(double placaMae) {
		this.placaMae = placaMae;
	}
	public double getProcessador() {
		return processador;
	}
	public void setProcessador(double processador) {
		this.processador = processador;
	}
	public double getHd() {
		return hd;
	}
	public void setHd(double hd) {
		this.hd = hd;
	}
	public double getMemoria() {
		return memoria;
	}
	public void setMemoria(double memoria) {
		this.memoria = memoria;
	}
	public String getPlacaMaeDesc() {
		return placaMaeDesc;
	}
	public void setPlacaMaeDesc(String placaMaeDesc) {
		this.placaMaeDesc = placaMaeDesc;
	}
	public String getProcessadorDesc() {
		return processadorDesc;
	}
	public void setProcessadorDesc(String processadorDesc) {
		this.processadorDesc = processadorDesc;
	}
	public String getHdDesc() {
		return hdDesc;
	}
	public void setHdDesc(String hdDesc) {
		this.hdDesc = hdDesc;
	}
	public String getMemoriaDesc() {
		return memoriaDesc;
	}
	public void setMemoriaDesc(String memoriaDesc) {
		this.memoriaDesc = memoriaDesc;
	}
}
