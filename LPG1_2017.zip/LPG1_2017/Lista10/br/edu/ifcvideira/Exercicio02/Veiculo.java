package br.edu.ifcvideira.Exercicio02;

public class Veiculo {

}
