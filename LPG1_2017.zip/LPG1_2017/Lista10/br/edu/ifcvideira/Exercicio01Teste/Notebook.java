package br.edu.ifcvideira.Exercicio01Teste;

public class Notebook extends Computador{
	private double valorPlaca_Mae;
	private double valorProcessador;
	private double valorHD;
	private double valorMemoria;
	

	public double getValorPlaca_Mae() {
		return valorPlaca_Mae;
	}

	public void setValorPlaca_Mae(double valorPlaca_Mae) {
		this.valorPlaca_Mae = valorPlaca_Mae;
	}

	public double getValorProcessador() {
		return valorProcessador;
	}

	public void setValorProcessador(double valorProcessador) {
		this.valorProcessador = valorProcessador;
	}

	public double getValorHD() {
		return valorHD;
	}

	public void setValorHD(double valorHD) {
		this.valorHD = valorHD;
	}

	public double getValorMemoria() {
		return valorMemoria;
	}

	public void setValorMemoria(double valorMemoria) {
		this.valorMemoria = valorMemoria;
	}
	
	
}
