package br.edu.ifcvideira.Exercicio01Teste;

public class Computador {
	private String Placa_Mae;
	private String Processador;
	private String HD;
	private String Memoria;
	
	public String getPlaca_Mae() {
		return Placa_Mae;
	}

	public void setPlaca_Mae(String placa_Mae) {
		Placa_Mae = placa_Mae;
	}

	public String getProcessador() {
		return Processador;
	}

	public void setProcessador(String processador) {
		Processador = processador;
	}

	public String getHD() {
		return HD;
	}

	public void setHD(String hD) {
		HD = hD;
	}

	public String getMemoria() {
		return Memoria;
	}

	public void setMemoria(String memoria) {
		Memoria = memoria;
	}
	
	
	
	
}
