package br.edu.ifcvideira.Exercicio01Teste;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

public class Sistema extends JFrame {
	Notebook note = new Notebook ();
	Notebook note1 = new Notebook ();
	Notebook note2 = new Notebook ();
	Desktop pc = new Desktop();
	Desktop pc1 = new Desktop();
	Desktop pc2 = new Desktop();
	private String carregador;
	private String pasta;
	private String mause;
	private String teclado;
	private String fone;
	private String fonte;
	private String leitorDVD;
	private double valorLeitorDVD;
	private double valorFonte;
	private double valorCarregador;
	private double valorPasta;
	private double valorMause;
	private double valorTeclado;
	private double valorFone;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sistema frame = new Sistema();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Sistema() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Sistema.class.getResource("/br/edu/ifcvideira/Exercicio01/calculator.png")));
		setTitle("Vendas Notebook");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 511, 345);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNome = new JLabel("Configure seu computador");
		lblNome.setHorizontalAlignment(SwingConstants.CENTER);
		lblNome.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNome.setForeground(Color.WHITE);
		lblNome.setBounds(10, 11, 1342, 41);
		contentPane.add(lblNome);

		setExtendedState( MAXIMIZED_BOTH );//Maximi
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(0, 0, 1373, 705);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon(Sistema.class.getResource("/br/edu/ifcvideira/Exercicio01/fundo.jpg")));
		contentPane.add(lblNewLabel);
		
		//Cadastro de HD Desktop
		pc.setHD("HD SATA de 500 GBs (5400 RPM)");
		pc1.setHD("HD SATA de 1 TB (5400 RPM)");
		pc2.setHD("HD SATA de 2 TB (5400 RPM)");
		pc.setValorHD(230.99);
		pc1.setValorHD(310.99);
		pc2.setValorHD(402.99);
		//Cadastro de Memoria Desktop
		pc.setMemoria("4GB, DDR4, 2400MHz");
		pc1.setMemoria("8GB, DDR4, 2400MHz");
		pc2.setMemoria("16GB, DDR4, 2400MHz");
		pc.setValorMemoria(199.99);
		pc1.setValorMemoria(note.getValorMemoria()*2);
		pc2.setValorMemoria(note.getValorMemoria()*4);
		
		//Cadastro Placa mae Desktop
		pc.setPlaca_Mae("Placa M�e Gigabyte GA-H81M-H LGA 1150 Chipset Intel H81");
		pc1.setPlaca_Mae("Placa-M�e GIGABYTE p/ Intel LGA 1151 mATX GA-B250M-GAMING 3 4xDDR4 64GB, HDMI, DVI, M.2 PCIe NVMe para SSD/Optane, USB 3.1");
		pc2.setPlaca_Mae("Placa m�e Gigabyte Aorus Z370 (linha Xtreme)");
		pc.setValorPlaca_Mae(399.99);
		pc1.setValorPlaca_Mae(599.99);
		pc2.setValorPlaca_Mae(799.99);
		//Cadastro Processador Desktop
		pc.setProcessador("7� gera��o do Processador Intel� Core� i5-7200U (2 n�cleos, 2.5 GHz expans�vel at� 3.1 GHz, Cache de 3 M)");
		pc1.setProcessador("7� gera��o do Processador Intel� Core� I5-7300HQ (Quad Core, 2.5 GHz expans�vel at� 3.5 GHz, Cache de 6MB com Turbo Boost)");
		pc2.setProcessador("7� gera��o do Processador Intel� Core� I7-7700HQ (Quad Core, 2.8 GHz expans�vel at� 3.8 GHz, Cache de 6MB com Turbo Boost)");
		pc.setValorProcessador(459.99);
		pc1.setValorProcessador(699.99);
		pc2.setValorProcessador(939.99);
		
		//Cadastro de HD
		note.setHD("HD SATA de 500 GBs (5400 RPM)");
		note1.setHD("HD SATA de 1 TB (5400 RPM)");
		note2.setHD("HD SATA de 2 TB (5400 RPM)");
		note.setValorHD(230.99);
		note1.setValorHD(310.99);
		note2.setValorHD(402.99);
				
		//Cadastro de Memoria
		note.setMemoria("4GB, DDR4, 2400MHz");
		note1.setMemoria("8GB, DDR4, 2400MHz");
		note2.setMemoria("16GB, DDR4, 2400MHz");
		note.setValorMemoria(199.99);
		note1.setValorMemoria(note.getValorMemoria()*2);
		note2.setValorMemoria(note.getValorMemoria()*4);
				
		//Cadastro de Placa M�e
		note.setPlaca_Mae("Placa m�e para notebook placa de video integrada at� 8GBs de memoria ram e HD 2 TBs");
		note1.setPlaca_Mae("Placa m�e para notebook placa de video integrada at� 16GBs de memoria ram e HD 2 TBs");
		note2.setPlaca_Mae("Placa m�e para notebook placa de video dedicada at� 16GBs de memoria tam e HD 2 TBs");
		note.setValorPlaca_Mae(499.99);
		note1.setValorPlaca_Mae(699.99);
		note2.setValorPlaca_Mae(999.99);
				
		//cadastro de Processador
		note.setProcessador("7� gera��o do Processador Intel� Core� i5-7200U (2 n�cleos, 2.5 GHz expans�vel at� 3.1 GHz, Cache de 3 M)");
		note1.setProcessador("7� gera��o do Processador Intel� Core� I5-7300HQ (Quad Core, 2.5 GHz expans�vel at� 3.5 GHz, Cache de 6MB com Turbo Boost)");
		note2.setProcessador("7� gera��o do Processador Intel� Core� I7-7700HQ (Quad Core, 2.8 GHz expans�vel at� 3.8 GHz, Cache de 6MB com Turbo Boost)");
		note.setValorProcessador(459.99);
		note1.setValorProcessador(699.99);
		note2.setValorProcessador(939.99);
				
		//Cadastro perifericos
		carregador = String.valueOf("Carregador para notebook");
		pasta = String.valueOf("Pasta para notebook");
		mause = String.valueOf("Mause para Notebook/Desktop");
		teclado = String.valueOf("Teclado para Notebook/Desktop");
		fone = String.valueOf("Fone de ouvido");
		fonte = String.valueOf("Fonte 500w para desktop");
		leitorDVD = String.valueOf("Leitor de CD/DVD para Notebook/Desktop");
		valorLeitorDVD = 199.99;
		valorFonte = 128.75;
		valorCarregador = 120.00;
		valorPasta = 58.87;
		valorMause = 32.99;
		valorTeclado = 37.99;
		valorFone = 50.00;
		
		
	}
}
