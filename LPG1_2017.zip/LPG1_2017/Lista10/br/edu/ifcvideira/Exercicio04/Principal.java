package br.edu.ifcvideira.Exercicio04;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.event.PopupMenuListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Principal extends JFrame {

	private JPanel contentPane;
	private JTextField tfNome;
	private JTextField tfEndereco;
	private JTextField tfSetor;
	private JTextField tfTelefonePessoal;
	private JTextField tfParentesco;
	JTextPane textPane = new JTextPane();
	
	ColegaTrabalho co = new ColegaTrabalho();
	Amigo am = new Amigo();
	Parente pa = new Parente();
	
	String msg = "";
	private JTextField tfEmail;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 508);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("Button.background"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEscolhaUmTipo = new JLabel("Escolha um tipo de pessoa");
		lblEscolhaUmTipo.setBounds(32, 11, 198, 14);
		contentPane.add(lblEscolhaUmTipo);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addPopupMenuListener(new PopupMenuListener() {
			public void popupMenuCanceled(PopupMenuEvent arg0) {
			}
			public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {
				//
				if (comboBox.getSelectedIndex()==0){
					tfSetor.setEnabled(true);
					tfTelefonePessoal.setEnabled(false);
					tfParentesco.setEnabled(false);
					tfTelefonePessoal.setText("");
					tfParentesco.setText("");
				}else if (comboBox.getSelectedIndex()==1){
					tfSetor.setEnabled(false);
					tfTelefonePessoal.setEnabled(true);
					tfParentesco.setEnabled(false);
					tfSetor.setText("");
					tfParentesco.setText("");
				}else if (comboBox.getSelectedIndex()==2){
					tfSetor.setEnabled(false);
					tfTelefonePessoal.setEnabled(false);
					tfParentesco.setEnabled(true);
					tfSetor.setText("");
					tfTelefonePessoal.setText("");
				}
			}
			public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Colega de Trabalho", "Amigo", "Parente "}));
		comboBox.setBounds(229, 8, 169, 20);
		contentPane.add(comboBox);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(32, 36, 46, 14);
		contentPane.add(lblNome);
		
		tfNome = new JTextField();
		tfNome.setBounds(159, 33, 239, 20);
		contentPane.add(tfNome);
		tfNome.setColumns(10);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setBounds(32, 61, 46, 14);
		contentPane.add(lblEmail);
		
		tfEmail = new JTextField();
		tfEmail.setColumns(10);
		tfEmail.setBounds(159, 58, 239, 20);
		contentPane.add(tfEmail);
		
		tfEndereco = new JTextField();
		tfEndereco.setColumns(10);
		tfEndereco.setBounds(159, 84, 239, 20);
		contentPane.add(tfEndereco);
		
		JLabel lblEndereo = new JLabel("Endere\u00E7o:");
		lblEndereo.setBounds(32, 87, 117, 14);
		contentPane.add(lblEndereo);
		
		JLabel lblSetor = new JLabel("Setor:");
		lblSetor.setBounds(32, 114, 117, 14);
		contentPane.add(lblSetor);
		
		tfSetor = new JTextField();
		tfSetor.setColumns(10);
		tfSetor.setBounds(159, 111, 239, 20);
		contentPane.add(tfSetor);
		
		tfTelefonePessoal = new JTextField();
		tfTelefonePessoal.setEnabled(false);
		tfTelefonePessoal.setColumns(10);
		tfTelefonePessoal.setBounds(159, 139, 239, 20);
		contentPane.add(tfTelefonePessoal);
		
		JLabel lblTelefonePessoal = new JLabel("Telefone Pessoal:");
		lblTelefonePessoal.setBounds(32, 142, 117, 14);
		contentPane.add(lblTelefonePessoal);
		
		tfParentesco = new JTextField();
		tfParentesco.setEnabled(false);
		tfParentesco.setColumns(10);
		tfParentesco.setBounds(159, 169, 239, 20);
		contentPane.add(tfParentesco);
		
		JLabel lblParentesco = new JLabel("Parentesco:");
		lblParentesco.setBounds(32, 172, 117, 14);
		contentPane.add(lblParentesco);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(32, 238, 366, 220);
		contentPane.add(scrollPane);
		textPane.setEditable(false);
		
		
		scrollPane.setViewportView(textPane);
		
		JButton btEnter = new JButton("Enter");
		btEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (comboBox.getSelectedIndex()==0){
					co.setNome(tfNome.getText());
					co.setEmail(tfEmail.getText());
					co.setEndereco(tfEmail.getText());
					co.setSetor(tfSetor.getText());
					
					msg += co.retornaColegaTrabalho();
				}else if (comboBox.getSelectedIndex()==1){
					am.setNome(tfNome.getText());
					am.setEmail(tfEmail.getText());
					am.setEndereco(tfEmail.getText());
					am.setTelefonePessoal(tfTelefonePessoal.getText());
					
					msg += am.retornaAmigo();
				}else if (comboBox.getSelectedIndex()==2){
					pa.setNome(tfNome.getText());
					pa.setEmail(tfEmail.getText());
					pa.setEndereco(tfEmail.getText());
					pa.setParentesco(tfParentesco.getText());
					
					msg += pa.retornaParente();
				}
				textPane.setText(msg);
				limpar();
			}
		});
		btEnter.setBounds(159, 204, 89, 23);
		contentPane.add(btEnter);
	}
	public void limpar(){
		tfNome.setText("");
		tfEmail.setText("");
		tfEndereco.setText("");
		tfParentesco.setText("");
		tfTelefonePessoal.setText("");
		tfSetor.setText("");
	}
}
