package br.edu.ifcvideira.Exercicio04;

public class ColegaTrabalho extends Pessoa{
	private String setor;

	public String getSetor() {
		return setor;
	}
	public void setSetor(String setor) {
		this.setor = setor;
	}
	public String retornaColegaTrabalho(){
		return "Nome: " + this.getNome() + "\n"
				+ "Email: " + this.getEmail() + "\n"
						+ "Endere�o: " + this.getEndereco() + "\n"
								+ "Setor: " + this.getSetor() + "\n"
										+ "Assinatura de Email: Att." + this.getNome()+"\n\n";
	}
}
