package br.edu.ifcvideira.Exercicio04;

public class Amigo extends Pessoa{
	private String telefonePessoal;

	public String getTelefonePessoal() {
		return telefonePessoal;
	}

	public void setTelefonePessoal(String telefonePessoal) {
		this.telefonePessoal = telefonePessoal;
	}
	
	public String retornaAmigo(){
		return "Nome: " + this.getNome() + "\n"
				+ "Email: " + this.getEmail() + "\n"
						+ "Endere�o: " + this.getEndereco() + "\n"
								+ "Telefone Pessoal: " + this.getTelefonePessoal() + "\n"
										+ "Assinatura de Email: Abra�os." + this.getNome()+"\n\n";
	}
}
