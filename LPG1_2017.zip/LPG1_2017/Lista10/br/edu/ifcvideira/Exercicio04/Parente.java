package br.edu.ifcvideira.Exercicio04;

public class Parente extends Pessoa{
	private String parentesco;

	public String getParentesco() {
		return parentesco;
	}

	public void setParentesco(String parentesco) {
		this.parentesco = parentesco;
	}
	
	public String retornaParente(){
		return "Nome: " + this.getNome() + "\n"
				+ "Email: " + this.getEmail() + "\n"
						+ "Endere�o: " + this.getEndereco() + "\n"
								+ "Parentesco: " + this.getParentesco() + "\n"
										+ "Assinatura de Email: At� Mais." + this.getNome()+"\n\n";
	}
}
//SobreCarga de metodos � quando eu crio 2 classes com os mesmos nomes porem com atividades diferentes 
//SobreEscrita de metodos � quando ele esta dentro de uma classe mae e reescrevo na classe filha ou seja, na mae possui um metodo e na filha possui o metodo com o mesmo nome porem com outras atividades