package br.edu.ifcvideira.ContaCorrente;

import javax.swing.JOptionPane;

public class Caixa {
	public static void main(String[] args) {
		ContaCorrente cc = new ContaCorrente();
		int dec;
		double valor;
		
		for (;;){
			dec = Integer.parseInt(JOptionPane.showInputDialog("1 - Dep�sito\n"
					+ "2 - Saque\n"
					+ "3 - Saldo\n"
					+ "4 - Saida\n"
					+ "Digite sua Opera��o: "));
			if (dec == 1){
				cc.deposito(Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do dep�sito: ")));
			}else if (dec == 2){
				valor=(Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do saque: ")));
					if 	(cc.getSaldo()>=valor){
						cc.saque(valor);
						JOptionPane.showMessageDialog(null, "Saldo Efetuado Com Sucesso !");
					}else {
						JOptionPane.showMessageDialog(null, "Saldo Indisponivel !");
					}
			}else if (dec == 3){
				JOptionPane.showMessageDialog(null, "Saldo Atual: R$" + cc.getSaldo());
			}else if (dec == 4){
				JOptionPane.showMessageDialog(null, "Finalizando !");
				break;
			}else {
				JOptionPane.showMessageDialog(null, "Op��o Invalida !");
			}
		}
	}
}
// Criar um arquivo executavel � em File - Export - Java - Runnable
