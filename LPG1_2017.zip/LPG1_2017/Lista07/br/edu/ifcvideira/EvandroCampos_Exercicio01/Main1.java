package br.edu.ifcvideira.EvandroCampos_Exercicio01;

import javax.swing.JOptionPane;

public class Main1 {
	public static void main(String[] args) {
		Pessoa p1 = new Pessoa ();
		Pessoa p2 = new Pessoa ();
		Pessoa p3 = new Pessoa ();
		int dec;
		
		p1.setNome(JOptionPane.showInputDialog("Digite o nome da 1� Pessoa"));
		p1.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Digite a idade de " + p1.getNome())));
		p2.setNome(JOptionPane.showInputDialog("Digite o nome da 2� Pessoa"));
		p2.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Digite a idade de " + p2.getNome())));
		p3.setNome(JOptionPane.showInputDialog("Digite o nome da 3� Pessoa"));
		p3.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Digite a idade de " + p3.getNome())));
		
		for (;;){
			dec = Integer.parseInt(JOptionPane.showInputDialog("Dados pessoas !\n"
					+ "Nome: " + p1.getNome() + " : " + p1.getIdade() + "\n"
						+ "Nome: "+p2.getNome() + " : " + p2.getIdade()+"\n"
								+ "Nome: "+p3.getNome() + " : "+p3.getIdade()+"\n"
										+ "Quem fez anivers�rio ?"));
		
			if (dec == 1){
				p1.fazAniversario();
			}else if (dec == 2){
				p2.fazAniversario();
			}else if (dec == 3){
				p3.fazAniversario();
			}else if (dec == 4){
				JOptionPane.showMessageDialog(null, "Dados ap�s finalizar o programa \n");
				JOptionPane.showMessageDialog(null, "Dados pessoas !\n"
						+ "Nome: " + p1.getNome() + " : " + p1.getIdade() + "\n"
							+ "Nome: "+p2.getNome() + " : " + p2.getIdade()+"\n"
									+ "Nome: "+p3.getNome() + " : "+p3.getIdade()+"\n");
				break;
			}else {
				JOptionPane.showMessageDialog(null, "Erro Comando Invalido !");
			}
		}
		
	}
}
