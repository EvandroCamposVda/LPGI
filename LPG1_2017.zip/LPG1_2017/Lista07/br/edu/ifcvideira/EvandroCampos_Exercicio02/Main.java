package br.edu.ifcvideira.EvandroCampos_Exercicio02;

import javax.swing.JOptionPane;

public class Main {
	public static void main(String[] args) {
		Porta po = new Porta ();
		int dec;
		
		dec = Integer.parseInt(JOptionPane.showInputDialog("Qual estado inicial da porta\n"
				+ "1 - Aberta\n"
				+ "2 - Fechada"));
		if (dec == 1){
			po.setEstado(true);
		}else if (dec == 2){
			po.setEstado(false);
		}else {
			JOptionPane.showInputDialog("Comando Invalido");
		}
		po.setCor(String.valueOf(JOptionPane.showInputDialog("Digite a cor da porta")));
		po.setdX(Double.parseDouble(JOptionPane.showInputDialog("Digite a dimens�o X")));
		po.setdY(Double.parseDouble(JOptionPane.showInputDialog("Digite a dimens�o Y")));
		po.setdZ(Double.parseDouble(JOptionPane.showInputDialog("Digite a dimens�o Z")));
		
		for (;;){
			dec = Integer.parseInt(JOptionPane.showInputDialog("Dados Atuais da Porta\n"
					+ "Estado: " + po.retorneEstado() +"\n"
							+ "Cor: " + po.getCor() + "\n"
									+ "Dimens�o X: " + po.getdX()+ "\n"
											+ "Dimensao Y: " + po.getdY()+ "\n"
													+ "Dimensao Z: " + po.getdZ()+ "\n\n\n"
															+ "1 - Alterar Estado \n"
															+ "2 - Alterar Cor \n"
															+ "3 - Alterar Dimensao X \n"
															+ "4 - Alterar Dimensao Y \n"
															+ "5 - Aletrar Dimensao Z \n"
															+ "6 - Sair \n"
															+ "Digite sua op��o"));
			if (dec == 1){
				po.mudaEstado();
			}else if (dec == 2){
				po.setCor(String.valueOf(JOptionPane.showInputDialog("Digite a cor da porta !")));
			}else if (dec == 3){
				po.setdX(Double.parseDouble(JOptionPane.showInputDialog("Digite a Dimensao X da porta !")));
			}else if (dec == 4){
				po.setdY(Double.parseDouble(JOptionPane.showInputDialog("Digite a Dimensao X da porta !")));
			}else if (dec == 5){
				po.setdZ(Double.parseDouble(JOptionPane.showInputDialog("Digite a Dimensao X da porta !")));
			}else if (dec == 6){
				JOptionPane.showMessageDialog(null, "Finalizando ...");
				break;
			}else {
				JOptionPane.showMessageDialog(null, "Op��o Invalida !");
			}
		}
	}
}
