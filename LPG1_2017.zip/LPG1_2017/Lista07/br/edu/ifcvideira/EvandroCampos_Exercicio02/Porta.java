package br.edu.ifcvideira.EvandroCampos_Exercicio02;

public class Porta {
	private boolean estado;
	private String cor;
	private double dX;
	private double dY;
	private double dZ;
	
	//Encapsular
	public boolean isEstado() {//is diz se � verdadeiro
		return estado;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public double getdX() {
		return dX;
	}
	public void setdX(double dX) {
		this.dX = dX;
	}
	public double getdY() {
		return dY;
	}
	public void setdY(double dY) {
		this.dY = dY;
	}
	public double getdZ() {
		return dZ;
	}
	public void setdZ(double dZ) {
		this.dZ = dZ;
	}
	//Fim Encapsulamento
	//Mudan�a de estado porta
	public void mudaEstado(){
		if (this.isEstado()){
			this.setEstado(false);
		}else{
			this.setEstado(true);
		}
	}
	public String retorneEstado(){//Retorna em portugues
		if (this.isEstado()){
			return "Aberta";
		}else {
			return "Fechada";
		}
	}
}
