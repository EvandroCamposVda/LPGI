package br.edu.ifcvideira.EvandroCampos_Exercicio04;

public class Computador {
	private int codigo;
	private String nomePlacaMae;
	private String nomeMemoria;
	private String nomeProcessador;
	private String nomeHD;
	private String nomeMonitor;
	private String comprovante;

	private double valorPlacaMae;
	private double valorMemoria;
	private double valorProcessador;
	private double valorHD;
	private double valorMonitor;
	private double somaTotal;
	
	
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNomePlacaMae() {
		return nomePlacaMae;
	}

	public void setNomePlacaMae(String nomePlacaMae) {
		this.nomePlacaMae = nomePlacaMae;
	}

	public String getNomeMemoria() {
		return nomeMemoria;
	}

	public void setNomeMemoria(String nomeMemoria) {
		this.nomeMemoria = nomeMemoria;
	}

	public String getNomeProcessador() {
		return nomeProcessador;
	}

	public void setNomeProcessador(String nomeProcessador) {
		this.nomeProcessador = nomeProcessador;
	}

	public String getNomeHD() {
		return nomeHD;
	}

	public void setNomeHD(String nomeHD) {
		this.nomeHD = nomeHD;
	}

	public String getNomeMonitor() {
		return nomeMonitor;
	}

	public void setNomeMonitor(String nomeMonitor) {
		this.nomeMonitor = nomeMonitor;
	}

	public double getValorPlacaMae() {
		return valorPlacaMae;
	}

	public void setValorPlacaMae(double valorPlacaMae) {
		this.valorPlacaMae = valorPlacaMae;
	}

	public double getValorMemoria() {
		return valorMemoria;
	}

	public void setValorMemoria(double valorMemoria) {
		this.valorMemoria = valorMemoria;
	}

	public double getValorProcessador() {
		return valorProcessador;
	}

	public void setValorProcessador(double valorProcessador) {
		this.valorProcessador = valorProcessador;
	}

	public double getValorHD() {
		return valorHD;
	}

	public void setValorHD(double valorHD) {
		this.valorHD = valorHD;
	}

	public double getValorMonitor() {
		return valorMonitor;
	}

	public void setValorMonitor(double valorMonitor) {
		this.valorMonitor = valorMonitor;
	}

	public double getSomaTotal() {
		return somaTotal = this.valorHD + this.valorMemoria + this.valorMonitor + this.valorPlacaMae + this.valorProcessador;
	}
	
	public String getComprovante() {
		return comprovante = "Lista Compras ! \n\n" + this.nomeHD + ": R$" + this.valorHD + "\n"
				+ this.nomeMemoria + ": R$" +  this.valorMemoria + "\n" 
				+ this.nomeMonitor + ": R$ " + this.valorMonitor + "\n"
				+ this.nomePlacaMae + ": R$" + this.valorPlacaMae + "\n"
				+ this.nomeProcessador + ": R$" + this.valorProcessador + "\n";
	}
}

/* 
1 - Crie um codigo para  item;
2 - Crie um nome para  item;
3 - Crie um valor para  item;
4 - Crie um metodo para fazer a soma de coisas compradas;
*/