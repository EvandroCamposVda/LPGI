package br.edu.ifcvideira.EvandroCampos_Exercicio04;

import javax.swing.JOptionPane;

public class main {
	public static void main( String[] args) {
		Computador cpu = new Computador ();
		int dec;//Menu
		int dec1;//Compras
		int i;
		int j = 1;
		
		for (i=1;i>0;i++) {
			dec = Integer.parseInt(JOptionPane.showInputDialog("Bem Vindo \n"
					+ "Pedido n�mero" + j + "\n"
					+ "1 - Placa m�e \n"
					+ "2 - Mem�ria \n"
					+ "3 - Disco R�gido \n"
					+ "4 - Monitor \n"
					+ "5 - Processador \n"
					+ "6 - Finalizar Compras \n"
					+ "Digite o que deseja inserir no pedido"));
			if (dec == 1) {
				dec1 = Integer.parseInt(JOptionPane.showInputDialog("Placa M�e \n"
						+ "1 - Placa-m�e Msi P/ Intel Lga 1151 Atx Z270 Gaming M5 4x Ddr4, Sli/crossfire, Hdmi R$900,00\n"
						+ "2 - Placa Mae Asus Atx (Am3+) 970 Pro Gaming/Aura R$900,00\n"
						+ "Digite o modelo desejado "));
				if (dec1 == 1) {
					cpu.setNomePlacaMae("Placa-m�e Msi P/ Intel Lga 1151 Atx Z270 Gaming M5 4x Ddr4, Sli/crossfire, Hdmi");
					cpu.setValorPlacaMae(900);
				}else if (dec1 == 2) {
					cpu.setNomePlacaMae("Placa Mae Asus Atx (Am3+) 970 Pro Gaming/Aura");
					cpu.setValorPlacaMae(900);
				}else  {
					JOptionPane.showMessageDialog(null, "Comando Invalido", "Erro Cadastro Placa M�e !", JOptionPane.ERROR_MESSAGE);
				}//Fim Compra placa m�e
			}else if (dec == 2) {
				dec1 = Integer.parseInt(JOptionPane.showInputDialog("Mem�ria Ram \n\n"
						+ "1 - Memoria Ram 1GBs R$150,00" +"\n"
						+ "2 - Memoria Ram 2GBs R$ 300,00" + "\n"
						+ "3 - Memoria Ram 4GBs R$ 600,00" + "\n"
						+ "4 - Memoria Ram 8GBs R$ 1200,00" + "\n"
						+ "Digite o modelo desejado"));
				if (dec1 == 1) {
					cpu.setNomeMemoria("Memoria Ram 1GBs");
					cpu.setValorMemoria(150);
				}else if (dec1 == 2) {
					cpu.setNomeMemoria("Memoria Ram 2GBs");
					cpu.setValorMemoria(300);
				}else if (dec1 == 3) {
					cpu.setNomeMemoria("Memoria Ram 4GBs");
					cpu.setValorMemoria(600);
				}else if (dec1 == 4) {
					cpu.setNomeMemoria("Memoria Ram 8GBs");
					cpu.setValorMemoria(1200);
				}else  {
					JOptionPane.showMessageDialog(null, "Comando Invalido", "Erro Cadastro Memoria RAM !", JOptionPane.ERROR_MESSAGE);
				}//Fim Compra memoria 
			}else if (dec == 3) {
				dec1 = Integer.parseInt(JOptionPane.showInputDialog("Disco Rigido \n"
						+ "1 - Disco Rigido 500GBs R$400,00\n"
						+ "2 - Disco Rigido 1TBs R$600,00\n"
						+ "3 - Disco Rigido 2TBs R$800,00\n"
						+ "Digite o disco"));
				if (dec1 == 1) {
					cpu.setNomeHD("Disco Rigido 500GBs");
					cpu.setValorHD(400);
				}else if (dec1 == 2) {
					cpu.setNomeHD("Disco Rigido 1TBs");
					cpu.setValorHD(600);
				}else if (dec1 == 3) {
					cpu.setNomeHD("Disco Rigido 2TBs");
					cpu.setValorHD(800);
				}else  {
					JOptionPane.showMessageDialog(null, "Comando Invalido", "Erro Cadastro HD !", JOptionPane.ERROR_MESSAGE);
				}
				
			}else if (dec == 4) {
				dec1 = Integer.parseInt(JOptionPane.showInputDialog("Monitor\n"
						+ "1 - Monitor 17 Polegadas R$390,00\n"
						+ "2 - Monitor 19 Polegadas R$520,00\n"
						+ "Digite o modelo do monitor"));
				if (dec1 == 1) {
					cpu.setNomeMonitor("Monitor 17 Polegadas");
					cpu.setValorMonitor(520);
				}else if (dec1 == 2) {
					cpu.setNomeMonitor("Monitor 19 Polegadas");
					cpu.setValorMonitor(520);
				}else  {
					JOptionPane.showMessageDialog(null, "Comando Invalido", "Erro Cadastro Monitor !", JOptionPane.ERROR_MESSAGE);
				}
			}else if (dec == 5) {
				dec1 = Integer.parseInt(JOptionPane.showInputDialog("Processadores \n"
						+ "1 - Processador 600Mhz R$700,00\n"
						+ "2 - Processador 800Mhz R$830,00\n"
						+ "3 - Processador 933Mhz R$910,00\n"
						+ "Digite a op��o de processador"));
				if (dec1 == 1) {
					cpu.setNomeProcessador("Processador 600Mhz");
					cpu.setValorProcessador(700);
				}else if (dec1 == 2) {
					cpu.setNomeProcessador("Processador 800Mhz");
					cpu.setValorProcessador(830);
				}else if (dec1 == 3) {
					cpu.setNomeProcessador("Processador 933Mhz");
					cpu.setValorProcessador(910);
				}else {
					JOptionPane.showMessageDialog(null, "Comando Invalido", "Erro Cadastro Processadores !", JOptionPane.ERROR_MESSAGE);
				}
			}else if (dec == 6) {
				JOptionPane.showMessageDialog(null, cpu.getComprovante() + "\nValor Total: R$" + cpu.getSomaTotal(), "Comprovante Compras", JOptionPane.INFORMATION_MESSAGE);
				j++;
				break;
			}else {
				JOptionPane.showMessageDialog(null, "Comando Invalido", "Erro Comando Menu !", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}