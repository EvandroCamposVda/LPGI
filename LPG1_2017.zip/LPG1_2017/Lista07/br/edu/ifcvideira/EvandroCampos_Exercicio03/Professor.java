/*3 - Defina uma classe Professor com os dados: nome do professor, nome do departamento, n�mero de registro e data de admiss�o. Crie uma 
 * classe main que permita manipular os dados dos professores.
 */
package br.edu.ifcvideira.EvandroCampos_Exercicio03;

public class Professor {
	private String nome;
	private String departamento;
	private double registro;
	private String dataAdmissao;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public double getRegistro() {
		return registro;
	}
	public void setRegistro(double registro) {
		this.registro = registro;
	}
	public String getDataAdmissao() {
		return dataAdmissao;
	}
	public void setDataAdmissao(String dataAdminissao) {
		this.dataAdmissao = dataAdminissao;
	}
	
	
}
