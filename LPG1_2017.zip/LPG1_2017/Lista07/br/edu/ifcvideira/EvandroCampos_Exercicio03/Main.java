/*3 - Defina uma classe Professor com os dados: nome do professor, nome do departamento, n�mero de registro e data de admiss�o. Crie uma 
 * classe main que permita manipular os dados dos professores. */
package br.edu.ifcvideira.EvandroCampos_Exercicio03;

import javax.swing.JOptionPane;

public class Main {
	public static void main(String[] args) {
		Professor p = new Professor ();
		int dec;
		
		p.setNome(JOptionPane.showInputDialog("Digite o nome do professor !"));
		p.setDepartamento(JOptionPane.showInputDialog("Digite o nome do Departamento !"));
		p.setRegistro(Double.parseDouble(JOptionPane.showInputDialog("Digite n�mero do registro !")));
		p.setDataAdmissao(JOptionPane.showInputDialog("Digite a data de admiss�o !"));
		
		for (;;){
			dec = Integer.parseInt(JOptionPane.showInputDialog("Dados Professor !\n"
					+ "1 - Nome: " + p.getNome() + "\n"
					+ "2 - Departamento: " + p.getDepartamento() + "\n"
					+ "3 - Registro: " + p.getRegistro() + "\n"
					+ "4 - Data Admiss�o: " + p.getDataAdmissao() + "\n"
					+ "O que deseja alterar !"));
			if (dec == 1){
				p.setNome(JOptionPane.showInputDialog("Digite o novo nome !"));
			}else if (dec == 2){
				p.setDepartamento(JOptionPane.showInputDialog("Digite o departamento !"));
			}else if (dec == 3){
				p.setRegistro(Double.parseDouble(JOptionPane.showInputDialog("Novo numero de registro !")));
			}else if (dec == 4){
				p.setDataAdmissao((JOptionPane.showInputDialog("Digite a nova data de admiss�o !")));
			}else {
				JOptionPane.showMessageDialog(null, "Comando Invalido !", "Erro Altera��o Professor", JOptionPane.ERROR_MESSAGE);;
			}
					
		}
	}
}
