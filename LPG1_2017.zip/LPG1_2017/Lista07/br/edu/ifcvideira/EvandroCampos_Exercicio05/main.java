package br.edu.ifcvideira.EvandroCampos_Exercicio05;

import javax.swing.JOptionPane;

public class main {
	public static void main(String[] args) {
		livro l1 = new livro("Fundamentos da programa��o de computadores", "Acencio", 2012);
		livro l2 = new livro("Programa��o com C", "X", 2010);
		livro l3 = new livro("Programa��o com Java", "Y", 2013);
		
		JOptionPane.showMessageDialog(null, "Dados Livros !\n"
				+ "Livro 1 \n"
				+ "Titulo: " + l1.getTitulo()+ "\n"
				+ "Autor: " + l1.getAutor()+ "\n"
				+ "Ano: " + l1.getTitulo()+ "\n\n"
				+ "Livro 2 \n"
				+ "Titulo: " + l2.getTitulo()+ "\n"
				+ "Autor: " + l2.getAutor()+ "\n"
				+ "Ano: " + l2.getTitulo()+ "\n\n"
				+ "Livro 3 \n"
				+ "Titulo: " + l3.getTitulo()+ "\n"
				+ "Autor: " + l3.getAutor()+ "\n"
				+ "Ano: " + l3.getTitulo()+ "\n");
	}
}
