package br.edu.ifc.Exercicio02;

import javax.swing.JOptionPane;

public class Produto {
	public static void main(String[] args) {
		EquipamentoSonoro eq = new EquipamentoSonoro ();
		int dec;

		for (;;) {
			
			dec = Integer.parseInt(JOptionPane.showInputDialog(null, "Ligado: "+ eq.isLigado() +"\nVolume: "+ eq.getVolume() +"\n\nLigar o equipamento \n"
					+ "1 - ligar\n"
					+ "2 - desligar\n"
					+ "3 - Volume", "Condi��o Equipamento", JOptionPane.QUESTION_MESSAGE));
			if (dec == 1){
				eq.liga();
				eq.setVolume(5);
			}else if (dec == 2) {
				eq.desliga();
			}else if (dec == 3) {
				dec = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor do volume"));
				if (dec > 10 || dec < 0) {
					JOptionPane.showMessageDialog(null, "Volume n�o aceito", "Erro Volume", JOptionPane.ERROR_MESSAGE);
				}else {
					eq.setVolume(dec);
					JOptionPane.showMessageDialog(null, "Volume cadastrado", "Volume Configurado", JOptionPane.INFORMATION_MESSAGE);
				}
			}else {
				JOptionPane.showMessageDialog(null, "Comando invalido !", "Comando Invalido", JOptionPane.ERROR_MESSAGE);
			}
		}	
	}
}
