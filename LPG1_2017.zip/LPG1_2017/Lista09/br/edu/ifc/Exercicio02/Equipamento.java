package br.edu.ifc.Exercicio02;

public class Equipamento {
	private boolean ligado;

	public boolean isLigado() {
		return ligado;
	}

	public void setLigado(boolean ligado) {
		this.ligado = ligado;
	}
	
	public boolean liga(){
		setLigado (true);
		return true;
	}
	
	public boolean desliga(){
		setLigado (false);
		return false;
	}
}
