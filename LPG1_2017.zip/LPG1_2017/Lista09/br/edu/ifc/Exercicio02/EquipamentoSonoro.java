package br.edu.ifc.Exercicio02;

public class EquipamentoSonoro extends Equipamento{
	private int volume = 0;
	private boolean stereo;
	
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
	public boolean isStereo() {
		return stereo;
	}
	public void setStereo(boolean stereo) {
		this.stereo = stereo;
	}
	
	public void mono(){
		this.stereo = false;
	}
	public void stereo (){
		this.stereo = true;
	}
}
