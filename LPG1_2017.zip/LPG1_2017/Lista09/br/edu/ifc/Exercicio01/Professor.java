package br.edu.ifc.Exercicio01;

public class Professor extends Funcionario{

	public Professor(String nome, String sobrenome, int matricula, double salario) {
		setNome(nome);
		setSobrenome(sobrenome);
		setMatricula(matricula);
		setSalario(salario);
	}

	public double setSalarioProfessor1 (){
		return getSalario();
	}
	
	public double setSalarioProfessor2 (){
		return 0;
	}
	

	
	
}
