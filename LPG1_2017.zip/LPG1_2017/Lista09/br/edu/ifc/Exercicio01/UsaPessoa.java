package br.edu.ifc.Exercicio01;

import javax.swing.JOptionPane;

public class UsaPessoa {
	public static void main(String[] args) {
		Pessoa pessoa1 = new Pessoa ("Mario", "Lopes");
		Funcionario pessoa2 = new Funcionario ("Lucas", "Mendes",2,2000);
		Professor pessoa3 = new Professor ("Rafael", "Lira", 3, 500);
		
		JOptionPane.showMessageDialog(null, "Rela��o de Nomes Completo !\n"
				+ "Pessoa 1: " + pessoa1.setNomeCompleto() + "\n"
						+ "Pessoa 2: " + pessoa2.setNomeCompleto() + "\n"
								+ "Pessoa 3: " + pessoa3.setNomeCompleto(), "Nomes", JOptionPane.INFORMATION_MESSAGE);
		
		JOptionPane.showMessageDialog(null, "Rela��o de Sal�rios !" + "\n"
				+ pessoa2.setNomeCompleto() + " Salario 1: " + pessoa2.setSalario1() + "\n"
						+ pessoa2.setNomeCompleto() +" Salario 2: " + pessoa2.setSalario2() + "\n"
								+ pessoa3.setNomeCompleto() +" Salario 1: "+ pessoa3.setSalarioProfessor1() + "\n"
										+ pessoa3.setNomeCompleto() + " Salario 2: " + pessoa3.setSalarioProfessor2(),"Salarios", JOptionPane.INFORMATION_MESSAGE);
	}
}
