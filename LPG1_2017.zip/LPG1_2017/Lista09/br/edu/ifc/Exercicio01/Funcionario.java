package br.edu.ifc.Exercicio01;

public class Funcionario extends Pessoa{
	private int matricula; 
	private double salario;
	
	
	
	public Funcionario(String nome, String sobrenome, int matricula, double salario) {
		setNome(nome);
		setSobrenome(sobrenome);
		this.matricula = matricula;
		this.salario = salario;
	}
	
	
	public Funcionario() {
		this.matricula = matricula;
		this.salario = salario;
	}

	public int getMatricula() {
		return matricula;
	}
	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	public double setSalario1 (){
		return this.salario*0.60;
	}
	
	public double setSalario2 (){
		return this.salario*0.40;
	}
	
	
}
