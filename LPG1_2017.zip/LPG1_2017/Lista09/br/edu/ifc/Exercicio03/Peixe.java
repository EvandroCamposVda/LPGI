package br.edu.ifc.Exercicio03;

public class Peixe extends Animal{
	private String caracteristicas; 
	
	public Peixe(String animal, int comprimento, int patas, String cor, String ambiente, double velocidade, String caracteristicas) {
		setAnimal(animal);
		setComprimento(comprimento);
		setPatas(patas);
		setCor(cor);
		setAmbiente(ambiente);
		setVelocidade(velocidade);
		this.caracteristicas = caracteristicas;
				
	}

	public String getCaracteristicas() {
		return caracteristicas;
	}

	public void setCaracteristicas(String caracteristicas) {
		this.caracteristicas = caracteristicas;
	}
}
