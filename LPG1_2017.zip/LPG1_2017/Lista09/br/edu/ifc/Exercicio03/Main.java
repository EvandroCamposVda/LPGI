package br.edu.ifc.Exercicio03;

import javax.swing.JOptionPane;

public class Main {
	public static void main(String[] args) {
		Peixe px = new Peixe("Tubar�o", 300, 0, "Cinzento", "Mar", 1.5, "Basbatanas e Cauda");
		Mamifero mf = new Mamifero("Camelo", 150, 4, "Amarelo", "Terra", 2, "null");
		Mamifero mf1 = new Mamifero("Urso-do-Canad�", 180, 4, "Vermelho", "Terra", 0.5, "Mel");
		
		JOptionPane.showMessageDialog(null, "Animal: " + px.getAnimal() + "\n"
			+ "Comprimento: " + px.getComprimento() + "cm\n"
			+ "Patas: " + px.getPatas() + "\n"
			+ "Cor: " + px.getCor()+ "\n"
			+ "Ambiente: " + px.getAmbiente() + "\n"
			+ "Velocidade: " + px.getVelocidade() + "m/s\n"
			+ "Caracteristicas: " + px.getCaracteristicas() + "m/s\n\n\n"
					+ "Animal: " + mf.getAnimal() + "\n"
					+ "Comprimento: " + mf.getComprimento() + "cm\n"
					+ "Patas: " + mf.getPatas() + "\n"
					+ "Cor: " + mf.getCor()+ "\n"
					+ "Ambiente: " + mf.getAmbiente() + "\n"
					+ "Velocidade: " + mf.getVelocidade() + "m/s\n\n\n"
							+ "Animal: " + mf1.getAnimal() + "\n"
							+ "Comprimento: " + mf1.getComprimento() + "cm\n"
							+ "Patas: " + mf1.getPatas() + "\n"
							+ "Cor: " + mf1.getCor()+ "\n"
							+ "Ambiente: " + mf1.getAmbiente() + "\n"
							+ "Velocidade: " + mf1.getVelocidade() + "m/s\n"
							+ "Alimento: " + mf1.getAlimento() , "Informa��es Animal", JOptionPane.INFORMATION_MESSAGE);
	}
}
