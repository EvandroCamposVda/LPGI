package br.edu.ifc.Exercicio03;

public class Mamifero extends Animal{
	private String alimento;
	
	public Mamifero(String animal, int comprimento, int patas, String cor, String ambiente, double velocidade, String alimento) {
		setAnimal(animal);
		setComprimento(comprimento);
		setPatas(patas);
		setCor(cor);
		setAmbiente(ambiente);
		setVelocidade(velocidade);
		this.alimento = alimento;	
	}

	public String getAlimento() {
		return alimento;
	}

	public void setAlimento(String alimento) {
		this.alimento = alimento;
	}
}
