package br.edu.ifc.Exemplo_heran�a;

import javax.swing.JOptionPane;

public class PrincipalVeiculo {
	
	public static void main(String[] args) {
		
		moto mo = new moto();
		carro ca = new carro();
		String cor;
		int ano;
		double preconovo;
		double cilindrada;
		int portas;
		int op = 0;
		
		
		for(;;){
			op=Integer.parseInt(JOptionPane.showInputDialog("Qual ve�culo deseja cadastrar:\n" +
					"1 - Moto\n" +
					"2 - Carro\n" +
					"3 - Sair"));
			if (op==1){
			cor=String.valueOf(JOptionPane.showInputDialog("Qual a cor da moto"));
			mo.setCor(cor);
			ano=Integer.parseInt(JOptionPane.showInputDialog("Qual o ano de fabrica��o"));
			mo.setAno(ano);
			preconovo=Double.parseDouble(JOptionPane.showInputDialog("Qual o preco da moto nova"));
			mo.setPreconovo(preconovo);
			cilindrada=Double.parseDouble(JOptionPane.showInputDialog("Qual a quantidade de cilindradas da moto"));
			mo.setCilindrada(cilindrada);
			
			JOptionPane.showMessageDialog(null, "Moto cadastrada:\n" +
					"Cor:"+mo.getCor()+
					"\nAno:"+mo.getAno()+
					"\nPreco atual da moto:"+mo.calculaPrecoAtual()+
					"\nQuantidade de cilindradas:"+mo.getCilindrada());
			
			
			}else if (op==2){
				cor=String.valueOf(JOptionPane.showInputDialog("Qual a cor do carro"));
				ca.setCor(cor);
				ano=Integer.parseInt(JOptionPane.showInputDialog("Qual o ano de fabrica��o"));
				ca.setAno(ano);
				preconovo=Double.parseDouble(JOptionPane.showInputDialog("Qual o preco do carro novo"));
				ca.setPreconovo(preconovo);
				portas=Integer.parseInt(JOptionPane.showInputDialog("Qual a quantidade de portas do carro"));
				ca.setQuantidadePortas(portas);
				
				JOptionPane.showMessageDialog(null, "Carro cadastrado:\n" +
						"Cor:"+ca.getCor()+
						"\nAno:"+ca.getAno()+
						"\nPreco atual do carro:"+ca.calculaPrecoAtual()+
						"\nQuantidade de portas:"+ca.getQuantidadePortas());
				
				
				}else{
					break;
				}
			
			
		}
		
	}
}
