package br.edu.ifc.Exemplo_heran�a;

public class Veiculo {
	
	private String cor;
	private int ano;
	private double preconovo;
	
	
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public double getPreconovo() {
		return preconovo;
	}
	public void setPreconovo(double preconovo) {
		this.preconovo = preconovo;
	}
	
	public double calculaPrecoAtual(){
		return this.getPreconovo()-(2014-this.getAno())*300;
	}
}

