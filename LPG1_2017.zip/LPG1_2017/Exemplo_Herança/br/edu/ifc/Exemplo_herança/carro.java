package br.edu.ifc.Exemplo_heran�a;

public class carro extends Veiculo {
	
	private int quantidadePortas;

	public int getQuantidadePortas() {
		return quantidadePortas;
	}

	public void setQuantidadePortas(int quantidadePortas) {
		this.quantidadePortas = quantidadePortas;
	}
	
	

}
