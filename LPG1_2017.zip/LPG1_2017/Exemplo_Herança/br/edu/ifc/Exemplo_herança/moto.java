package br.edu.ifc.Exemplo_heran�a;

public class moto extends Veiculo{
	
	private double cilindrada;

	public double getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(double cilindrada) {
		this.cilindrada = cilindrada;
	}
	
	public double calculaPrecoAtual(){
		return this.getPreconovo()-(2014-this.getAno())*100;
	}
	
}