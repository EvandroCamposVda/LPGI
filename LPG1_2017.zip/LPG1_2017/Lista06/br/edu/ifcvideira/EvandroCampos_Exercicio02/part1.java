package br.edu.ifcvideira.EvandroCampos_Exercicio02;

public class part1 {
	
	private double n1;
	private double n2;
	private double n3;
	
	public void getTroca(double n1, double n2){
		this.n1 = n1;
		this.n2 = n2;
		this.n3 = this.n1;
		this.n1 = this.n2;
		this.n2 = this.n3;
	}
	
	public double getN1(){
		return n1;
	}
	public double getN2(){
		return n2;
	}
}
