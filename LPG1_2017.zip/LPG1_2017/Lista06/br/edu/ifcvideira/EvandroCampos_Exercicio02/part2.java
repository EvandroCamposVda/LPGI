package br.edu.ifcvideira.EvandroCampos_Exercicio02;

import javax.swing.JOptionPane;

public class part2 {
	public static void main(String[] args) {
		part1 troca = new part1 ();
		double n1 = 10;
		double n2 = 12;
		
		n1 = Double.parseDouble(JOptionPane.showInputDialog("Digite o numero n1: "));
		n2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o numero n2: "));
		
		troca.getTroca(n1, n2);
		
		JOptionPane.showMessageDialog(null, "Valor n1: " + troca.getN1()
				+ "\nValor n2: " +  troca.getN2());
	}
}
