package br.edu.ifcvideira.EvandroCampos_Exercicio03_Construtor;

public class part1 {
	
	private double salMin;
	private double kwh;
	
	public part1(double salMin, double kwh) {
		this.salMin = salMin;
		this.kwh = kwh;
	}
	
	public double getCalc() {
		return this.salMin/7/100*kwh;
	}
	
	public double getCalc1(){
		return this.salMin/7/100*0.9*kwh;
	}
}