package br.edu.ifcvideira.EvandroCampos_Exercicio03_Construtor;

import javax.swing.JOptionPane;

public class part2 {
	public static void main(String[] args) {
		double salMin1;
		double kwh1;
		
		for (;;){
			salMin1 = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do salario minimo !"));
			kwh1 = Double.parseDouble(JOptionPane.showInputDialog("Digite a quantidade de quilowatts gasto !"));
		
			part1 calc = new part1 (salMin1, kwh1);
		
			JOptionPane.showMessageDialog(null, "O valor da fatura � de: " + calc.getCalc()
				+ "\nValor da Fatura com desconto � de: " + (calc.getCalc1()));
		}
	}
}