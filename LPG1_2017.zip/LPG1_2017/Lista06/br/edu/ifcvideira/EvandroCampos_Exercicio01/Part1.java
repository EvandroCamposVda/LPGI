package br.edu.ifcvideira.EvandroCampos_Exercicio01;

public class Part1 {
	
	private double Numero;
	
	public double getNumero(){
		return Numero;
	}
	public void soma (double numero) {
		this.Numero = numero + 1;
	}
	public void menos (double numero){
		this.Numero = numero - 1;
	}
	
}
