package br.edu.ifcvideira.EvandroCampos_Exercicio01;

import javax.swing.JOptionPane;

public class Part2 {
	public static void main(String[] args) {
		Part1 num = new Part1();
		int dec;
		double valor = 0;
		
		for (;;){
			dec = Integer.parseInt(JOptionPane.showInputDialog("1 - Incrementar\n"
				+ "2 - Decrementar\n"
				+ "3 - Sair"));
			if (dec == 1){
				num.soma(valor);
				valor = valor + 1;
				JOptionPane.showMessageDialog(null, "Resultado Final: " + num.getNumero());
			}else if (dec == 2){
				num.menos(valor);
				valor = valor - 1;
				JOptionPane.showMessageDialog(null, "Resultado Final: " + num.getNumero());
			}else if (dec == 3){
				JOptionPane.showMessageDialog(null, "Fechando o Programa !");
				break;
			}else {
				JOptionPane.showMessageDialog(null, "Comando Invalido !");
			}
		}
	}
}
