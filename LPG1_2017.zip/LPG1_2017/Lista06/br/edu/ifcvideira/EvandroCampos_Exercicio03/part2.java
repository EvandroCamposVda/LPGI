package br.edu.ifcvideira.EvandroCampos_Exercicio03;

import javax.swing.JOptionPane;

public class part2 {
	public static void main(String[] args) {
		part1 calc = new part1 ();
		double salMin1;
		double kwh1;
		
		for (;;){
			salMin1 = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do salario minimo !"));
			kwh1 = Double.parseDouble(JOptionPane.showInputDialog("Digite a quantidade de quilowatts gasto !"));
		
			calc.valorP(kwh1, salMin1);
		
			JOptionPane.showMessageDialog(null, "O valor da fatura � de: " + calc.getCalc()
				+ "\nValor da Fatura com desconto � de: " + (calc.getCalc1()));
		}
	}
}