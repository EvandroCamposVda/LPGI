package br.edu.ifcvideira.EvandroCampos_Exercicio03;

public class part1 {
	private double salMin;
	private double kwh;
	private double calc;
	private double calc1;
	
	public void valorP (double kwh, double salMin1) {//Calculo de dados redebidos 
		this.salMin = salMin1;
		this.kwh = kwh;
		this.calc = (((this.salMin/7)*(this.kwh/100)));
		this.calc1 = ((this.salMin/7)*(this.kwh/100)) - ((this.salMin/7)*(this.kwh/100)*0.10);
	}
	public double getCalc () {//Retorno do valor total 
		return this.calc;
	}
	public double getCalc1 (){//Retorno do valor do desconto
		return this.calc1;
	}
}