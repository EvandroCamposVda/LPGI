package br.edu.ifcvideira.Exercicio01;

import javax.swing.JOptionPane;

public class main {
	public static void main(String[] args) {
		Gerente ge = new Gerente ();
		AssistenteTecnico AT = new AssistenteTecnico();
		AssistenteAdmin AA = new AssistenteAdmin();
		
		int dec;
		
		for (;;){
			dec = Integer.parseInt(JOptionPane.showInputDialog(null, "Qual o tipo de funcionario que deseja cadastrar ? \n"
					+ "1 - Gerente\n"
					+ "2 - Assistente Tecnico\n"
					+ "3 - Assistente Administrativo\n"
					+ "4 - Sair", "Cadastro de Fun��o", JOptionPane.QUESTION_MESSAGE));
			
			if (dec == 1){
				ge.setNome(String.valueOf(JOptionPane.showInputDialog(null, "Qual o nome do gerente", "Cadastro Nome Gerente", JOptionPane.QUESTION_MESSAGE)));
				ge.setSalario(Double.parseDouble(JOptionPane.showInputDialog(null, "Qual o salario de "+ ge.getNome(), "Cadastro Salario Gerente", JOptionPane.QUESTION_MESSAGE)));
				ge.setCargo("Gerente");
				
				JOptionPane.showMessageDialog(null, "Dados Funcion�rio\n"
						+ "Cargo: " + ge.getCargo() + "\n"
						+ "Nome: " + ge.getNome() + "\n"
						+ "Sal�rio Total: " + ge.calculaSalarioGerente() + "\n", "Salario Gerente", JOptionPane.INFORMATION_MESSAGE);
			}else if (dec == 2){
				AT.setNome(String.valueOf(JOptionPane.showInputDialog(null, "Qual o nome do Assistente Tecnico", "Cadastro Nome Assistente Tecnico", JOptionPane.QUESTION_MESSAGE)));
				AT.setSalario(Double.parseDouble(JOptionPane.showInputDialog(null, "Qual o salario de "+ AT.getNome(), "Cadastro Salario Assistente Tecnico", JOptionPane.QUESTION_MESSAGE)));
				AT.setCargo("Assistente Tecnico");
				
				JOptionPane.showMessageDialog(null, "Dados Funcion�rio\n"
						+ "Cargo: " + AT.getCargo() + "\n"
						+ "Nome: " + AT.getNome() + "\n"
						+ "Sal�rio Total: " + AT.calculaSalarioAssistenteTecnico() + "\n", "Salario Assistente T�cnico", JOptionPane.INFORMATION_MESSAGE);
			}else if (dec == 3){
				AA.setNome(String.valueOf(JOptionPane.showInputDialog(null, "Qual o nome do Assistente Administrativo", "Cadastro Nome Assistente Administrativo", JOptionPane.QUESTION_MESSAGE)));
				AA.setSalario(Double.parseDouble(JOptionPane.showInputDialog(null, "Qual o salario de "+ AA.getNome(), "Cadastro Salario Assistente Administrativo", JOptionPane.QUESTION_MESSAGE)));
				AA.setCargo("Assistente Administrativo");
				
				JOptionPane.showMessageDialog(null, "Dados Funcion�rio\n"
						+ "Cargo: " + AA.getCargo() + "\n"
						+ "Nome: " + AA.getNome() + "\n"
						+ "Sal�rio Total: " + AA.calcularSalarioAssistenteAdmin() + "\n", "Salario Assistente Administrativo", JOptionPane.INFORMATION_MESSAGE);
			}else if (dec == 4){
				JOptionPane.showMessageDialog(null, "Fechando Sistema", "Fechando Sistema", JOptionPane.INFORMATION_MESSAGE);
				break;
			}else {
				JOptionPane.showMessageDialog(null, "Comando Invalido !", "Erro Menu Principal", JOptionPane.ERROR_MESSAGE);
			}
			
		}
	}
}
