package br.edu.ifcvideira.Exercicio01;

public class AssistenteAdmin extends Funcionario {
	private String numMatricula;
	private String turno;
	
	
	public String getNumMatricula() {
		return numMatricula;
	}
	public void setNumMatricula(String numMatricula) {
		this.numMatricula = numMatricula;
	}
	public String getTurno() {
		return turno;
	}
	public void setTurno(String turno) {
		this.turno = turno;
	}
	
	public double calcularSalarioAssistenteAdmin(){
		return this.getSalario()*1.3;
	}
}