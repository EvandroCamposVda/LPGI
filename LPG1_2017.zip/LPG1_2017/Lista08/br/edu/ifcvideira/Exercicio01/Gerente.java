package br.edu.ifcvideira.Exercicio01;

public class Gerente extends Funcionario {
	
	public double calculaSalarioGerente (){
		return this.getSalario()*1.5;
	}
	
}
