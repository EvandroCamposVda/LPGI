package br.edu.ifcvideira.Exercicio01;

public class AssistenteTecnico extends Funcionario {
	
	public double calculaSalarioAssistenteTecnico(){
		return this.getSalario()*1.2;
	}
	
}
