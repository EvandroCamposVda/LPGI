package br.edu.ifcvideira.Exercicio04;

public class Imovel {
	private String endereco = new String ("Rua: Bauc�o Viana, Floresta, Videira - SC, Brasil");
	private Double preco = 1500000.0;
	
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public Double getPreco() {
		return preco;
	}
	public void setPreco(Double preco) {
		this.preco = preco;
	}
	
}
