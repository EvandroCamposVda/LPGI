package br.edu.ifcvideira.Exercicio04;

public class Novo extends Imovel{
	public Double valorNovo(){
		return (getPreco() * 1.30);
	}
}
