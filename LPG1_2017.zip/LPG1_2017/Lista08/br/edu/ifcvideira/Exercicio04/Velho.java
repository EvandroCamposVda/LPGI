package br.edu.ifcvideira.Exercicio04;

public class Velho extends Imovel{
	public Double valorVelho (){
		return getPreco()*0.70;
	}
}
