package br.edu.ifcvideira.Exercicio04;

import javax.swing.JOptionPane;

public class main {
	public static void main(String[] args) {
		int dec;
		Novo novo = new Novo();
		Velho velho = new Velho ();
		
		for (;;){
			dec = Integer.parseInt(JOptionPane.showInputDialog(null, "1 - Novo\n"
					+ "2 - Velho\n"
					+ "3 - Sair\n"
					+ "Qual op��o deseja cadastrar ?", "Menu Escolha", JOptionPane.INFORMATION_MESSAGE));
			if (dec == 1){
				JOptionPane.showMessageDialog(null, "Valor imovel Novo R$"+novo.valorNovo() + "\n"
						+ "Endere�o: "+ novo.getEndereco(), "Valor Imovel Novo", JOptionPane.INFORMATION_MESSAGE);
			}else if (dec == 2){
				JOptionPane.showMessageDialog(null, "Valor imovel Velho R$"+velho.valorVelho() + "\n"
						+ "Endere�o: "+ velho.getEndereco(), "Valor Imovel Velho", JOptionPane.INFORMATION_MESSAGE);
			}else if (dec == 3){
				JOptionPane.showMessageDialog(null, "Finalizando Sistema", "Finalizando", JOptionPane.WARNING_MESSAGE);
				break;
			}else {
				JOptionPane.showMessageDialog(null, "Comando Invalido !", "Erro", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}
