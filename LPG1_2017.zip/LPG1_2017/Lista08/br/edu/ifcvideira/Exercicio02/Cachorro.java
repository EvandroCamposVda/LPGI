package br.edu.ifcvideira.Exercicio02;

public class Cachorro extends Animal {
	
	public String late (){
		return "AU AU";
	}
}
