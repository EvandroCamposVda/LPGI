package br.edu.ifcvideira.Exercicio02;

import javax.swing.JOptionPane;

public class cadastroAnimal {
	public static void main(String[] args) {
		Cachorro dog = new Cachorro ();
		Gato cat = new Gato();
		
		int dec;
		
		for (;;){
			dec = Integer.parseInt(JOptionPane.showInputDialog(null, "1 - Cachorro\n"
					+ "2 - Gato\n"
					+ "3 - Sair\n"
					+ "Digite Esp�cie do animal !", "Digite Especie", JOptionPane.QUESTION_MESSAGE));
			if (dec == 1){
				dog.setNome(String.valueOf(JOptionPane.showInputDialog(null, "Digite o nome do animal", "Cadastro nome Cachorro", JOptionPane.QUESTION_MESSAGE)));
				dog.setRaca(String.valueOf(JOptionPane.showInputDialog(null, "Digite a Ra�a do animal", "Cadastro Ra�a", JOptionPane.QUESTION_MESSAGE)));
				JOptionPane.showMessageDialog(null, "Dados Animal\n"
						+ "Nome: " + dog.getNome() + "\n"
								+ "Ra�a: " + dog.getRaca() + "\n"
										+ "A��o Animal: " + dog.late(), "Dados C�o", JOptionPane.INFORMATION_MESSAGE);
			}else if (dec == 2) {
				cat.setNome(String.valueOf(JOptionPane.showInputDialog(null, "Digite o nome do animal", "Cadastro nome gato", JOptionPane.QUESTION_MESSAGE)));
				cat.setRaca(String.valueOf(JOptionPane.showInputDialog(null, "Digite a ra�a do animal", "Cadastro ra�a gato", JOptionPane.QUESTION_MESSAGE)));
				JOptionPane.showMessageDialog(null, "Dados Animal\n"
						+ "Nome: " + cat.getNome() + "\n"
						+ "Ra�a: " + cat.getRaca() + "\n"
						+ "A��o Animal: " + cat.mia(), "Dados Gato", JOptionPane.INFORMATION_MESSAGE);
			}else if (dec == 3) {
				JOptionPane.showMessageDialog(null, "Fechando Sistema !", "Finalizando", JOptionPane.CANCEL_OPTION);
				break;
			}else {
				JOptionPane.showMessageDialog(null, "Erro 198 !\n"
						+ "Comando Invalido !", "Erro comando Invalido", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}
