package br.edu.ifcvideira.Exercicio03;

public class CamaroteSuperior extends VIP{

	public double ValorCamaroteSuperior() {
		return getValor() + 100;
	}
	
}
