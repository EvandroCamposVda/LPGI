package br.edu.ifcvideira.Exercicio03;

import javax.swing.JOptionPane;

public class main {
	public static void main(String[] args) {
		Normal normal = new Normal();
		VIP vip = new VIP();
		CamaroteInferior inferior = new CamaroteInferior();
		CamaroteSuperior superior = new CamaroteSuperior();
		
		int dec;
		int contN = 0, contV = 0, contCI = 0, contCS = 0, dec2 = 0;

				for(;;){
					dec = Integer.parseInt(JOptionPane.showInputDialog(null, "1 - Normal \n"
							+ "2 - VIP\n"
							+ "3 - Camarote Inferior \n"
							+ "4 - Camarote Superior \n"
							+ "5 - Sair", "Emiss�o Ingresso", JOptionPane.QUESTION_MESSAGE));
					if (dec == 1) {
						if (normal.getValor() == 0) {
							JOptionPane.showMessageDialog(null, "Erro 195 !\n"
									+ "Dados n�o cadastrados para ingresso Comum\n"
									+ "Favor Cadastrar um valor para Ingresso Comum !", "Erro Ingresso VIP", JOptionPane.ERROR_MESSAGE);
						}else {	
							dec2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a quantidade", "Quantidade Ingresso", JOptionPane.QUESTION_MESSAGE));
							dec = JOptionPane.showConfirmDialog(null, "Deseja confirmar a venda de " + dec2 + " Ingressos ?", "Confirma��o Venda Ingresso", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
								if (dec == 0) {
									JOptionPane.showMessageDialog(null, "valor Ingressos Comum !\n" +
											dec2 + " Ingressos Comum: R$" + (dec2*normal.getValor()), "Relatorio Venda", JOptionPane.INFORMATION_MESSAGE);
											contN = contN + dec2;
								}
						}//Fim Venda ingresso normal
					}else if (dec == 2) {
						if (vip.ValorVIP() == 0) {
							JOptionPane.showMessageDialog(null, "Erro 194 !\n"
							+ "Dados n�o cadastrados para ingresso VIP\n"
							+ "Favor Cadastrar um valor para Ingresso VIP !", "Erro Ingresso VIP", JOptionPane.ERROR_MESSAGE);
							
						}else {
							dec2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a quantidade", "Quantidade Ingresso", JOptionPane.QUESTION_MESSAGE));
							dec = JOptionPane.showConfirmDialog(null, "Deseja confirmar a venda de " + dec2 + " Ingressos ?", "Confirma��o Venda Ingresso", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
								if (dec == 0) {
									JOptionPane.showMessageDialog(null, "valor Ingressos VIP !\n" +
											dec2 + " Ingressos Comum: R$" + (dec2*vip.ValorVIP()), "Relatorio Venda", JOptionPane.INFORMATION_MESSAGE);
											contV = contV + dec2;
								}
						}
					}else if (dec == 3) {
						if (vip.ValorVIP() == 0) {
							JOptionPane.showMessageDialog(null, "Erro 194 !\n"
							+ "Dados n�o cadastrados para ingresso VIP\n"
							+ "Favor Cadastrar um valor para Ingresso VIP !", "Erro Ingresso VIP", JOptionPane.ERROR_MESSAGE);
							
						}else if (inferior.getLocaliza��o().equals("Vazio")) {
							JOptionPane.showMessageDialog(null, "Erro 196 !\n"
									+ "Localiza��o de ingresso n�o cadastrado !\n"
									+ "Favor Cadastrar uma localiza��o", "Erro Localiza��o", JOptionPane.ERROR_MESSAGE);
								
						}else {
							dec2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a quantidade", "Quantidade Ingresso", JOptionPane.QUESTION_MESSAGE));
							dec = JOptionPane.showConfirmDialog(null, "Deseja confirmar a venda de " + dec2 + " Ingressos ?", "Confirma��o Venda Ingresso", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
								if (dec == 0) {
									JOptionPane.showMessageDialog(null, "Valor Ingressos Camarote Inferior !\n" +
											dec2 + " Ingressos Camarote Inferior: R$" + (dec2*vip.ValorVIP()) + "\n"
											+ "Local: " + inferior.getLocaliza��o(), "Relatorio Venda", JOptionPane.INFORMATION_MESSAGE);
											contCI = contCI + dec2;
											
								}
						}
					}else if (dec == 4) {
						if (superior.ValorCamaroteSuperior() == 0) {
							JOptionPane.showMessageDialog(null, "Erro 194 !\n"
							+ "Dados n�o cadastrados para ingresso Camarote Superior\n"
							+ "Favor Cadastrar um valor para Ingresso Camarote Superior !", "Erro Ingresso Camarote Superior", JOptionPane.ERROR_MESSAGE);
						}else {
							dec2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a quantidade", "Quantidade Ingresso", JOptionPane.QUESTION_MESSAGE));
							dec = JOptionPane.showConfirmDialog(null, "Deseja confirmar a venda de " + dec2 + " Ingressos ?", "Confirma��o Venda Ingresso", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
								if (dec == 0) {
									JOptionPane.showMessageDialog(null, "Valor Ingressos Camarote Superior !\n" +
											dec2 + " ingressos Camarote Superior: R$" + (dec2*superior.ValorCamaroteSuperior()) , "Relatorio Venda", JOptionPane.INFORMATION_MESSAGE);
											contCS = contCS + dec2;
											
								}
						}
					}else if (dec == 5) {
						JOptionPane.showMessageDialog(null, "Fechando Sistema !!", "Fianlizando !", JOptionPane.INFORMATION_MESSAGE);
						break;
					}else {
						JOptionPane.showMessageDialog(null, "Comando invalido !", "Comando Invalido", JOptionPane.ERROR_MESSAGE);
					}
				}// Fim emiss�o Ingresso
		}
	}