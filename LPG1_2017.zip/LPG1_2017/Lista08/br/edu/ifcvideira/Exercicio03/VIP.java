package br.edu.ifcvideira.Exercicio03;

public class VIP extends Ingresso{
	private double acrescimo;

	public double getAcrescimo() {
		return acrescimo;
	}

	public void setAcrescimo(double acrescimo) {
		this.acrescimo = acrescimo;
	}
	
	public double ValorVIP() {
		return getValor() + 30;
	}
}
