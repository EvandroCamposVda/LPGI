package br.edu.ifcvideira.Exercicio03;

public class Normal extends Ingresso{
	
	public Double IngressoNormal () {
		return getValor();
	}
	
}
