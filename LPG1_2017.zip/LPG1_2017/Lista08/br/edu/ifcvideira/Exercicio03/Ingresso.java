package br.edu.ifcvideira.Exercicio03;

public class Ingresso {
	private double valor = 50;

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	
	
}
