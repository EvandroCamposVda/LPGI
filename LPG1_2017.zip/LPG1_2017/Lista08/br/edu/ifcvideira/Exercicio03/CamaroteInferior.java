package br.edu.ifcvideira.Exercicio03;

public class CamaroteInferior extends VIP {
	private String localiza��o = new String ("Parte Superior");
	
	public String getLocaliza��o() {
		return localiza��o;
	}

	public void setLocaliza��o(String localiza��o) {
		this.localiza��o = localiza��o;
	}
	
	public double getValorInferior() {
		return ValorVIP() + 30;
	}
}
